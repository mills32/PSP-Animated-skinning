///ANIMATION 3D
#include <oslib/oslib.h>
#include <AMG/AMGLib.h>


PSP_MODULE_INFO("Cube Sample", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_VFPU | THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(12*1024);

void AMG_RotateMatrix_by_quat(ScePspQuatMatrix *q, ScePspFMatrix4 *m) {
	__asm__ volatile (
       "lv.q      C000, %1\n"                               // C000 = [x,  y,  z,  w ]
       "vmul.q    C010, C000, C000\n"                       // C010 = [x2, y2, z2, w2]
       "vcrs.t    C020, C000, C000\n"                       // C020 = [yz, xz, xy ]
       "vmul.q    C030, C000[x,y,z,1], C000[w,w,w,2]\n"	    // C030 = [wx, wy, wz ]

       "vadd.q    C100, C020[0,z,y,0], C030[0,z,-y,0]\n"    // C100 = [0,     xy+wz, xz-wy]
       "vadd.s    S100, S011, S012\n"                       // C100 = [y2+z2, xy+wz, xz-wy]

       "vadd.q    C110, C020[z,0,x,0], C030[-z,0,x,0]\n"    // C110 = [xy-wz, 0,     yz+wx]
       "vadd.s    S111, S010, S012\n"                       // C110 = [xy-wz, x2+z2, yz+wx]

       "vadd.q    C120, C020[y,x,0,0], C030[y,-x,0,0]\n"    // C120 = [xz+wy, yz-wx, 0    ]
       "vadd.s    S122, S010, S011\n"                       // C120 = [xz+wy, yz-wx, x2+y2]

       "vmscl.t   M100, M100, S033\n"                       // C100 = [2*(y2+z2), 2*(xy+wz), 2*(xz-wy)]
                                                            // C110 = [2*(xy-wz), 2*(x2+z2), 2*(yz+wx)]
                                                            // C120 = [2*(xz+wy), 2*(yz-wx), 2*(x2+y2)]

       "vocp.s    S100, S100\n"                             // C100 = [1-2*(y2+z2), 2*(xy+wz),   2*(xz-wy)  ]
       "vocp.s    S111, S111\n"                             // C110 = [2*(xy-wz),   1-2*(x2+z2), 2*(yz+wx)  ]
       "vocp.s    S122, S122\n"                             // C120 = [2*(xz+wy),   2*(yz-wx),   1-2*(x2+y2)]

       "vidt.q    C130\n"                                   // C130 = [0, 0, 0, 1]

       "sv.q      R100, 0  + %0\n"
       "sv.q      R101, 16 + %0\n"
       "sv.q      R102, 32 + %0\n"
       
	: "=m"(*m) : "m"(*q));
}

typedef struct {
	float skinWeight[8];
	float u, v;
	unsigned int color;
	float nx,ny,nz;
	float x,y,z;
}AMG_Vertex_WTNV;

typedef struct {
	ScePspFVector3 position;
	ScePspQuatMatrix orient; 
	ScePspQuatMatrix interpolated; 
	int parent;
}AMG_Bone;

typedef struct {
	AMG_Bone *Bone;
}AMG_SkinFrame;

typedef struct {
	u32 Start,End;
	int bones[8];
}AMG_SkinGroup;

#ifdef AMG_DOC_ENGLISH
/**
 * @struct
 * @brief Structs which holds Animted mesh
 */
#else
/**
 * @struct
 * @brief Estructuras de un modelo animado
 */
#endif
typedef struct {
	AMG_Texture *texture;
	AMG_Texture *MultiTexture;
	AMG_Vertex_WTNV *Data;
	AMG_SkinFrame *Frame;
	AMG_SkinGroup *Group;
	MorphVertex *vertices;
	u8 Lighting;
	int n_bones;
	int n_groups;
	int frameCount;
	int polyCount;
	int frame;
	int lastFrame;
	int startFrame;
	int endFrame;
	int loop;
	float speed;
	float interpolation;
	int fps;
	float morphoweight;
	ScePspFVector3 *BBox;
// Motor fisico BULLET
	int phys;
	float Mass;									/**< Masa del objeto / Object mass */
	u32 bullet_id;
}SkinnedModel;
typedef struct{
	int Mirror;
	SkinnedModel *Object;
	int smooth;
	int Optimized;				//Activate Optimization to save ram
	ScePspFVector3 Pos;
	ScePspFVector3 Rot;
	ScePspFVector3 Scale;
	ScePspFVector3 Origin;
	ScePspFMatrix4 *bones;
}AMG_Skinned_Actor;


int val = 0;

//CARGA EL MODELO DEL ARCHIVO
AMG_Skinned_Actor *AMG_LoadSkinnedActor(char *path){
	
	int i;
	int k;
	u32 v = 0;
	int bone = 0;
	int groups = 0;
	int bonef = 0;
	int frame = 0;
	
	AMG_Skinned_Actor *actor = NULL;
	actor = (AMG_Skinned_Actor*) calloc (1, sizeof(AMG_Skinned_Actor));
	actor->Object = (SkinnedModel*) calloc (1, sizeof(SkinnedModel));
	//////////////////////////////////
	
	actor->Object[0].texture=NULL;
	actor->Object[0].MultiTexture =NULL;
	actor->Object[0].frameCount=0;
	actor->Object[0].polyCount=0;
	actor->Object[0].n_bones=0;
	
	FILE *f = fopen(path, "r");

	char *line = (char*) calloc (128, sizeof(char));
	
	//LEE número de triangulos, huesos y frames
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		switch(line[0]){
			case 'n': 
				if (line[1] == 't') sscanf(line,"ntris %i",&actor->Object[0].polyCount);
				if (line[1] == 'b') sscanf(line,"nbones %i",&actor->Object[0].n_bones);
				if (line[1] == 'f') sscanf(line,"nframes %i",&actor->Object[0].frameCount); 
				break;
			case '\t': //nsplit
				if (line[1] == 'n') groups++;
				break;
			default: break; 
		}
	}
	
	//PREPARA MEMORIA
	actor->Object[0].Data = (AMG_Vertex_WTNV*) malloc(sizeof(AMG_Vertex_WTNV)*actor->Object->polyCount*3);
	actor->Object[0].Frame = (AMG_SkinFrame*) malloc(sizeof(AMG_SkinFrame)*actor->Object->frameCount);
	for(i = 0; i < actor->Object->frameCount; i++){
		actor->Object[0].Frame[i].Bone = (AMG_Bone*) malloc(sizeof(AMG_Bone)*actor->Object[0].n_bones);
	}
	actor->bones = (ScePspFMatrix4*) malloc (sizeof(ScePspFMatrix4)*32);
	actor->Object[0].Group = (AMG_SkinGroup*) malloc (sizeof(AMG_SkinGroup)*groups);
	actor->Object[0].n_groups = groups;
	int dummy;
	bonef = 0;
	groups = 0;
	frame = 0;
	//METE DATOS EN VARIABLES
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		switch(line[0]){
			case '#': break;
			case 'b':
			    if (line[1] == 'n'){ //Bones
					sscanf(line,"bn %i %i",&dummy,&actor->Object[0].Frame[0].Bone[bone].parent);
					bone++;
				}
				if (line[1] == 'f') bonef = 0; break;			
			case 'p':
			    if (line[1] == 'f'){ //Bone positions frames
					ScePspFVector3 position; 
					ScePspQuatMatrix orient; 
					sscanf(line,"pf %f %f %f %f %f %f %f",
					    &position.x,&position.y,&position.z,
						&orient.x,&orient.y,&orient.z,&orient.w
                    );
					actor->Object[0].Frame[frame].Bone[bonef].position = position;
					actor->Object[0].Frame[frame].Bone[bonef].orient = orient;
					bonef++;
				}
			    break;
			case 'x': frame++;
			case '\t': //nsplit
				if (line[1] == 'n') {
					if (groups > 0) actor->Object[0].Group[groups-1].End = v;
					actor->Object[0].Group[groups].Start = v;
					groups++;
					}
				break;
			case '-': //end data
				if (line[1] == 'e') actor->Object[0].Group[groups-1].End = v;
			case 'v':
				if (line[1] == ' '){ //XYZ, UV, Normal(xyz), bone
					int bonew;
					sscanf(line, 
					    "v %f %f %f %f %f %f %f %f %i",
						&actor->Object[0].Data[v].x, &actor->Object[0].Data[v].z, &actor->Object[0].Data[v].y,
                        &actor->Object[0].Data[v].u, &actor->Object[0].Data[v].v,
                        &actor->Object[0].Data[v].nx, &actor->Object[0].Data[v].nz, &actor->Object[0].Data[v].ny,						
						&bonew
					);
					actor->Object[0].Data[v].z = -1*actor->Object[0].Data[v].z;
					actor->Object[0].Data[v].nz = -1*actor->Object[0].Data[v].nz;
					actor->Object[0].Data[v].v = -1*actor->Object[0].Data[v].v;
					
					for(k=0;k<8;k++) actor->Object[0].Data[v].skinWeight[k] = 0;
					actor->Object[0].Data[v].skinWeight[bonew] = 1;
					actor->Object[0].Data[v].color = 0xffffffff;
					v++;
				} break;
			default: break; 
		}
	}
	fclose(f);
	
	//get texture with the same name as the file
	char *texturename = (char*) calloc (strlen(path), sizeof(char));
	strncpy(texturename,path,strlen(path)-3);
	strcat(texturename,"png");
	AMG_Texture *texture = AMG_LoadTexture(texturename,AMG_TEX_RAM);
	if (texture != NULL) actor->Object[0].texture = texture;
	
	if(line) free(line); line = NULL;

	actor->Pos = actor->Rot = (ScePspFVector3) {0,0,0};
	actor->Scale = (ScePspFVector3) {1,1,1};
	actor->Object[0].Lighting = 1;
	actor->Object[0].frameCount = actor->Object[0].frameCount;
	actor->Object[0].startFrame = 0;
	actor->Object[0].endFrame = 0;
	actor->Object[0].loop = 1;
	actor->Object[0].speed = 0;
	actor->Object[0].interpolation = 0;
	actor->Object[0].frame = 0;
	actor->smooth = 1;
	return actor;
}

void AMG_RenderSkinnedActor(AMG_Skinned_Actor *actor){
	// Comprueba si es NULL
	if(actor == NULL) return;
	// Control de la iluminación
	u8 l2 = 0;

	if(!actor->Object[0].Lighting){
		l2 = sceGuGetStatus(GU_LIGHTING);
		sceGuDisable(GU_LIGHTING);
	}
	
	//animation
	int frame,nextframe;
	float sp = 1/actor->Object[0].speed;
	
	if (actor->Object[0].interpolation > 1){
		actor->Object[0].interpolation = 0;
		actor->Object[0].frame++;
	}
	if (actor->Object[0].frame == actor->Object[0].frameCount)
		actor->Object[0].frame = 0;
	frame = actor->Object[0].frame;
	nextframe = frame+1;
	if (frame == actor->Object[0].frameCount-1)
		nextframe = 0;
	if (frame == actor->Object[0].frameCount)
		frame = 0;
	
	// Aplica las transformaciones necesarias	
	
	//Posicion del hueso padre
	ScePspFVector3 GPos0 = actor->Object[0].Frame[0].Bone[0].position;
	ScePspFVector3 GPos1 = actor->Object[0].Frame[frame].Bone[0].position;
	ScePspFVector3 GPos;
	GPos.x = actor->Pos.x-GPos0.x+GPos1.x; 
	GPos.y = actor->Pos.y-GPos0.y+GPos1.y;
	GPos.z = actor->Pos.z-GPos0.z+GPos1.z;
	
	AMG_PushMatrix(GU_MODEL);
	AMG_Translate(GU_MODEL, &GPos);
	AMG_Translate(GU_MODEL, &actor->Origin);
	AMG_Rotate(GU_MODEL, &actor->Rot);
	AMG_Scale(GU_MODEL, &actor->Scale);
	actor->Origin.x = -actor->Origin.x; actor->Origin.y = -actor->Origin.y; actor->Origin.z = -actor->Origin.z;
	AMG_Translate(GU_MODEL, &actor->Origin);
	actor->Origin.x = -actor->Origin.x; actor->Origin.y = -actor->Origin.y; actor->Origin.z = -actor->Origin.z;
	AMG_UpdateMatrices();											// Actualiza las matrices
	sceGuColorMaterial(GU_DIFFUSE | GU_SPECULAR | GU_AMBIENT);		// Define los componentes materiales a usar
	sceGuSpecular(AMG.WorldSpecular);	
	
	//MUEVE HUESOS
	int q = 0;
	int n_bones = actor->Object[0].n_bones;
	for( q = 0; q < n_bones; ++q){
		
		//Update rotation
		float f = actor->Object[0].interpolation;

		//Toma la rotacion y posicion del hueso
		gumLoadIdentity(&actor->bones[q]);
		ScePspFVector3 pos = actor->Object[0].Frame[0].Bone[q].position;
		ScePspFVector3 pfix = {-1*pos.x,-1*pos.y,-1*pos.z};
		
		//interpolate quaternion
		//sample_hermite could be the best function, but linear and normalize are 
		//faster and solve the scaling issue when interpolating very different angles
		if (actor->smooth == 0)
			vfpu_quaternion_sample_linear(&actor->Object[0].Frame[frame].Bone[q].interpolated,&actor->Object[0].Frame[frame].Bone[q].orient,&actor->Object[0].Frame[nextframe].Bone[q].orient,f);
		if (actor->smooth == 1)
			vfpu_quaternion_sample_linear(&actor->Object[0].Frame[frame].Bone[q].interpolated,&actor->Object[0].Frame[frame].Bone[q].orient,&actor->Object[0].Frame[nextframe].Bone[q].orient,vfpu_ease_in_out(f));

		vfpu_quaternion_normalize(&actor->Object[0].Frame[frame].Bone[q].interpolated);
		
		//Apply position and rotation to bone matrix
		AMG_TranslateUser(&actor->bones[q], &pos);
		AMG_RotateMatrix_by_quat(&actor->Object[0].Frame[frame].Bone[q].interpolated, &actor->bones[q]);
		AMG_TranslateUser(&actor->bones[q], &pfix);
		
		//Now apply child bones the rotation of the parents
		if (q > 0) {
			int parent = actor->Object[0].Frame[0].Bone[q].parent;
			gumMultMatrix(&actor->bones[q], &actor->bones[parent], &actor->bones[q]);
		}
	}

	actor->Object[0].interpolation += sp;
	
	// setup texture
    AMG_EnableTexture(actor->Object[0].texture);
    sceGuColor(GU_RGBA(255,255,255,0)); 
    sceGuAmbient(GU_RGBA(25,25,25,255));
	
	ScePspFMatrix4 test;
	gumLoadIdentity(&test);
	//Draw groups
	int g = 0;
	int b = 0;
	for (g = 0; g < actor->Object[0].n_groups; g++){ 
		u32 number = actor->Object[0].Group[g].End - actor->Object[0].Group[g].Start;
		u32 offset = actor->Object[0].Group[g].Start;
		//Set bone matrices for every bone in the group... 
		//Max 8 bones in a group
		//You have your model animated!!!
		for( q = 0; q < 8; q++){
			sceGuBoneMatrix( q, &actor->bones[q+b]);
			sceGuMorphWeight( q, 1 );
		}
		//Draw group
		sceGumDrawArray(GU_TRIANGLES,GU_WEIGHTS(8)|GU_NORMAL_32BITF|GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_WEIGHT_32BITF|GU_TRANSFORM_3D,number,0,actor->Object[0].Data+offset);
		//
		b+=8;
	}
    AMG_PopMatrix(GU_MODEL);
	// Control de la iluminación
	if((!actor->Object[0].Lighting) && (l2)) sceGuEnable(GU_LIGHTING);
}			

void AMG_ConfigActor2(AMG_Skinned_Actor *actor,float speed, int smooth){
	actor->Object[0].speed = speed;
	actor->smooth = smooth;

}


/////////////////////////////////////////////
int flip_screen(){
oslEndDrawing(); ///Añadido aquí
oslEndFrame();
oslSyncFrame();
oslStartDrawing(); ///Añadido aquí
sceGuClearColor(0x22222222); ///Añadido aquí
sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT | GU_STENCIL_BUFFER_BIT); ///Añadido aquí
return 0;
}


int main(){

    ///Por defecto OSLIB
	oslInit(1);
	oslInitGfx(GU_PSM_8888,1);
	AMG_Init3D(GU_PSM_8888);	
	
    //AMG_SetCpuSpeed(333);	

    AMG_Light[0].Type = GU_DIRECTIONAL; //GU_POINTLIGHT;
	AMG_Light[0].Diffuse = GU_RGBA(250, 250, 250, 0x0F);
	AMG_Light[0].Specular = GU_RGBA(180, 180, 180, 0x0F);
	AMG_Light[0].Ambient = GU_RGBA(90, 90, 90, 0x0F);
	AMG_Light[0].Pos.x = 1.0f;
	AMG_Light[0].Pos.y = 1.0f;
	AMG_Light[0].Pos.z = 1.0f;
	
	// Crea una camara

    AMG_Camera *camera = AMG_InitCamera();
	camera->Pos.x = 0.0f;
	camera->Pos.y = 2.0f;
	camera->Pos.z = 15.0f;
	camera->Eye.y = 2.0f;

	// load
	AMG_Skinned_Actor* Plant = AMG_LoadSkinnedActor("plant.o3m");
	AMG_ConfigActor2(Plant,70,1);
	AMG_Skinned_Actor* Homer = AMG_LoadSkinnedActor("homer.o3m");
	AMG_ConfigActor2(Homer,40,1);
	//AMG_Model *Cube = AMG_LoadModel("Animations2.obj",0);
		
    AMG_InitMatrixSystem(45.0f);
	
	float ram1 = oslGetRamStatus().maxAvailable /1024/1024;
	while(1){

	    AMG_Begin3D();
		
		AMG_SetCamera(camera);
	
        AMG_EnableLight(0);	
			AMG_RenderSkinnedActor(Homer);
			AMG_RenderSkinnedActor(Plant);
		AMG_DisableLight(0);
		
		Homer->Pos.x = 3;
		Plant->Pos.x = -3;

		AMG_OrthoMode(1);
			oslPrintf_xy(10,10,"Homer Tris %i",Homer->Object[0].polyCount);
			oslPrintf_xy(10,20,"Homer Bones %i",Homer->Object[0].n_bones); 
			oslPrintf_xy(10,30,"Homer Frames %i",Homer->Object[0].frameCount);
			oslPrintf_xy(10,60,"Plant Tris %i",Plant->Object[0].polyCount);
			oslPrintf_xy(10,70,"Plant Bones %i",Plant->Object[0].n_bones); 
			oslPrintf_xy(10,80,"Plant Frames %i",Plant->Object[0].frameCount);
			oslPrintf_xy(10,100,"Free Ram %f",ram1);
		AMG_OrthoMode(0);		
		
		AMG_Update3D();
		///FLIP
        flip_screen();
		
		oslReadKeys();
		
		if (osl_keys->held.circle) Homer->Rot.y+=0.01; //turn
		if (osl_keys->held.circle) Plant->Rot.y+=0.01; 

        if (osl_keys->pressed.triangle)oslQuit();
	}
	return 0;
}
# This script is licensed as public domain.
# Export models for use in ONELua for PSP.

bl_info = {
	"name": "ONELua",
	"author": "Mills",
	"version": (2017, 6, 3),
	"blender": (2, 7, 4),
	"location": "File > Export > ONELua ",
	"description": "ONELUA",
	"warning": "",
	"wiki_url": "",
	"tracker_url": "",
	"category": "Import-Export"}

import os, struct, math
import mathutils
import bpy
import bpy_extras.io_utils

error0 = 0
error1 = 0
error2 = 0
error3 = 0
error4 = 0

def exportO3M(context, filename):
	currentScene = bpy.context.scene
	bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
	file = open(filename, 'w')

	#get selected objects
	obj = bpy.context.selected_objects
	
	#set variables
	triangle_number = 0
	mesh_number = 0
	armature = None
	bone_number = 0
	frame = 0
	
	#this stores vertices assigned to a maximum of 32 bones (8*4) 
	#split in 4 parts, do not share vertices between parts!!!
	DATA = [[],[],[],[]]
	
	#apply transformations to meshes
	bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
	
	#iterate selected meshes
	for obj in context.selected_objects:
		obj.data.calc_normals_split()
		obj.data.update(calc_edges=True, calc_tessface=True)
		i = 0
		mesh = obj.data
		armature = obj.find_armature()
		#error0
		if armature == None: 
			error0 = 1
			return

		for face in obj.data.polygons:
			triangle_number = triangle_number + 1

		#error1
		#if bone_number > 32: 
		#	error1 = 1
		#	return
		facex = 0
		vertex = 0
		for face in obj.data.polygons:
			for vert, loop in zip(face.vertices, face.loop_indices):
				DATA[mesh_number].append(obj.data.vertices[vert].co[0])
				DATA[mesh_number].append(obj.data.vertices[vert].co[1])
				DATA[mesh_number].append(obj.data.vertices[vert].co[2])
				DATA[mesh_number].append(obj.data.uv_layers.active.data[loop].uv[0])
				DATA[mesh_number].append(obj.data.uv_layers.active.data[loop].uv[1])
				#get custom normals
				normal = obj.data.tessfaces[facex].split_normals[vertex]
				DATA[mesh_number].append(normal[0])
				DATA[mesh_number].append(normal[1])
				DATA[mesh_number].append(normal[2])
				for item in obj.data.vertices[vert].groups:
					bmatrix_number = item.group - (mesh_number*8);
					#error2
					#if bmatrix_number > 7: 
					#	error2 = 1
					#return
					DATA[mesh_number].append(bmatrix_number)
				i = i+9
				vertex = vertex + 1
				if vertex == 3:
					vertex = 0
			facex = facex + 1
		mesh_number = mesh_number + 1
	
	currentScene.frame_set(0)
	#get animation range
	startFrame = int(armature.animation_data.action.frame_range.x)
	endFrame = int(armature.animation_data.action.frame_range.y)
	for bone in armature.pose.bones:
		bone_number = bone_number + 1
	
	#----------
	#Write file
	#----------
	
	file.write('#-----------------------------------------------------\n')
	file.write('# Onelua 3D Model\n# For Onelua Play Station Portable\n')
	file.write('#-----------------------------------------------------\n')
	file.write('# Use included plugin to export form blender, or use whatever you want...\n')
	file.write('# Just be sure to generate this file structure.\n\n')
	file.write('#-----------------------------------------------------\n\n')
	
	#write triangles (PSP will like it)
	file.write('mesh\n\n')
	file.write('ntris %d\n' % (triangle_number))
	file.write('nbones %d\n' % (bone_number))
	file.write('nframes %d\n' % (armature.animation_data.action.frame_range.y+1))
	file.write('-data - X Y Z - U V - NX NY NZ - BONE\n')
	
	i = 0
	j = 0
	while j < len(DATA):
		if len(DATA[j]) > 0: 
			file.write('\tnsplit\n')
			while i < len(DATA[j]):
				file.write('v %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %i\n' % (DATA[j][i],DATA[j][i+1],DATA[j][i+2],DATA[j][i+3],DATA[j][i+4],DATA[j][i+5],DATA[j][i+6],DATA[j][i+7],DATA[j][i+8]))
				i = i+9
		j = j + 1
		i = 0
	file.write('-end_data\n')
	file.write('\n')
	file.write('-animation\n\n')
	file.write('bones\n')
	
	#write bone list and their parents
	currentScene.frame_set(0)
	x = 0
	y = 0
	for bone in armature.pose.bones:
		#if bone.name == i:
		bonen = x
		if bone.parent: #get parent number
			y = 0
			for b in armature.pose.bones:
				if b.name == bone.parent.name:
					parent = y
				y = y + 1
		else:
			parent = -1
		file.write('bn %i %i\n' % (bonen,parent))
		x = x + 1
		
	#write bone head positions and rotations for all frames
	obj.rotation_mode = 'QUATERNION'
	for frame in range(startFrame, endFrame+1, 1):
		currentScene.frame_set(frame)
		file.write('\nbframe (pose) POS XYZ - QUATERNION XYZW %d\n' % (frame))
		#for i in BONENAMES:
		for bone in armature.pose.bones:
			#if bone.name == i:
			bonen = bone.name
			bonepos = obj.matrix_world.inverted() * bone.head
			bonerot = bone.rotation_quaternion
			rott = bonerot.to_axis_angle()
			file.write('pf %.6f %.6f %.6f %.6f %.6f %.6f %.6f\n' % (bonepos.x,bonepos.z,-bonepos.y,-bonerot.x,-bonerot.y,-bonerot.z,bonerot.w))
		file.write('x\n')
	file.write('-end_animation\n\n')
	currentScene.frame_set(0)
	file.close()
	file = None;

	
class ExportO3M(bpy.types.Operator, bpy_extras.io_utils.ExportHelper):
	'''ONELua'''
	bl_idname = "export.o3m"
	bl_label = 'O3M'
	filename_ext = ".o3m"

	def execute(self, context):
		exportO3M(context, self.properties.filepath)
		if error0 == 1:
			self.report({'ERROR_INVALID_INPUT'}, "No armature found")
		if error1 == 1:
			self.report({'ERROR_INVALID_INPUT'}, "Too much bones, only 32")
		if error2 == 1:
			self.report({'ERROR_INVALID_INPUT'}, "A group has more than 8 bones")
		if error3 == 1:
			self.report({'ERROR_INVALID_INPUT'}, "Some vertices have more than one bone assigned")
		if error4 == 1:
			self.report({'ERROR_INVALID_INPUT'}, "CONSUELA: Noo no, is to much bones... Only 28... no")
			
		self.report({'ERROR_INVALID_INPUT'}, "FINISHED")
		return {'FINISHED'}

	def check(self, context):
		filepath = bpy.path.ensure_ext(self.filepath, '.o3m')
		return False

def menu_func(self, context):
	self.layout.operator(ExportO3M.bl_idname, text="ONELua")

def register():
	bpy.utils.register_module(__name__)
	bpy.types.INFO_MT_file_export.append(menu_func)

def unregister():
	bpy.utils.unregister_module(__name__)
	bpy.types.INFO_MT_file_export.remove(menu_func)

if __name__ == "__main__":
	register()


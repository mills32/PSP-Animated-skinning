// Includes
#include "AMG_Multimedia.h"
#include "AMG_3D.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <psputility.h>
#include <pspatrac3.h>

#ifndef AMG_COMPILE_ONELUA

// Estructura de 4 canales
typedef struct{
	AMG_SOUND *Data;
	int ID;
	int ThreadID;
	u16 *AudioBuffer;	// <-- Solo MP3
	u16 Volume;
}AMG_Channel;
AMG_Channel *AMG_AudioSystem;
u8 AMG_AudioEnd = 1;

int amg_at3callback(SceSize args, void *argp){
	while(!AMG_AudioEnd){
		// Obt�n el canal
		int ch = *(int*)argp;
		AMG_SOUND *snd = AMG_AudioSystem[ch].Data;
		if((ch < 8) && (snd->Play)){
			// Decodifica el audio
			snd->E = (snd->E+1) % 16;
			snd->NSamples = 0;
			int end = 0;
			int rem = -1;
			int res = sceAtracDecodeData(snd->AtracID, &snd->OutputBuffer[8192*snd->E], (int*)&snd->NSamples, &end, &rem);
			if (res < 0 || end) snd->Play = 0;		
			// Reproduce el audio
			snd->S = (snd->S + 1) % 16;
			sceAudioOutputBlocking(AMG_AudioSystem[ch].ID, AMG_AudioSystem[ch].Volume, &snd->OutputBuffer[8192*snd->S]);
		}else{
			sceAudioOutputBlocking(AMG_AudioSystem[ch].ID, 0, snd->OutputBuffer);
		}
	}
	
	sceKernelExitThread(0);
	return 0;
}

// Convierte fixed point a s16
s16 MadFixedToSshort(mad_fixed_t Fixed){
    // Comprueba los l�mites
    if (Fixed >= MAD_F_ONE) return (SHRT_MAX);
    if (Fixed <= -MAD_F_ONE) return (-SHRT_MAX);
    // Quita la parte decimal
    Fixed = Fixed >> (MAD_F_FRACBITS - 15);
    return ((signed short) Fixed);
}

void mp3_cb(AMG_SOUND *snd, u8 ch){
	// Obt�n el buffer de audio
	short *_buf = (short*)AMG_AudioSystem[ch].AudioBuffer;
	unsigned long samplesOut = 0;
	
	// Si hay samples listos...
	if (snd->OutputSamples > 0){
		if ((u32)snd->OutputSamples > snd->NSamples) {
			memcpy(_buf, snd->OutputBuffer, snd->NSamples * 4);
			samplesOut = snd->NSamples;
			snd->OutputSamples -= snd->NSamples;
		} else {
			memcpy(_buf, snd->OutputBuffer, snd->OutputSamples * 4);
			samplesOut = snd->OutputSamples;
			snd->OutputSamples = 0;
		}
	}
	
	// Llenamos el buffer con samples
	while (samplesOut < snd->NSamples) {
		if (snd->Stream.buffer == NULL || snd->Stream.error == MAD_ERROR_BUFLEN) {
			mad_stream_buffer(&snd->Stream, snd->Data, snd->DataSize);		// Asignamos un buffer de datos
			snd->Stream.error = (mad_error)0;
		}
			
		// Decodifica el frame actual
		if(mad_frame_decode(&snd->Frame, &snd->Stream)) {
			if (MAD_RECOVERABLE(snd->Stream.error)) {				// Error (pero se puede seguir)
				return;
			} else if (snd->Stream.error == MAD_ERROR_BUFLEN) {		// Fin del archivo
				if(snd->Loop != 0){
					mad_timer_reset(&snd->Timer);
				}else{
					snd->Play = 0;
				}
				return;
			} else {
				AMG_Error(AMG_CUSTOM_ERROR, 0, "Error while decoding MP3 data"); return;
			}
		}
					
		// Especifica el contador
		mad_timer_add(&snd->Timer, snd->Frame.header.duration);

		// Aqu� se pueden aplicar filtros de sonido

		// Obt�n los datos PCM
		mad_synth_frame(&snd->Synth, &snd->Frame);
						
		// Mete los datos en el buffer de audio
		for (int i = 0; i < snd->Synth.pcm.length; i++) {
			s16 Sample;
			if (samplesOut < snd->NSamples) {
				// Altavoz izquierdo
				Sample = MadFixedToSshort(snd->Synth.pcm.samples[0][i]);
				_buf[samplesOut * 2] = Sample;
				// Altavoz derecho
				if (MAD_NCHANNELS(&snd->Frame.header) == 2)
					Sample = MadFixedToSshort(snd->Synth.pcm.samples[1][i]);
				_buf[samplesOut * 2 + 1] = Sample;
				samplesOut++;
			} else {
				// Altavoz izquierdo
				Sample = MadFixedToSshort(snd->Synth.pcm.samples[0][i]);
				snd->OutputBuffer[snd->OutputSamples * 2] = Sample;
				// Altavoz derecho
				if (MAD_NCHANNELS(&snd->Frame.header) == 2)
					Sample = MadFixedToSshort(snd->Synth.pcm.samples[1][i]);
				snd->OutputBuffer[snd->OutputSamples * 2 + 1] = Sample;
				snd->OutputSamples++;
			}
		}
	}
}

int amg_mp3callback(SceSize args, void *argp){
	while(!AMG_AudioEnd){
		int ch = *(int*)argp;
		AMG_SOUND *snd = AMG_AudioSystem[ch].Data;
		u16 vol = AMG_AudioSystem[ch].Volume;
		if((ch < 8) && (snd->Play)){
			mp3_cb(snd, ch);
		}else{
			vol = 0;
		}
		sceAudioOutputBlocking(AMG_AudioSystem[ch].ID, vol, AMG_AudioSystem[ch].AudioBuffer);
	}
	
	sceKernelExitThread(0);
	return 0;
}

// Inicializa el motor multimedia
void AMG_InitMultimedia(void){
	if(AMG.MultimediaInited) return;
	if(sceUtilityLoadAvModule(PSP_AV_MODULE_AVCODEC) < 0){ AMG_Error(AMG_MODULE_INIT, -1, "PSP_MODULE_AV_AVCODEC"); return;}
	AMG.MultimediaInited = true;
}

// Acaba con el motor multimedia
void AMG_FinishMultimedia(void){
	if(!AMG.MultimediaInited) return;
	sceUtilityUnloadAvModule(PSP_AV_MODULE_AVCODEC);
	AMG.MultimediaInited = false;
}

// Inicializa el motor de audio
void AMG_InitAudio(void){
	// Carga los m�dulos necesarios
	AMG_InitMultimedia();
	sceUtilityLoadAvModule(PSP_AV_MODULE_ATRAC3PLUS);
	// Inicializa el motor de audio
	AMG_AudioSystem = (AMG_Channel*) calloc (8, sizeof(AMG_Channel));
	for(u8 i=0;i<8;i++) AMG_AudioSystem[i].Volume = 0x8000;
	AMG_AudioEnd = 0;
}

// Finaliza el motor de audio
void AMG_FinishAudio(void){
	// Finaliza el audio
	AMG_AudioEnd = 1;
	// Elimina los plugins
	sceUtilityUnloadAvModule(PSP_AV_MODULE_ATRAC3PLUS);
}

// Carga un MP3 en RAM
AMG_SOUND *AMG_LoadSoundMP3(const char *path){
	// Crea el MP3
	AMG_SOUND *snd = (AMG_SOUND*) calloc (1, sizeof(AMG_SOUND));
	if(snd == NULL) return NULL;
	snd->Play = 0;
	snd->Type = AMG_SOUND_MP3;
	// Carga el archivo en RAM
	FILE *f = fopen(path, "rb");
	if(f == NULL){ AMG_Error(AMG_OPEN_FILE, 0, path); return NULL;}
	fseek(f, 0, SEEK_END);
	snd->DataSize = ftell(f);
	rewind(f);
	snd->Data = (u8*) calloc (snd->DataSize, sizeof(u8));
	if(snd->Data == NULL){ AMG_Error(AMG_OUT_OF_RAM, snd->DataSize, "AMG_LoadSoundMP3"); return NULL;}
	fread(snd->Data, snd->DataSize, 1, f);
	fclose(f); f = NULL;
	// Crea los datos para libMAD
	mad_stream_init(&snd->Stream);
	mad_frame_init(&snd->Frame);
	mad_synth_init(&snd->Synth);
	mad_timer_reset(&snd->Timer);
	snd->OutputBuffer = (u16*) calloc (2048, sizeof(u16));
	if(snd->OutputBuffer == NULL){ AMG_Error(AMG_OUT_OF_RAM, 4096, "AMG_LoadSoundMP3"); return NULL;}
	snd->NSamples = 1152;
	// Devuelve el archivo cargado
	return snd;
}

// Carga un AT3
AMG_SOUND *AMG_LoadSoundAT3(const char *path){
	// Crea el MP3
	AMG_SOUND *snd = (AMG_SOUND*) calloc (1, sizeof(AMG_SOUND));
	if(snd == NULL) return NULL;
	snd->Play = 0;
	snd->Type = AMG_SOUND_AT3;
	// Carga el archivo en RAM
	FILE *f = fopen(path, "rb");
	if(f == NULL){ AMG_Error(AMG_OPEN_FILE, 0, path); return NULL;}
	fseek(f, 0, SEEK_END);
	snd->DataSize = ftell(f);
	rewind(f);
	snd->Data = (u8*) calloc (snd->DataSize, sizeof(u8));
	if(snd->Data == NULL){ AMG_Error(AMG_OUT_OF_RAM, snd->DataSize, "AMG_LoadSoundAT3"); return NULL;}
	fread(snd->Data, snd->DataSize, 1, f);
	fclose(f); f = NULL;
	// Crea datos AT3
	snd->AtracID = sceAtracSetDataAndGetID(snd->Data, snd->DataSize);
	if(snd->AtracID < 0) AMG_Error(AMG_MODULE_EXCEPTION, snd->AtracID, "sceAtracSetDataAndGetID");
	sceAtracGetMaxSample(snd->AtracID, (int*)&snd->NSamples);
	sceAtracSetLoopNum(snd->AtracID, 0);
	snd->OutputBuffer = (u16*) calloc (131072, sizeof(u16));	// 256KB
	if(snd->OutputBuffer == NULL){ AMG_Error(AMG_OUT_OF_RAM, 262144, "AMG_LoadSoundAT3"); return NULL;}
	// Devuelve el archivo cargado
	return snd;
}

// Establece el sonido a un canal
void AMG_SetChannelSound(AMG_SOUND *snd, u8 channel){
	if((channel > 7) || (snd == NULL)) return;
	// Crea el thread para este canal
	char name[16];
	sprintf(name, "AMG_Audio%d", channel);
	if(snd->Type == AMG_SOUND_MP3){
		AMG_AudioSystem[channel].ThreadID = sceKernelCreateThread(name, amg_mp3callback, 0x11, 0xFA0, 0, 0);
		AMG_AudioSystem[channel].AudioBuffer = (u16*) calloc (snd->NSamples*2, sizeof(u16));
	}else{
		AMG_AudioSystem[channel].ThreadID = sceKernelCreateThread(name, amg_at3callback, 0x11, 0xFA0, 0, 0);
	}
	if(!AMG_AudioSystem[channel].ThreadID){ AMG_Error(AMG_CUSTOM_ERROR, 0, "Couldn't create channel %d", channel); return;}
	AMG_AudioSystem[channel].ID = sceAudioChReserve(channel, snd->NSamples, 0);
	int *ch = (int*) calloc (1, sizeof(int));
	ch[0] = (int)channel;
	// Enlaza el sonido a este canal
	AMG_AudioSystem[channel].Data = snd;
	// Comienza el thread
	sceKernelStartThread(AMG_AudioSystem[channel].ThreadID, sizeof(int), ch);
}

// Establece el volumen de un canal
void AMG_SetChannelVolume(u8 channel, u16 vol){
	if(channel > 7) return;
	AMG_AudioSystem[channel].Volume = vol;
}

// Quita el sonido de un canal
void AMG_FreeChannelSound(u8 channel){
	if(channel > 7) return;
	
}

// Elimina un sonido
void AMG_UnloadSound(AMG_SOUND *snd){
	if(snd == NULL) return;
	// Elimina los datos
	if(snd->Data) free(snd->Data);
	if(snd->OutputBuffer) free(snd->OutputBuffer);
	// Elimina datos de libMAD
	if(snd->Type == AMG_SOUND_MP3){
		mad_synth_finish(&snd->Synth);
		mad_frame_finish(&snd->Frame);
		mad_stream_finish(&snd->Stream);
	}else{
		sceAtracReleaseAtracID(snd->AtracID);
	}
}

// Detiene un sonido
void AMG_StopSound(AMG_SOUND *snd){
	if(snd == NULL) return;
	snd->Play = 0;
	if(snd->Type == AMG_SOUND_MP3){
		mad_timer_reset(&snd->Timer);
	}else{
		
	}
}

// Establece el loop de un sonido
void AMG_SetSoundLoop(AMG_SOUND *snd, u8 loop){
	if(snd == NULL) return;
	snd->Loop = loop;
	if(snd->Type == AMG_SOUND_AT3){
		sceAtracSetLoopNum(snd->AtracID, loop);
	}
}

#endif

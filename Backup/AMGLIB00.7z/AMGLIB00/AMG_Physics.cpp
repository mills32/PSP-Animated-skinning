// Includes
#include "AMG_Physics.h"
#include "AMG_User.h"
#include <stdio.h>
#include <pspgum.h>
#include "AMG_3D.h"

#ifdef AMG_ADDON_BULLET

// Includes BULLET
#include <LinearMath/btVector3.h>
#include <LinearMath/btMatrix3x3.h>
#include <LinearMath/btTransform.h>
#include <LinearMath/btQuickprof.h>
#include <LinearMath/btAlignedObjectArray.h>
#include <btBulletDynamicsCommon.h>
#include <BulletCollision/CollisionShapes/btShapeHull.h>
#include "BulletSoftBody/btSoftBody.h"
#include "BulletSoftBody/btSoftRigidDynamicsWorld.h"
#include "BulletSoftBody/btSoftBodyRigidBodyCollisionConfiguration.h"
#include "BulletSoftBody/btSoftBodyHelpers.h"

// Objetos principales
/*btDynamicsWorld**/btSoftRigidDynamicsWorld* AMG_DynamicWorld;
btBroadphaseInterface* AMG_WorldBroadphase;
btCollisionDispatcher* AMG_WorldDispatcher;
btConstraintSolver*	AMG_PhysicsSolver;
btDefaultCollisionConfiguration* AMG_CollisionConfiguration;

//for soft bodies
btSoftBodyWorldInfo	m_softBodyWorldInfo;
btSoftBody::Node* m_node;

typedef struct{
	AMG_Object *md;
	btRigidBody *Body;
	btSoftBody *SoftBody;
	btCollisionShape *Shape;
	btRaycastVehicle *m_vehicle;
	btVehicleRaycaster *m_vehicleRayCaster;
	btTypedConstraint *BallConstraint;
	btHingeConstraint *HingeConstraint;
	btTransform Transform;
	btVector3 Inertia;
	// Datos adicionales (btConvexHullShape)
	u32 ConvexVertices;
	btTriangleMesh *tri;
	btConvexShape *sh;
	btShapeHull *hull;
	int type; //0 = rigid; 1 = soft; 2 = Vehicle
	//Physics parameters
	float	wheelRadius;
	float	wheelWidth;
	float	wheelFriction;
	float	WheelsXDist;
	float	WheelsZDist;
	float	suspensionStiffness;//Rigidez de amortiguación
	float	suspensionDamping;//Valor de amortiguación
	float	suspensionCompression;//Fuerza de amortiguadores
	float	suspensionRestLength;//Longitud de amortiguador en reposo
	float	connectionHeight;//Altura de los ejes respecto al chasis
}amg_mdh;
amg_mdh *amg_model_ptr = NULL;
u32 amg_max_objects = 0;

// Funciones locales
void amg_get_position(amg_mdh *obj, ScePspFVector3 &pos);
void amg_save_object_stack(AMG_Object *md);
void amg_set_position(amg_mdh *obj, ScePspFVector3 &pos);

// Callback de BULLET
bool amg_bcallback(btManifoldPoint &cp, const btCollisionObjectWrapper *obj1, int id0, int idx0, const btCollisionObjectWrapper *obj2, int id1, int idx1){
	AMG_Object *o1 = (AMG_Object*) obj1->getCollisionObject()->getUserPointer();
	AMG_Object *o2 = (AMG_Object*) obj2->getCollisionObject()->getUserPointer();
	o1->Collision = true;
	o2->Collision = true;
	o1->CollideWith = o2->bullet_id;
	o2->CollideWith = o1->bullet_id;
	return false;
}
btVector3 AMG_world[2];
// Inicializa el motor BULLET
void AMG_InitBulletPhysics(ScePspFVector3 *world_size, u32 max_objects){
	if(world_size){
		AMG_world[0] = btVector3(world_size[0].x, world_size[0].y, world_size[0].z);
		AMG_world[1] = btVector3(world_size[1].x, world_size[1].y, world_size[1].z);
	}
	AMG_CollisionConfiguration = new btDefaultCollisionConfiguration();
	AMG_WorldDispatcher = new btCollisionDispatcher(AMG_CollisionConfiguration);
	m_softBodyWorldInfo.m_dispatcher = AMG_WorldDispatcher;
	if(world_size) AMG_WorldBroadphase = new btAxisSweep3(AMG_world[0], AMG_world[1], max_objects);
	else AMG_WorldBroadphase = new btDbvtBroadphase();
	AMG_PhysicsSolver = new btSequentialImpulseConstraintSolver();
	m_softBodyWorldInfo.m_broadphase = AMG_WorldBroadphase;
	AMG_DynamicWorld = new btSoftRigidDynamicsWorld/*btDiscreteDynamicsWorld*/(AMG_WorldDispatcher, AMG_WorldBroadphase, AMG_PhysicsSolver, AMG_CollisionConfiguration);
	AMG_DynamicWorld->setGravity(btVector3(0.0f, -9.8f, 0.0f));		// Gravedad por defecto (la terrestre)
	m_softBodyWorldInfo.m_gravity.setValue(0,-9.8,0);
	m_softBodyWorldInfo.m_sparsesdf.Initialize();
	// Crea la pila de modelos 3D
	amg_model_ptr = (amg_mdh*) calloc (max_objects, sizeof(amg_mdh));
	amg_max_objects = max_objects;
	for(u32 i=0;i<amg_max_objects;i++){
		amg_model_ptr[i].md = NULL;
	}
	// Establece el callback de colisión
	//gContactAddedCallback = amg_bcallback;
}

// Establece la gravedad del mundo simulado
void AMG_SetWorldGravity(float x, float y, float z){
	AMG_DynamicWorld->setGravity(btVector3(x, y, z));
}

// Haz un test de Ray Tracing
u8 AMG_RayTracingTest(ScePspFVector3 *pos, ScePspFVector3 *vec){
	u8 c=0;
	btCollisionWorld::ClosestRayResultCallback cb(btVector3(pos->x, pos->y, pos->z), btVector3(vec->x, vec->y, vec->z));
	AMG_DynamicWorld->rayTest(btVector3(pos->x, pos->y, pos->z), btVector3(vec->x, vec->y, vec->z), cb);
	c = cb.hasHit();		// Nos dice si el rayo ha chocado con algo
	if(c){
		AMG_Object *o = (AMG_Object*)(cb.m_collisionObject->getUserPointer());
		o->Collision = true;
		o->CollideWith = AMG_COLLISION_RAY;
	}
	return c;
}

// Inicializa las fisicas de un modelo 3D
void AMG_InitModelPhysics(AMG_Model *model){
	for(u8 i=0;i<model->NObjects;i++){
		if(model->Object[i].ShapeType == AMG_BULLET_SHAPE_NONE) continue;
		// Guarda el objeto en la pila
		amg_save_object_stack(&model->Object[i]);
		// Obtén el objeto
		amg_mdh *obj = &amg_model_ptr[model->Object[i].bullet_id];
		// Calcula los márgenes
		float x, y, z;
		x = ((model->Object[i].BBox[1].x - model->Object[i].BBox[0].x)/2.0f)*model->Object[i].Scale.x;
		y = ((model->Object[i].BBox[1].y - model->Object[i].BBox[0].y)/2.0f)*model->Object[i].Scale.y;
		z = ((model->Object[i].BBox[1].z - model->Object[i].BBox[0].z)/2.0f)*model->Object[i].Scale.z;
		// Según el tipo de objeto que sea...
		switch(model->Object[i].ShapeType){
			case AMG_BULLET_SHAPE_BOX:
				obj->Shape = new btBoxShape(btVector3(btScalar(x), btScalar(y), btScalar(z)));
				break;
			case AMG_BULLET_SHAPE_SPHERE:
				obj->Shape = new btSphereShape(x);
				break;
			case AMG_BULLET_SHAPE_CONE:
				model->Object[i].Origin.y -= y;
				obj->Shape = new btConeShape(x, y*2.0f);
				break;
			case AMG_BULLET_SHAPE_CYLINDER:
				obj->Shape = new btCylinderShape(btVector3(x, y, z));
				break;
			case AMG_BULLET_SHAPE_CONVEXHULL:
			{
				// Guarda los triángulos en un buffer
				obj->tri = new btTriangleMesh();
				for(u32 a=0;a<(model->Object[i].NFaces);a++){
					ScePspFVector3 *t = &(((ScePspFVector3*)model->Object[i].Triangles)[a*3]);
					obj->tri->addTriangle(btVector3(t[0].x, t[0].y, t[0].z),
										  btVector3(t[1].x, t[1].y, t[1].z),
										  btVector3(t[2].x, t[2].y, t[2].z));
				}
				
				// Crea el Convex Hull
				if(model->Object[i].isGround){
					btBvhTriangleMeshShape *trimesh = new btBvhTriangleMeshShape(obj->tri, false);
					//trimesh->buildOptimizedBvh();
					obj->Shape = trimesh;
				}else{
					obj->sh = new btConvexTriangleMeshShape(obj->tri);
					obj->hull = new btShapeHull(obj->sh);
					obj->hull->buildHull(obj->sh->getMargin());
					obj->sh->setUserPointer(obj->hull);
					btConvexHullShape *convexHull = new btConvexHullShape((btScalar*)obj->hull->getVertexPointer(), obj->hull->numVertices());
					//convexHull->initializePolyhedralFeatures();
					obj->ConvexVertices = obj->hull->numVertices();
					obj->Shape = convexHull;
				}
				
				// Configura la escala
				obj->Shape->setLocalScaling(btVector3(model->Object[i].Scale.x, model->Object[i].Scale.y, model->Object[i].Scale.z));
			} break;
			default: AMG_Error(AMG_CUSTOM_ERROR, 0, "Undefined BULLET shape type"); return;
		}
		obj->Transform.setIdentity();
		obj->Transform.setOrigin(btVector3(model->Object[i].Pos.x, model->Object[i].Pos.y, model->Object[i].Pos.z));
		btDefaultMotionState* MotionState = new btDefaultMotionState(obj->Transform);
		obj->Inertia = btVector3(0.0f, 0.0f, 0.0f);
		if(model->Object[i].Mass > 0.0f) obj->Shape->calculateLocalInertia(model->Object[i].Mass, obj->Inertia);
		obj->Body = new btRigidBody(model->Object[i].Mass, MotionState, obj->Shape, obj->Inertia);
		AMG_DynamicWorld->addRigidBody(obj->Body);
		if(!model->Object[i].isGround) obj->Body->activate();		// Activa el objeto
		// Establece el Callback
		obj->Body->setCollisionFlags(obj->Body->getCollisionFlags() | btCollisionObject::CF_CUSTOM_MATERIAL_CALLBACK);
		obj->Body->setUserPointer(&model->Object[i]);
		// Corrige el centro de rotación si es un cono
		if(model->Object[i].ShapeType == AMG_BULLET_SHAPE_CONE) model->Object[i].Origin.y += y;
	
		obj->Body->setDamping(0.1,0.1);
		//obj->Body->setFriction(0.2);
		//obj->Body->setRollingFriction(0.1);
		//obj->Body->setRestitution(0.1);
		model->Object[i].Physics = 1;
		obj->type = 0; //Rigid
	}
}

// Inicializa las fisicas de un actor 3D
void AMG_InitActorPhysics(AMG_Actor *actor, float mass){

	AMG_Model *model = NULL;
	model = (AMG_Model*) calloc (1, sizeof(AMG_Model));
	model->Object = (AMG_Object*) calloc (1, sizeof(AMG_Object));
	actor->Object[0].Mass = mass;
	
	AMG_ObjectConfPhysics(&model->Object[0], 0, 0, 0, 0, 0, 0, mass, AMG_BULLET_SHAPE_SPHERE);
	// Guarda un objeto en la pila
	amg_save_object_stack(&model->Object[0]);
	// Obtén el objeto
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	
	// Calcula los márgenes
	float x, y, z;
	x = ((actor->Object[0].BBox[1].x - actor->Object[0].BBox[0].x)/2.0f)*actor->Scale.x;
	y = ((actor->Object[0].BBox[1].y - actor->Object[0].BBox[0].y)/2.0f)*actor->Scale.y;
	z = ((actor->Object[0].BBox[1].z - actor->Object[0].BBox[0].z)/2.0f)*actor->Scale.z;
	//Siempre una esfera
	obj->Shape = new btSphereShape(x);
	
	obj->Transform.setIdentity();
	obj->Transform.setOrigin(btVector3(actor->Pos.x, actor->Pos.y, actor->Pos.z));
	btDefaultMotionState* MotionState = new btDefaultMotionState(obj->Transform);
	obj->Inertia = btVector3(0.0f, 0.0f, 0.0f);
	if(actor->Object[0].Mass > 0.0f) obj->Shape->calculateLocalInertia(actor->Object[0].Mass, obj->Inertia);
	obj->Body = new btRigidBody(actor->Object[0].Mass, MotionState, obj->Shape, obj->Inertia);
	AMG_DynamicWorld->addRigidBody(obj->Body);
	obj->Body->activate();		// Activa el objeto
	// Establece el Callback
	obj->Body->setCollisionFlags(obj->Body->getCollisionFlags() | btCollisionObject::CF_CUSTOM_MATERIAL_CALLBACK);
	obj->Body->setUserPointer(&model->Object);
	
	actor->Object[0].phys = 1;
	actor->Object[0].bullet_id = model->Object[0].bullet_id;
	
	//SET ORIGIN POS
	amg_model_ptr[model->Object[0].bullet_id].md->Pos = actor->Pos;
	obj->Body->setDamping(0,1);
	obj->Body->setFriction(1);
	obj->Body->setRollingFriction(1);
	obj->Body->setRestitution(0);
}

// Quita un modelo 3D de la pila
void AMG_DeleteModelPhysics(AMG_Model *model){
	for(u8 i=0;i<model->NObjects;i++){		// Elimina de Bullet cada objeto 3D
		if(model->Object[i].ShapeType == AMG_BULLET_SHAPE_NONE) return;
		amg_mdh *obj = &amg_model_ptr[model->Object[i].bullet_id];
		// Elimina datos adicionales
		if(obj->tri) delete obj->tri;
		if(obj->sh) delete obj->sh;
		if(obj->hull) delete obj->hull;
		// Eliminalos del motor Bullet
		AMG_DynamicWorld->removeRigidBody(obj->Body);
		delete obj->Body; obj->Body = NULL;
		delete obj->Shape; obj->Shape = NULL;
		model->Object[i].Mass = 0.0f; model->Object[i].isGround = 0;
		// Quitalos de la pila
		amg_model_ptr[model->Object[i].bullet_id].md = NULL;
		model->Object[i].bullet_id = 0;
	}
}

// Quita un Actor 3D de la pila
void AMG_DeleteActorPhysics(AMG_Actor *actor){

	amg_mdh *obj = &amg_model_ptr[actor->Object[0].bullet_id];
	// Elimina datos adicionales
	if(obj->tri) delete obj->tri;
	if(obj->sh) delete obj->sh;
	if(obj->hull) delete obj->hull;
	// Eliminalos del motor Bullet
	AMG_DynamicWorld->removeRigidBody(obj->Body);
	delete obj->Body; obj->Body = NULL;
	delete obj->Shape; obj->Shape = NULL;
	actor->Object[0].Mass = 0.0f;
	// Quitalos de la pila
	amg_model_ptr[actor->Object[0].bullet_id].md = NULL;
	actor->Object[0].bullet_id = 0;
}

void AMG_UpdateBody(AMG_Object *model){
	btQuaternion __attribute__((aligned(64))) q;
	ScePspQuatMatrix __attribute__((aligned(64))) q2;
	btVector3 center;
	
	amg_mdh *obj = &amg_model_ptr[model->bullet_id];
	//If rigid body 
	if (obj->type == 0){
		obj->Body->activate();
		center = obj->Body->getWorldTransform().getOrigin();
		memcpy(&model->Pos,&center,sizeof(ScePspFVector3));
		q = obj->Body->getOrientation();
		q2.x = q[0]; q2.y = q[1]; q2.z = q[2]; q2.w = -q[3];//WHY!!! -q[3] ? two days to realize
		AMG_Translate(GU_MODEL, &model->Pos);
		AMG_RotateQuat(GU_MODEL,&q2);
	}
	//Reset collisions
	obj->md->Collision = 0;
	obj->md->CollideWith = 0xFFFF;
}

void AMG_UpdateActorBody(AMG_Actor *actor){

	btVector3 center;
	amg_mdh *obj = &amg_model_ptr[actor->Object[0].bullet_id];
	
	obj->Body->activate();
	center = obj->Body->getWorldTransform().getOrigin();
	memcpy(&actor->Pos,&center,sizeof(ScePspFVector3));
	actor->Pos.y = actor->Pos.y-(((actor->Object[0].BBox[1].x - actor->Object[0].BBox[0].x)/2)*actor->Scale.x);
	AMG_Translate(GU_MODEL, &actor->Pos);
	obj->md->Collision = 0;
	obj->md->CollideWith = 0xFFFF;
}

void AMG_SetVehicle(AMG_Model *model, float mass, float wradius, float wwidth, float wfriction, float xd, float yd){
	model->Object[0].Mass = mass;
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	obj->wheelRadius = wradius;
	obj->wheelWidth = wwidth;
	obj->WheelsXDist = xd;
	obj->WheelsZDist = yd;
	obj->wheelFriction = wfriction;
}
void AMG_InitVehiclePhysics(AMG_Model *model){
	model->Object[0].Mass = 1;
	model->Object[0].Physics = 1;
	// Guarda el objeto en la pila
	amg_save_object_stack(&model->Object[0]);
	/// create vehicle
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	
	//drive parameters
	model->Object[0].Steering = 0;
	model->Object[0].SteeringInc = 0;
	model->Object[0].SteeringClamp = 0.3;
	model->Object[0].Engine = 0;
	model->Object[0].Brake = 0;
	//Physics parameters
	obj->wheelRadius = 0.3;
	obj->wheelWidth = 0.3;
	obj->WheelsXDist = 0.5;
	obj->WheelsZDist = 0.6;
	obj->wheelFriction = 1;

	obj->suspensionDamping = 0.5;//Valor de amortiguación
	obj->suspensionStiffness = 30;//Rigidez de amortiguación
	obj->suspensionCompression = 6;//Fuerza de amortiguación
	obj->connectionHeight = -0.4;//Altura de los ejes respecto al chasis
	
	
	obj->Transform.setIdentity();
	//Box shape has a size defined by wheels position
	float X = obj->WheelsXDist*2; float Y = obj->connectionHeight/3; float Z = obj->WheelsZDist*2;
	obj->Shape = new btBoxShape(btVector3(btScalar(X), btScalar(Y), btScalar(Z)));
	btDefaultMotionState* myMotionState = new btDefaultMotionState(obj->Transform);
	btVector3 localInertia(0,0,0);
	if (model->Object[0].Mass != 0) obj->Shape->calculateLocalInertia(model->Object[0].Mass,localInertia);
	obj->Body = new btRigidBody(model->Object[0].Mass,myMotionState,obj->Shape,localInertia);
	obj->Transform.setOrigin(btVector3(model->Object[0].Pos.x,model->Object[0].Pos.y,model->Object[0].Pos.z));
	
	obj->Body->setWorldTransform(obj->Transform);
	AMG_DynamicWorld->addRigidBody(obj->Body);
	
	btRaycastVehicle::btVehicleTuning m_tuning;
	obj->m_vehicleRayCaster = new btDefaultVehicleRaycaster(AMG_DynamicWorld);
	obj->m_vehicle = new btRaycastVehicle(m_tuning,obj->Body,obj->m_vehicleRayCaster);
	
	///never deactivate the vehicle
	obj->Body->setActivationState(DISABLE_DEACTIVATION);
	AMG_DynamicWorld->addVehicle(obj->m_vehicle);
	
	//choose coordinate system
	obj->m_vehicle->setCoordinateSystem(0,1,2);
	
	//Add wheels in this order: Front left, front right, back left, back right
	//Params: position,axis0,axis1,suspensionRestLength,wheelRadius,vehicle tuning
	btVector3 wheelAx0(0,-1,0);
	btVector3 wheelAx1(-1,0,0);
	float suspensionRestLength = abs(obj->connectionHeight)/2;//Longitud de amortiguador en reposo
	//Position
	obj->m_vehicle->addWheel(btVector3(-obj->WheelsXDist,obj->connectionHeight,-obj->WheelsZDist),wheelAx0,wheelAx1,suspensionRestLength,obj->wheelRadius,m_tuning,1);
	obj->m_vehicle->addWheel(btVector3(obj->WheelsXDist,obj->connectionHeight,-obj->WheelsZDist),wheelAx0,wheelAx1,suspensionRestLength,obj->wheelRadius,m_tuning,1);
	obj->m_vehicle->addWheel(btVector3(-obj->WheelsXDist,obj->connectionHeight,obj->WheelsZDist),wheelAx0,wheelAx1,suspensionRestLength,obj->wheelRadius,m_tuning,0);
	obj->m_vehicle->addWheel(btVector3(obj->WheelsXDist,obj->connectionHeight,obj->WheelsZDist),wheelAx0,wheelAx1,suspensionRestLength,obj->wheelRadius,m_tuning,0);
	
	for (int i=0;i<obj->m_vehicle->getNumWheels();i++){
		btWheelInfo& wheel = obj->m_vehicle->getWheelInfo(i);
		wheel.m_suspensionStiffness = obj->suspensionStiffness;
		wheel.m_wheelsDampingRelaxation = obj->suspensionDamping;
		wheel.m_wheelsDampingCompression = obj->suspensionCompression;
		wheel.m_frictionSlip = obj->wheelFriction;
		wheel.m_rollInfluence = 0.1;//1.0f;
	}
	// Establece el Callback
	obj->Body->setCollisionFlags(obj->Body->getCollisionFlags() | btCollisionObject::CF_CUSTOM_MATERIAL_CALLBACK);
	obj->Body->setUserPointer(&model->Object[0]);
}

void AMG_UpdateVehicleBody(AMG_Model *model){
	btQuaternion __attribute__((aligned(16))) q;
	ScePspQuatMatrix __attribute__((aligned(16))) q2;
	ScePspFVector3 center;
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	memcpy(&center,&obj->m_vehicle->getChassisWorldTransform().getOrigin(),sizeof(ScePspFVector3));
	q = obj->m_vehicle->getChassisWorldTransform().getRotation();
	q2.x = q[0]; q2.y = q[1]; q2.z = q[2]; q2.w = -q[3];

	AMG_Translate(GU_MODEL, &center);
	AMG_RotateQuat(GU_MODEL,&q2);
}

void AMG_UpdateVehicleWheel(AMG_Model *model, int i){
	btQuaternion __attribute__((aligned(16))) q;
	ScePspQuatMatrix __attribute__((aligned(16))) q2;
	ScePspFVector3 c;
	
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	//Update wheel i
	obj->m_vehicle->updateWheelTransform(i,1);
	//Get position and rotation
	memcpy(&c,&obj->m_vehicle->getWheelInfo(i).m_worldTransform.getOrigin(),sizeof(ScePspFVector3));
	q = amg_model_ptr[model->Object[0].bullet_id].m_vehicle->getWheelInfo(i).m_worldTransform.getRotation();
	q2.x = q[0]; q2.y = q[1]; q2.z = q[2]; q2.w = -q[3];
	
	//Get size
	ScePspFVector3 wscal = {obj->wheelWidth,obj->wheelRadius*2,obj->wheelRadius*2};
	AMG_Translate(GU_MODEL, &c);
	AMG_RotateQuat(GU_MODEL,&q2);
	AMG_Scale(GU_MODEL, &wscal);
}

void AMG_MoveVehicle(AMG_Model *model){
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	
	float steering_inc = model->Object[0].SteeringInc;
	if (steering_inc == 0) model->Object[0].Steering = 0;
	model->Object[0].Steering += model->Object[0].SteeringInc;
	if (model->Object[0].Steering > model->Object[0].SteeringClamp) model->Object[0].Steering = model->Object[0].SteeringClamp;
	if (model->Object[0].Steering < -model->Object[0].SteeringClamp) model->Object[0].Steering = -model->Object[0].SteeringClamp;
	
	//Brake using rear wheels
	obj->m_vehicle->setBrake(model->Object[0].Brake,2);
	obj->m_vehicle->setBrake(model->Object[0].Brake,3);
	//Accelerate using front wheels (in you use rear wheels, car ussualy turns over)
	obj->m_vehicle->applyEngineForce(model->Object[0].Engine,0);
	obj->m_vehicle->applyEngineForce(model->Object[0].Engine,1);
	//Turn using front wheels
	obj->m_vehicle->setSteeringValue(model->Object[0].Steering,0);
	obj->m_vehicle->setSteeringValue(model->Object[0].Steering,1);
	
	//Reset collisions
	obj->md->Collision = 0;
	obj->md->CollideWith = 0xFFFF;
}

//constraints

void AMG_BallConstraint(AMG_Model *model, ScePspFVector3 *pivot){
	//point to point constraint with a breaking threshold
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	btVector3 pivotA(pivot->x,pivot->y,pivot->z);
	obj->Body->setActivationState(DISABLE_DEACTIVATION);
	obj->BallConstraint = new btPoint2PointConstraint(*obj->Body,pivotA);
	obj->BallConstraint->setBreakingImpulseThreshold(10.2);
	AMG_DynamicWorld->addConstraint(obj->BallConstraint);
}

void AMG_HingeConstraint(AMG_Model *model, ScePspFVector3 *pivot, int axis){
	//Hinge constraint fixed to world
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	btVector3 btPivotA(pivot->x,pivot->y,pivot->z); 
	btVector3 btAxisA(0,0,0); //axis
	btAxisA[axis] = 1;
	//btHingeConstraint* spHingeDynAB = NULL;
	obj->Body->setActivationState(DISABLE_DEACTIVATION);
	obj->HingeConstraint = new btHingeConstraint(*obj->Body, btPivotA, btAxisA);
	AMG_DynamicWorld->addConstraint(obj->HingeConstraint);
}

void AMG_HingeConstraint2(AMG_Model *model, AMG_Model *model2, ScePspFVector3 *pivot, ScePspFVector3 *pivot2, int axis){
	//Hinge constraint fixed to world
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	amg_mdh *obj2 = &amg_model_ptr[model2->Object[0].bullet_id];
	btVector3 btPivotA(pivot->x,pivot->y,pivot->z);
	btVector3 btAxisA(0,0,0); //axis
	btVector3 btPivotB(pivot2->x,pivot2->y,pivot2->z);
	btVector3 btAxisB(0,0,0); //axis
	btAxisA[axis] = 1;
	btAxisB[axis] = 1;
	//btHingeConstraint* spHingeDynAB = NULL;
	obj->Body->setActivationState(DISABLE_DEACTIVATION);
	obj->HingeConstraint = new btHingeConstraint(*obj->Body, *obj2->Body, btPivotA, btPivotB, btAxisA, btAxisB);
	AMG_DynamicWorld->addConstraint(obj->HingeConstraint);
}

void AMG_HingeConstraintMotor(AMG_Model *model, float target_vel, float max_impulse){
	amg_model_ptr[model->Object[0].bullet_id].HingeConstraint->enableAngularMotor(true, target_vel, max_impulse);
}
	
// Actualiza el motor de fisicas
void AMG_UpdateBulletPhysics(void){
	if(AMG_DynamicWorld == NULL) return;
	AMG_DynamicWorld->stepSimulation(1.0f/20.0f);
	//ONLY FOR GROUND OBJECTS
	//if (amg_model_ptr[i].md->Mass == 0.0f) amg_set_rotation(&amg_model_ptr[i], amg_model_ptr[i].md->Rot);
}

// Termina con el motor Bullet
void AMG_FinishBulletPhysics(void){
	// Elimina todos los objetos de la pila
	for(u32 i=0;i<amg_max_objects;i++){
		if(amg_model_ptr[i].md != NULL){
			// Eliminalo del motor Bullet
			AMG_DynamicWorld->removeRigidBody(amg_model_ptr[i].Body);
			delete amg_model_ptr[i].Body; amg_model_ptr[i].Body = NULL;
			delete amg_model_ptr[i].Shape; amg_model_ptr[i].Shape = NULL;
			amg_model_ptr[i].md->Mass = 0.0f; amg_model_ptr[i].md->isGround = 0;
			// Quitalo de la pila
			amg_model_ptr[i].md->bullet_id = 0;
			amg_model_ptr[i].md = NULL;
			amg_model_ptr[i].Shape = NULL;
			amg_model_ptr[i].Body = NULL;
		}
	}
	// Elimina la pila
	free(amg_model_ptr); amg_model_ptr = NULL;
	amg_max_objects = 0;
	// Elimina los demas datos
	delete AMG_DynamicWorld; AMG_DynamicWorld = NULL;
	delete AMG_PhysicsSolver;
	delete AMG_WorldBroadphase;
	delete AMG_WorldDispatcher;
	delete AMG_CollisionConfiguration;
}

/******************************************************/
/************** FUNCIONES LOCALES *********************/
/******************************************************/

// Transforma un vector en modo Cuartenion (IJK) a modo Vectorial (XYZ)
void amg_quaternion2vector(const btQuaternion &quat, btVector3 &vec){
	float w = quat.getW();	float x = quat.getX();	float y = quat.getY();	float z = quat.getZ();
	float sqw = w*w; float sqx = x*x; float sqy = y*y; float sqz = z*z; 
	vec.setZ((atan2f(2.0 * (x*y + z*w),(sqx - sqy - sqz + sqw))));
	vec.setX((atan2f(2.0 * (y*z + x*w),(-sqx - sqy + sqz + sqw))));
	vec.setY((asinf(-2.0 * (x*z - y*w))));
}

// Obten la rotacion de un objeto simulado
void amg_get_rotation(amg_mdh *obj, ScePspFVector3 &rot){
	btVector3 btv;
	amg_quaternion2vector(obj->Body->getOrientation(), btv);
	rot.x = btv.getX();
	rot.y = btv.getY();
	rot.z = btv.getZ();
}


// Establece la posicion de un objeto simulado
void amg_set_position(amg_mdh *obj, ScePspFVector3 &pos){
	ScePspFVector3 tpos;
	amg_get_position(obj, tpos);
	float x = pos.x - tpos.x;
	float y = pos.y - tpos.y;
	float z = pos.z - tpos.z;
	obj->Body->translate(btVector3(x, y, z));
}

// Obten la posicion de un objeto simulado
void amg_get_position(amg_mdh *obj, ScePspFVector3 &pos){
	if(obj->Body && obj->Body->getMotionState()){
		btVector3 p = obj->Body->getCenterOfMassPosition();
		pos.x = (p.getX() - obj->md->Origin.x);
		pos.y = (p.getY() - obj->md->Origin.y);
		pos.z = (p.getZ() - obj->md->Origin.z);
	}
}


// Guarda un objeto 3D en la pila
void amg_save_object_stack(AMG_Object *md){
	u32 i; u8 done = 0;
	for(i=0;i<amg_max_objects;i++){
		if(!amg_model_ptr[i].md){	// Busca el primer slot libre
			amg_model_ptr[i].md = md; done = 1;
			md->bullet_id = i; i = amg_max_objects;
		}
	}
	if(!done) AMG_Error(AMG_CUSTOM_ERROR, 0, "Couldn't allocate physic object, stack(%d) is full!!", amg_max_objects);	// Error si no se ha encontrado
}

// Establece la velocidad lineal de un objeto 3D
void AMG_SetObjectLinearVelocity(AMG_Object *obj, float x, float y, float z){
	amg_mdh *o = &amg_model_ptr[obj->bullet_id];
	if(o->Body == NULL) return;
	o->Body->setLinearVelocity(btVector3(x, y, z));
}

// Obtén la velocidad lineal de un objeto 3D
void AMG_GetObjectLinearVelocity(AMG_Object *obj, ScePspFVector3 *vel){
	amg_mdh *o = &amg_model_ptr[obj->bullet_id];
	if(o->Body == NULL) return;
	btVector3 v = o->Body->getLinearVelocity();
	vel->x = (float)v.getX(); vel->y = (float)v.getY(); vel->z = (float)v.getZ();
}

// Aplica una fuerza a un objeto 3D
void AMG_SetObjectForce(AMG_Object *obj, float x, float y, float z){
	amg_mdh *o = &amg_model_ptr[obj->bullet_id];
	if(o->Body == NULL) return;
	o->Body->applyCentralImpulse(btVector3(x, y, z));
}

// Establece las propiedades de un objeto 3D
void AMG_SetObjectProperties(AMG_Object *obj, btScalar friction, btScalar rollfriction, btScalar restitution){
	amg_mdh *o = &amg_model_ptr[obj->bullet_id];
	if(o->Body == NULL) return;
	o->Body->setFriction(friction);
	o->Body->setRollingFriction(rollfriction);
	o->Body->setRestitution(restitution);
}

// Obtén las propiedades de un objeto 3D
void AMG_GetObjectProperties(AMG_Object *obj, float *friction, float *rollfriction, float *restitution){
	amg_mdh *o = &amg_model_ptr[obj->bullet_id];
	if(o->Body == NULL) return;
	*friction = (float)o->Body->getFriction();
	*rollfriction = (float)o->Body->getRollingFriction();
	*restitution = (float)o->Body->getRestitution();
}

// Establece la velocidad lineal de un actor 3D
void AMG_SetActorLinearVelocity(AMG_Actor *actor, float x, float y, float z){
	amg_mdh *o = &amg_model_ptr[actor->Object[0].bullet_id];
	if(o->Body == NULL) return;
	o->Body->setLinearVelocity(btVector3(x, y, z));
}

// Obtén la velocidad lineal de un actor 3D
void AMG_GetActorLinearVelocity(AMG_Actor *actor, ScePspFVector3 *vel){
	amg_mdh *o = &amg_model_ptr[actor->Object[0].bullet_id];
	if(o->Body == NULL) return;
	btVector3 v = o->Body->getLinearVelocity();
	vel->x = (float)v.getX(); vel->y = (float)v.getY(); vel->z = (float)v.getZ();
}

// Aplica una fuerza a un actor 3D
void AMG_SetActorForce(AMG_Actor *actor, float x, float y, float z){
	amg_mdh *o = &amg_model_ptr[actor->Object[0].bullet_id];
	if(o->Body == NULL) return;
	o->Body->applyCentralImpulse(btVector3(x, y, z));
}

// Establece las propiedades de un actor 3D
void AMG_SetActorProperties(AMG_Actor *actor, float friction, float restitution){
	amg_mdh *o = &amg_model_ptr[actor->Object[0].bullet_id];
	if(o->Body == NULL) return;
	o->Body->setRollingFriction(friction);
	o->Body->setRestitution(restitution);
}

// Obtén las propiedades de un actor 3D
void AMG_GetActorProperties(AMG_Actor *actor, float *friction, float *restitution){
	amg_mdh *o = &amg_model_ptr[actor->Object[0].bullet_id];
	if(o->Body == NULL) return;
	*friction = (float)o->Body->getFriction();
	*restitution = (float)o->Body->getRestitution();
}

void AMG_GetVehiclePos(AMG_Model *model, ScePspFVector3 *position){
	ScePspFVector3 c = {0,0,0};
	memcpy(&c,&amg_model_ptr[model->Object[0].bullet_id].m_vehicle->getChassisWorldTransform().getOrigin(),sizeof(ScePspFVector3));
	*position = c;
}

void AMG_GetVehicleRot(AMG_Model *model, ScePspFVector3 *rotation){
	ScePspFVector3 c = {0,0,0};
	amg_mdh *obj = &amg_model_ptr[model->Object[0].bullet_id];
	amg_get_rotation(obj,c);
	*rotation = c;
}
#endif	// AMG_ADDON_BULLET

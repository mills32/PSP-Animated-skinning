// Includes
#include "AMG_Texture.h"
#include "AMG_User.h"
#include <pspgu.h>
#include <pspgum.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pspdisplay.h>
#include <pspjpeg.h>
#include "AMG_Multimedia.h"
#include "AMG_3D.h"
#include "AMG_Model.h"
#include <malloc.h>

//#include "shadows.h"	//Shadows redondas
extern int skip;
// OSLIB o LODEPNG
#ifdef AMG_COMPAT_OSLIB
#include <oslib/oslib.h>
#include <lodepng.h>
#include <tjpgd.h>
#else
#include <AMG/lodepng.h>
#include <AMG/tjpgd.h>
#endif

int AMG_MipMapping = 1;
float AMG_MipMapping_Bias = 0;
// Variables locales
char amgt2[256];
void *amg_shared_vram = NULL;
void *amg_svram_curtex = NULL;
u32 amg_svram_size = 0;

// Calcula la siguiente potencia de 2
u32 nextPow2(u32 a){
	if(a < 8) return 8;
	else if(a > 8 && a < 16) return 16;
	else if(a > 16 && a < 32) return 32;
	else if(a > 32 && a < 64) return 64;
	else if(a > 64 && a < 128) return 128;
	else if(a > 128 && a < 256) return 256;
	else if(a > 256) return 512;
	return a;
}

// Reserva espacio para las texturas compartidas
void AMG_AllocateSharedTexture(u32 w, u32 h, u32 psm){
	amg_shared_vram = AMG_VramAlloc(w, h, psm);
	amg_svram_size = AMG_GetVramSize(w, h, psm);
	if(amg_shared_vram == sceGeEdramGetAddr()) AMG_Error(AMG_OUT_OF_VRAM, AMG_GetVramSize(w, h, psm), "AMG_AllocateSharedTexture");
}

// Elimina el espacio para las texturas compartidas
void AMG_FreeSharedTexture(void){
	AMG_FreeVram(amg_shared_vram, amg_svram_size);
	amg_shared_vram = NULL;
	amg_svram_size = 0;
}

// Activa una textura
void AMG_EnableTexture(AMG_Texture *tex){
	if(tex == NULL) return;
	u8 *ptr;
	u8 *ptr1;
	u8 *ptr2;
	if(tex->Frame > (tex->NFrames-1)) tex->Frame = 0;
	u32 offset = (AMG_GetVramSize(tex->Width, tex->Height, tex->TexFormat) * tex->Frame);
	if((tex->Load == AMG_TEX_RAM) && (amg_shared_vram) && (offset <= amg_svram_size)){
		if(amg_svram_curtex != tex->Data){		// Cargamos la textura en VRAM compartida, si se puede...
			sceGuCopyImage(tex->TexFormat, 0, 0, tex->Width, tex->Height, tex->Width, &(((u8*)tex->Data)[offset]), 0, 0, tex->Width, amg_shared_vram);
			offset = 0;
			amg_svram_curtex = tex->Data;
			sceGuTexSync();
		}
		ptr = (u8*) amg_shared_vram;
	}else ptr = (u8*)tex->Data;
	ptr1 = (u8*)tex->MipData;
	ptr2 = (u8*)tex->MipData1;
	
	sceGuEnable(GU_TEXTURE_2D);
	
	if(tex->TexFormat == GU_PSM_T8){
		sceGuClutMode(GU_PSM_8888,0,0xff,0);
		sceGuClutLoad((256/8),tex->clut); // upload 256 rgba colours
	}
	sceGuTexFunc(tex->TFX, tex->TCC);
	sceGuTexEnvColor(tex->EnvColor);
	sceGuTexScale(1.0f, 1.0f);
	sceGuTexOffset(tex->U, tex->V);
	sceGuTexWrap(tex->WrapX, tex->WrapY);
	sceGuTexMapMode(tex->Mapping, tex->MappingLights[0], tex->MappingLights[1]);
	if((tex->Mapping == GU_ENVIRONMENT_MAP) && (tex->MappingLights[0] < 4) && (tex->MappingLights[1] < 4)){		// Si estamos hablando de un Environment Map..
		// Calcula la matriz de 2x3
		AMG_Light[tex->MappingLights[0]].Pos.x = tex->U+AMG_Cos(tex->EnvMapRot);
		AMG_Light[tex->MappingLights[0]].Pos.y = tex->V+AMG_Sin(tex->EnvMapRot);
		AMG_Light[tex->MappingLights[0]].Pos.z = tex->EnvMapX;
		AMG_Light[tex->MappingLights[1]].Pos.x = tex->U+AMG_Sin(tex->EnvMapRot);
		AMG_Light[tex->MappingLights[1]].Pos.y = tex->V-AMG_Cos(tex->EnvMapRot);
		AMG_Light[tex->MappingLights[1]].Pos.z = tex->EnvMapY;
		// Activa la matriz
		sceGuDisable(GU_LIGHT0 + tex->MappingLights[0]);
		sceGuDisable(GU_LIGHT0 + tex->MappingLights[1]);
		sceGuLight(tex->MappingLights[0], GU_DIRECTIONAL, GU_DIFFUSE, (ScePspFVector3*)&AMG_Light[tex->MappingLights[0]].Pos);
		sceGuLight(tex->MappingLights[1], GU_DIRECTIONAL, GU_DIFFUSE, (ScePspFVector3*)&AMG_Light[tex->MappingLights[1]].Pos);
	}
	//Now... Set the fucking images
	if (tex->NMipmaps == 0){
		sceGuTexFilter(tex->MinFilter, tex->MagFilter);
		sceGuTexMode(tex->TexFormat,0, 0, tex->Swizzle);
		sceGuTexImage(0, tex->rw, tex->rh, tex->Width, &ptr[offset]);
	} else {
		sceGuTexMode(tex->TexFormat,tex->NMipmaps, 0, tex->Swizzle);
		sceGuTexFunc(GU_TFX_MODULATE, GU_TCC_RGBA);
		sceGuTexLevelMode(GU_TEXTURE_AUTO, AMG_MipMapping_Bias); 
		sceGuTexFilter(GU_LINEAR_MIPMAP_LINEAR, GU_LINEAR);
		//sceGuTexFilter(GU_NEAREST_MIPMAP_NEAREST, GU_NEAREST);
		sceGuTexImage(0, tex->rw, tex->rh, tex->Width, &ptr[offset]);
		sceGuTexImage(1, tex->rw>>1, tex->rh>>1, tex->Width>>1, &ptr1[offset]);
		if (tex->NMipmaps == 2)sceGuTexImage(2, tex->rw>>2, tex->rh>>2, tex->Width>>2, &ptr2[offset]);
	}
}

// Crea una textura vacía
AMG_Texture *AMG_CreateTexture(u16 width, u16 height, u32 psm, u8 load){
	// Comprueba si es NULL
	AMG_Texture *tex = (AMG_Texture*) calloc (1, sizeof(AMG_Texture));
	// Inicializa la estructura
	tex->NFrames = 1; tex->Frame = 0;
	tex->Load = load;
	tex->Data = NULL;
	tex->MinFilter = GU_LINEAR; tex->MagFilter = GU_LINEAR;
	tex->NMipmaps = 0; tex->Swizzle = 0;
	tex->TFX = GU_TFX_MODULATE;
	tex->TCC = GU_TCC_RGBA;
	tex->EnvColor = 0xFFFFFFFF;
	tex->TexFormat = psm;
	tex->U = 0.0f; tex->V = 0.0f;
	tex->X = tex->Y = 0;
	tex->WrapX = GU_REPEAT; tex->WrapY = GU_REPEAT;
	tex->Mapping = GU_TEXTURE_COORDS;
	tex->MappingLights[0] = 2; tex->MappingLights[1] = 3;
	tex->EnvMapRot = 0.0f; tex->EnvMapX = 0.0f; tex->EnvMapY = 0.0f;
	tex->SprColor = 0xFFFFFFFF;
	tex->Rot = 0.0f; tex->ScaleX = 1.0f; tex->ScaleY = 1.0f;
	tex->Width = width; tex->Height = height;
	tex->rw = tex->Width; tex->rh = tex->Height;
	
	OSL_IMAGE *img = NULL;
	u32 oslib_psm;
	if (psm == GU_PSM_8888) oslib_psm = OSL_PF_8888;
	if (psm == GU_PSM_4444) oslib_psm = OSL_PF_4444;
	if (psm == GU_PSM_5650) oslib_psm = OSL_PF_5650;
	if (psm == GU_PSM_T8) oslib_psm = OSL_PF_8BIT;
	if (psm == GU_PSM_T4) oslib_psm = OSL_PF_4BIT;
	if(load == AMG_TEX_RAM) img = oslCreateImage(width,width,OSL_IN_RAM,oslib_psm);	
	if(load == AMG_TEX_VRAM) img = oslCreateImage(width,width,OSL_IN_VRAM,oslib_psm);	
	// Crea los datos
	tex->Data = (u32*) img->data;
	return tex;
}

// Carga una textura en formato PNG o JPG
AMG_Texture *AMG_LoadTexture(char *path, u8 load, int psm){
	int i;
	
	// Crea la textura
	AMG_Texture *tex = (AMG_Texture*) calloc (1, sizeof(AMG_Texture));
	
	// Inicializa la estructura
	tex->NFrames = 1; tex->Frame = 0;
	tex->Load = AMG_TEX_RAM;
	tex->Data = NULL;
	tex->MipData = NULL;
	tex->MipData1 = NULL;
	tex->MinFilter = GU_LINEAR; tex->MagFilter = GU_LINEAR;
	tex->NMipmaps = 0; tex->Swizzle = 0;
	tex->TFX = GU_TFX_MODULATE;
	tex->TCC = GU_TCC_RGBA;
	tex->EnvColor = 0xFFFFFFFF;
	if (psm == 0)tex->TexFormat = GU_PSM_8888;
	else tex->TexFormat = psm;
	tex->U = tex->V = 0.0f;
	tex->X = tex->Y = 0;
	tex->WrapX = GU_REPEAT; tex->WrapY = GU_REPEAT;
	tex->Mapping = GU_TEXTURE_COORDS;
	tex->MappingLights[0] = 2; tex->MappingLights[1] = 3;
	tex->EnvMapRot = tex->EnvMapX = tex->EnvMapY = 0.0f;
	tex->SprColor = 0xFFFFFFFF;
	tex->Rot = 0.0f; tex->ScaleX = 1.0f; tex->ScaleY = 1.0f;
	tex->Swizzle = 0;

	OSL_IMAGE *img = NULL;
	u32 oslib_psm;
	if (tex->TexFormat == GU_PSM_8888) oslib_psm = OSL_PF_8888;
	if (tex->TexFormat == GU_PSM_4444) oslib_psm = OSL_PF_4444;
	if (tex->TexFormat == GU_PSM_5650) oslib_psm = OSL_PF_5650;
	if (tex->TexFormat == GU_PSM_T8) oslib_psm = OSL_PF_8BIT;
	if (tex->TexFormat == GU_PSM_T4) oslib_psm = OSL_PF_4BIT;
	if(AMG.LoadFrom == AMG_LOAD_RAM){
		OSL_VIRTUALFILENAME ram_files = {"ram:/file.png", (void*)path, AMG.LoadSize, &VF_MEMORY};
		oslAddVirtualFileList(&ram_files, 1);
		img = oslLoadImageFilePNG("ram:/file.png", OSL_IN_RAM, OSL_PF_8888);
		oslRemoveVirtualFileList(&ram_files, 1);
	}else{
		//is a PNG
		img = oslLoadImageFilePNG(path, OSL_IN_RAM, oslib_psm);
	}
	if(img == NULL){ AMG_Error(AMG_CUSTOM_ERROR, 0, "AMG_LoadTexture: Couldn't load %s", path); return NULL;}
	oslUnswizzleImage(img);
	tex->TexFormat = img->pixelFormat;
	tex->Data = (u32*) img->data;
	tex->Width = (u32) img->sysSizeX;
	tex->Height = (u32) img->sysSizeY;
	//Get palette from 8 bit images
	if (tex->TexFormat == GU_PSM_T8){
		int colors = img->palette->nElements;
		for (i = 0; i < 256; i++) tex->clut[i] = 0xffffffff;
		//Manually Load palette from PNG (OSLIB fails a lot)
		FILE *pfile = fopen (path,"rb");
		if(pfile==NULL) return NULL;
		//find PLTE
		while(1) if(getc(pfile) == 'P') if(getc(pfile) == 'L') if(getc(pfile) == 'T') if(getc(pfile) == 'E') break;
		//store palette
		for (i = 0; i < colors; i++) fread(&tex->clut[i],3,1,pfile);
		fclose (pfile);
		//First colour is transparent
		tex->clut[0] = 0x00000000;
	}
	// Stride
	if(tex->Width > 512) AMG_Error(AMG_TEXTURE_OVERFLOW_SIZE, 0, "AMG_LoadTexture");
	tex->rw = tex->Width; tex->rh = tex->Height;
	
	//Create two textures for mipmapping
	if (AMG_MipMapping){
		if ((tex->TexFormat != GU_PSM_T8) && (tex->TexFormat != GU_PSM_T4)){
			OSL_IMAGE *img1 = oslScaleImageCreate(img, OSL_IN_RAM, tex->Width>>1, tex->Height>>1, oslib_psm);
			OSL_IMAGE *img2 = oslScaleImageCreate(img1, OSL_IN_RAM, tex->Width>>2, tex->Height>>2, oslib_psm);
			if (img1 == NULL) goto nomipmaps;
			if (img2 == NULL) goto nomipmaps;
			oslUnswizzleImage(img1);
			oslUnswizzleImage(img2);
			tex->MipData = (u32*) img1->data;
			tex->MipData1 = (u32*) img2->data;
		
			tex->NMipmaps = 2;
			nomipmaps:
			free(img1);free(img2);
			img1 = NULL;img2 = NULL;
		} else {
			u8 *mip0 = (u8*) calloc ((tex->Width>>1)*(tex->Height>>1), sizeof(u8));
			u8 *mip1 = (u8*) calloc ((tex->Width>>2)*(tex->Height>>2), sizeof(u8));
			u8 *data0 = (u8*) tex->Data;
			
			u32 x,y,offset;
			//OK, scan the texture and create the first mipmap, half the size of the texture.
			offset = 0;
			
			for(y=0; y<tex->Height;y+=2){
				for(x=0; x<tex->Width;x+=2){
					mip0[offset] = data0[x + (y * tex->Width)];
					offset++;
				}
			}
			tex->MipData = (u32*) mip0;
			
			//free(mip1); mip1 = NULL;
			
			//Create the second mipmap, half the size of first mipmap.
			offset = 0;
			for(y=0; y<tex->Height;y+=4){
				for(x=0; x<tex->Width;x+=4){
					mip1[offset] = data0[x + (y * tex->Width)];
					offset++;
				}
			}
			tex->MipData1 = (u32*) mip1;
			tex->NMipmaps = 2;
		}
	}
	AMG_SwizzleTexture(tex);
	
	// Transfiere la textura a VRAM, si es necesario
	/*if(load == AMG_TEX_VRAM){
		tex->Load = AMG_TEX_RAM;
		AMG_TransferTextureVram(tex);
	}*/
	
	free(img);
	img = NULL;

	// Devuelve la textura cargada
	return tex;
}

	
// Convierte el formato de una textura
void AMG_ConvertTexture(AMG_Texture *tex, u32 psm){
	if(tex == NULL) return;//Just in case you try to use it on textureless PLY models
	if(tex->TexFormat != GU_PSM_8888){ AMG_Error(AMG_CONVERT_TEXTURE, 0, "not 32 BPP texture"); return;}
	if(tex->Swizzle) return;
	// Crea el nuevo buffer
	u16 *data = (u16*) calloc (AMG_GetVramSize(tex->Width, tex->Height, psm), sizeof(u8));
	if(data == NULL){
		AMG_Error(AMG_OUT_OF_RAM, AMG_GetVramSize(tex->Width, tex->Height, psm), "AMG_ConvertTexture"); return;
	}
	u32 i; u8 *clr;
	// Convierte la textura, pues
	switch(psm){
		/*case GU_PSM_T8:
			for(i=0;i<(tex->Width*tex->Height);i++){
				// Obten el RGB
				clr = (u8*)&tex->Data[i];
				clr[0] = (clr[0] >> 4) &0xF;
				clr[1] = (clr[1] >> 4) &0xF;
				clr[2] = (clr[2] >> 4) &0xF;
				clr[3] = (clr[3] >> 4) &0xF;
				// Recombínalo a R1G1B1
				data[i] = AMG_RGBA4444(clr[0], clr[1], clr[2]);
			} break;
		*/
		case GU_PSM_4444:
			for(i=0;i<(tex->Width*tex->Height);i++){
				// Obten el RGB
				clr = (u8*)&tex->Data[i];
				clr[0] = (clr[0] >> 4) &0xF;
				clr[1] = (clr[1] >> 4) &0xF;
				clr[2] = (clr[2] >> 4) &0xF;
				clr[3] = (clr[3] >> 4) &0xF;
				// Recombínalo a R4G4B4A4
				data[i] = AMG_RGBA4444(clr[0], clr[1], clr[2], clr[3]);
			} break;
		case GU_PSM_5650:
			tex->TCC = GU_TCC_RGB;		// Es tontería poner alpha donde no lo hay
			for(i=0;i<(tex->Width*tex->Height);i++){
				// Obten el RGB
				clr = (u8*)&tex->Data[i];
				clr[0] = (clr[0] >> 3) &0x1F;
				clr[1] = (clr[1] >> 2) &0x3F;
				clr[2] = (clr[2] >> 3) &0x1F;
				// Recombínalo a R5G6B5
				data[i] = AMG_RGBA5650(clr[0], clr[1], clr[2]);
			} break;
		case GU_PSM_5551:
			for(i=0;i<(tex->Width*tex->Height);i++){
				// Obten el RGB
				clr = (u8*)&tex->Data[i];
				clr[0] = (clr[0] >> 3) &0x1F;
				clr[1] = (clr[1] >> 3) &0x1F;
				clr[2] = (clr[2] >> 3) &0x1F;
				// Recombínalo a R5G5B5A1
				data[i] = AMG_RGBA5551(clr[0], clr[1], clr[2], clr[3]?1:0);
			} break;
		default: AMG_Error(AMG_CONVERT_TEXTURE, 0, "Wrong PSM"); return;
	}
	// Actualiza el buffer
	tex->TexFormat = psm;
	if(tex->Load == AMG_TEX_RAM){
		free(tex->Data); tex->Data = NULL; tex->Data = (u32*) data;
	}else{
		tex->Load = AMG_TEX_RAM;
		AMG_FreeVram(tex->Data, (tex->Width*tex->Height)<<2); tex->Data = (u32*) data;
		AMG_TransferTextureVram(tex);
	}
}

// Transfiere una textura a VRAM
void AMG_TransferTextureVram(AMG_Texture *tex){
	if(tex->Load == AMG_TEX_RAM){
		u32 *vram_ptr = (u32*) AMG_VramAlloc(tex->Width, tex->Height, tex->TexFormat);
		if(vram_ptr != sceGeEdramGetAddr()){	// Si ha habido éxito pasamos la textura a VRAM
			memcpy(vram_ptr, tex->Data, AMG_GetVramSize(tex->Width, tex->Height, tex->TexFormat));
			free(tex->Data); tex->Data = NULL; tex->Data = vram_ptr;
			tex->Load = AMG_TEX_VRAM;
		}
	}
}

// Elimina una textura
void AMG_UnloadTexture(AMG_Texture *tex){
	if(tex == NULL) return;
	if(tex->Load == AMG_TEX_RAM){
		free(tex->Data);
	}else{
		AMG_FreeVram(tex->Data, AMG_GetVramSize(tex->Width, tex->Height, tex->TexFormat));
	}
	tex->Data = NULL;
}

// Dibuja un Sprite 2D
void AMG_DrawSprite(AMG_Texture *tex){
	if(tex == NULL) return;
	AMG_EnableTexture(tex);
	AMG_Vertex_intTV *data2D = (AMG_Vertex_intTV*) sceGuGetMemory(sizeof(AMG_Vertex_intTV) * 4);
	float w2 = (float)(tex->Width >> 1);
	float h2 = (float)(tex->Height >> 1);
	float s = AMG_Sin(tex->Rot);
	float c = AMG_Cos(tex->Rot);
	data2D[0].u = 0;
	data2D[0].v = 0;
	data2D[0].x = (s16)(((-w2*c) - (-h2*s)) * tex->ScaleX) + tex->X;
	data2D[0].y = (s16)(((-w2*s) + (-h2*c)) * tex->ScaleY) + tex->Y;
	data2D[0].z = 0;
	data2D[1].u = tex->Width;
	data2D[1].v = 0;
	data2D[1].x = (s16)(((w2*c) - (-h2*s)) * tex->ScaleX) + tex->X;
	data2D[1].y = (s16)(((w2*s) + (-h2*c)) * tex->ScaleY) + tex->Y;
	data2D[1].z = 0;
	data2D[2].u = 0;
	data2D[2].v = tex->Height;
	data2D[2].x = (s16)(((-w2*c) - (h2*s)) * tex->ScaleX) + tex->X;
	data2D[2].y = (s16)(((-w2*s) + (h2*c)) * tex->ScaleY) + tex->Y;
	data2D[2].z = 0;
	data2D[3].u = tex->Width;
	data2D[3].v = tex->Height;
	data2D[3].x = (s16)(((w2*c) - (h2*s)) * tex->ScaleX) + tex->X;
	data2D[3].y = (s16)(((w2*s) + (h2*c)) * tex->ScaleY) + tex->Y;
	data2D[3].z = 0;
	sceGuColor(tex->SprColor);
	sceGuDrawArray(GU_TRIANGLE_STRIP, (GU_TEXTURE_16BIT | GU_VERTEX_16BIT | GU_TRANSFORM_2D), 4, 0, data2D);
}

#ifndef AMG_COMPILE_ONELUA

// Crea un objeto 2D
void AMG_Create2dObject(AMG_Texture *tex, u32 psm, u8 vram){
	if(tex == NULL) return;
	// Convierte la textura, si es necesario
	tex->TFX = GU_TFX_MODULATE; tex->MinFilter = GU_NEAREST; tex->MagFilter = GU_NEAREST;
	if((psm != GU_PSM_8888) && (psm != tex->TexFormat)){		// Si hay que convertir...
		if(tex->Load == AMG_TEX_VRAM){ AMG_Error(AMG_CUSTOM_ERROR, 0, "AMG_Create2dObject: Texture is in Vram"); return;}
		AMG_ConvertTexture(tex, psm);
	}
	
	// Si la imagen no es potencia de 2...
	tex->rw = nextPow2(tex->rw);
	tex->rh = nextPow2(tex->rh);
	
	// Transfiere la textura a VRAM, si es necesario
	if(vram && (tex->Load != AMG_TEX_VRAM)) AMG_TransferTextureVram(tex);
}

// Printf al estilo AMGLib
void AMG_Printf(AMG_Texture *tex, int x, int y, u32 color, const char *text){

	// Obtén la cadena de texto
	u32 l = strlen(text);
	AMG_Vertex_intTV *data2D = (AMG_Vertex_intTV*) sceGuGetMemory((l << 1) * sizeof(AMG_Vertex_intTV));
	
	// Parámetros de la fuente de texto
	u16 fontw = (tex->Width >> 4);
	u16 fonth = (tex->Height >> 4);
	s16 _x = x, _y = y;
	char c = 0;
	
	// Calcula la cadena de texto
	u32 i;
	for(i=0;i<l;i++){
		c = text[i];
		if(c == '\n'){	// Si es un salto de línea...
			_y += fonth;
			_x = (x - fontw);
			c = 0;
		}
		data2D[(i<<1)].u = ((c &0xF)*fontw);
		data2D[(i<<1)].v = ((c &0xF0)>>4)*fonth;
		data2D[(i<<1)].x = _x;
		data2D[(i<<1)].y = _y;
		data2D[(i<<1)].z = 0;
		data2D[(i<<1)+1].u = ((c &0xF)*fontw) + fontw;
		data2D[(i<<1)+1].v = (((c &0xF0)>>4)*fonth) + fonth;
		data2D[(i<<1)+1].x = _x+fontw;
		data2D[(i<<1)+1].y = _y+fonth;
		data2D[(i<<1)+1].z = 0;
		_x += fontw;
	}
	
	// Dibuja la cadena de texto
	AMG_EnableTexture(tex);
	sceGuColor(color);
	sceGuDrawArray(GU_SPRITES, (GU_TEXTURE_16BIT | GU_VERTEX_16BIT | GU_TRANSFORM_2D), (l << 1), 0, data2D);
}

// Dibuja un sprite con texture-caché
void AMG_DrawSpriteCache(AMG_Texture *tex){
	if(tex == NULL) return;
	AMG_EnableTexture(tex);
	sceGuColor(tex->SprColor);
	
	// Dibuja el sprite
	int start, end;
	int dx = 0;
	int x = (tex->X - (tex->Width >> 1));
	int y = (tex->Y - (tex->Height >> 1));
	for(start = 0, end = tex->Width; start < end; start += tex->Width, dx += tex->Width){
		AMG_Vertex_intTV *vertices = (AMG_Vertex_intTV*) sceGuGetMemory(2 * sizeof(AMG_Vertex_intTV));
		int width = (start + tex->Width) < end ? tex->Width : end-start;
		vertices[0].u = start; vertices[0].v = 0;
		vertices[0].x = dx+x; vertices[0].y = y; vertices[0].z = 0;
		vertices[1].u = start + width; vertices[1].v = tex->Height;
		vertices[1].x = dx + width + x; vertices[1].y = tex->Height + y; vertices[1].z = 0;
		sceGuDrawArray(GU_SPRITES, GU_TEXTURE_16BIT | GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, vertices);
	}
}

// Elimina un color de la imagen
void AMG_DeleteColor(AMG_Texture *tex, u32 color){
	if(tex == NULL) return;
	if(tex->TexFormat == GU_PSM_5650){ AMG_Error(AMG_CUSTOM_ERROR, 0, "AMG_DeleteColor: Texture is 5650"); return;}
	u32 i;
	u16 *d = (u16*) tex->Data;
	
	// Borra el color requerido
	for(i=0;i<(tex->Width*tex->Height);i++){
		if(tex->TexFormat == GU_PSM_8888){
			if(tex->Data[i] == color){
				tex->Data[i] &= ~(0xFF000000);
			}
		}else{
			if(tex->TexFormat == GU_PSM_5551){		// 5551
				if(d[i] == (color &0xFFFF)) d[i] &= ~(1 << 15);
			}else{									// 4444
				if(d[i] == (color &0xFFFF)) d[i] &= ~(0xF << 12);
			}
		}
	}
}

#endif

// Establece el numero de frames de la textura
void AMG_TextureFrames(AMG_Texture *tex, u8 nframes){
	if(tex == NULL) return;
	tex->NFrames = nframes;
	tex->Height /= nframes;
	if(tex->Height > 512){ AMG_Error(AMG_TEXTURE_OVERFLOW_SIZE, 0, "AMG_TextureFrames"); return;}
	tex->rh = nextPow2(tex->Height);
}


u8* Swizzle_Data(u32 *data, u32 twidth, u32 theight, u32 tformat){
	u32 size;
	const u8 *in;
	u8 *out;
	u32 width, blockx, blocky, j, width_blocks, height_blocks, src_pitch, src_row;
	const u8 *ysrc;
	u32 *dst;
	
	size = AMG_GetVramSize(twidth, theight, tformat);
	out = (u8*) calloc (size, sizeof(u8));
	in = (const u8*)data;
	width = (twidth * (size / (twidth*theight)));
	width_blocks = (width / 16);
	height_blocks = (theight / 8);
	src_pitch = (width - 16)/4;
	src_row = width * 8;
	ysrc = in;
	dst = (u32*)out;
	for(blocky = 0; blocky < height_blocks; ++blocky){
		const u8* xsrc = ysrc;//Get texture pixel
		for(blockx = 0; blockx < width_blocks; ++blockx){
			const u32* src = (u32*)xsrc;
			for (j = 0; j < 8; ++j){
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				src += src_pitch;
			}
			xsrc += 16;
		}
		ysrc += src_row;
	}
	return out;
}

// Haz el efecto Swizzle a una textura (gana velocidad)
void AMG_SwizzleTexture(AMG_Texture *tex){
	if(tex == NULL) return;
	if(tex->Load == AMG_TEX_VRAM) return;
	if(tex->Swizzle) return;
	u8 *out = NULL;
	
	//Swizzle Main Texture
	out = Swizzle_Data(tex->Data,tex->Width,tex->Height,tex->TexFormat);
	free(tex->Data); tex->Data = NULL; tex->Data = (u32*)out;
	
	if (tex->NMipmaps == 2){
		//Swizzle MipData
		out = Swizzle_Data(tex->MipData,tex->Width>>1,tex->Height>>1,tex->TexFormat);
		free(tex->MipData); tex->MipData = NULL; tex->MipData = (u32*)out;
		//Swizzle MipData1
		out = Swizzle_Data(tex->MipData1,tex->Width>>2,tex->Height>>2,tex->TexFormat);
		free(tex->MipData1); tex->MipData1 = NULL; tex->MipData1 = (u32*)out;
	}
	tex->Swizzle = 1;
}

// Quita Swizzle a una textura para acceder a los pixeles
// Just do not unswizzle textures with mip maps
void AMG_UnswizzleTexture(AMG_Texture *tex){
	if(tex == NULL) return;
	if(tex->Load == AMG_TEX_VRAM) return;
	if(!tex->Swizzle) return;
	
	// Crea el buffer
	u32 size = AMG_GetVramSize(tex->Width, tex->Height, tex->TexFormat);
	u8 *out = (u8*) calloc (size, sizeof(u8));
	
	// Variables adicionales
	const u8 *in = (const u8*)tex->Data;
	u32 width = (tex->Width * (size / (tex->Width*tex->Height)));
	u32 blockx, blocky, j;
	u32 width_blocks = (width / 16);
	u32 height_blocks = (tex->Height / 8);
	u32 dst_pitch = (width - 16)/4;
	u32 dst_row = width * 8;

	u32* src = (u32*)in;
	u8* ydst = out;

	for (blocky = 0; blocky < height_blocks; ++blocky){
		const u8* xdst = ydst;
		for (blockx = 0; blockx < width_blocks; ++blockx){
			u32* dst= (u32*)xdst;
			for (j = 0; j < 8; ++j){
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				*(dst++) = *(src++);
				dst += dst_pitch;
			}
			xdst += 16;
		}
		ydst += dst_row;
	}	
	
	
	// Libera datos usados
	free(tex->Data); tex->Data = NULL; tex->Data = (u32*)out;
	tex->Swizzle = 0;
}

//#ifndef AMG_COMPILE_ONELUA

// Haz una screenshot en formato BMP24
void AMG_Screenshot(const char *path){
	// Obten el framebuffer
	void *fbv; int w, pf;
	u8 *data = (u8*) calloc (AMG.ScreenWidth*AMG.ScreenHeight*4, sizeof(u8));
	sceDisplayWaitVblankStart();
	sceDisplayGetFrameBuf(&fbv, &w, &pf, PSP_DISPLAY_SETBUF_NEXTFRAME);
	u8 *fb = (u8*) fbv;
	
	// Transforma la imagen a RGB32
	if(data == NULL) return;
	u32 x, y;
	u16 *fb16 = (u16*) fb; u16 clr;
	switch(AMG.PSM){
		case GU_PSM_8888:
			for(y=0;y<AMG.ScreenHeight;y++){
				for(x=0;x<AMG.ScreenWidth;x++){
					data[((x+(y*AMG.ScreenWidth))<<2)] = fb[((x+(y*AMG.ScreenStride))<<2)];
					data[((x+(y*AMG.ScreenWidth))<<2)+1] = fb[((x+(y*AMG.ScreenStride))<<2)+1];
					data[((x+(y*AMG.ScreenWidth))<<2)+2] = fb[((x+(y*AMG.ScreenStride))<<2)+2];
					data[((x+(y*AMG.ScreenWidth))<<2)+3] = 0xFF;
				}
			} break;
		case GU_PSM_5551:
			for(y=0;y<AMG.ScreenHeight;y++){
				for(x=0;x<AMG.ScreenWidth;x++){
					clr = fb16[(x+(y*AMG.ScreenStride))];
					data[((x+(y*AMG.ScreenWidth))<<2)] = (clr &0x1F) << 3;
					data[((x+(y*AMG.ScreenWidth))<<2)+1] = ((clr >> 5) &0x1F) << 3;
					data[((x+(y*AMG.ScreenWidth))<<2)+2] = ((clr >> 10) &0x1F) << 3;
					data[((x+(y*AMG.ScreenWidth))<<2)+3] = 0xFF;
				}
			} break;
		case GU_PSM_4444:
			for(y=0;y<AMG.ScreenHeight;y++){
				for(x=0;x<AMG.ScreenWidth;x++){
					clr = fb16[(x+(y*AMG.ScreenStride))];
					data[((x+(y*AMG.ScreenWidth))<<2)] = (clr &0xF) << 4;
					data[((x+(y*AMG.ScreenWidth))<<2)+1] = ((clr >> 4) &0xF) << 4;
					data[((x+(y*AMG.ScreenWidth))<<2)+2] = ((clr >> 8) &0xF) << 4;
					data[((x+(y*AMG.ScreenWidth))<<2)+3] = 0xFF;
				}
			} break;
		case GU_PSM_5650:
			for(y=0;y<AMG.ScreenHeight;y++){
				for(x=0;x<AMG.ScreenWidth;x++){
					clr = fb16[(x+(y*AMG.ScreenStride))];
					data[((x+(y*AMG.ScreenWidth))<<2)] = (clr &0x1F) << 3;
					data[((x+(y*AMG.ScreenWidth))<<2)+1] = ((clr >> 5) &0x3F) << 2;
					data[((x+(y*AMG.ScreenWidth))<<2)+2] = ((clr >> 11) &0x1F) << 3;
					data[((x+(y*AMG.ScreenWidth))<<2)+3] = 0xFF;
				}
			} break;
		default: free(data); data = NULL; return;
	}
	
	// Abre el archivo y guarda la imagen
	int error = lodepng_encode32_file(path, data, AMG.ScreenWidth, AMG.ScreenHeight);
	if(error){ AMG_Error(AMG_CUSTOM_ERROR, 0, lodepng_error_text(error)); return;}
	free(data); data = NULL;
}

//#endif

// Establece el mapeo de una textura
void AMG_SetTextureMapping(AMG_Texture *tex, u32 mapping, u8 l0, u8 l1){
	// Mapea la textura correspondiente
	if(tex == NULL) return;
	tex->Mapping = mapping;
	tex->MappingLights[0] = l0;
	tex->MappingLights[1] = l1;
}

// Activa el Render To Texture
void AMG_EnableRenderToTexture(AMG_Texture *tex){
	if(tex == NULL) return;
	if(tex->Load != AMG_TEX_VRAM) return;
	if (!skip){
		tex->Swizzle = 0;
		sceGuDrawBufferList(tex->TexFormat, (void*)((u32)tex->Data - (u32)sceGeEdramGetAddr()), tex->Width);
		sceGuOffset(2048 - (tex->Width>>1), 2048 - (tex->Height>>1));
		sceGuViewport(2048, 2048, tex->Width, tex->Height);
		sceGuClearColor(AMG.ClearColor);
		sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT | GU_STENCIL_BUFFER_BIT);
		sceGuScissor(0, 0, tex->Width, tex->Height);
	}	
}

// Desactiva el Render To Texture
void AMG_DisableRenderToTexture(void){
	sceGuScissor(0, 0, AMG.ScreenWidth, AMG.ScreenHeight);
	sceGuDrawBufferList(AMG.PSM, AMG.CurrentFB, AMG.ScreenStride);
	sceGuOffset(2048 - (AMG.ScreenWidth >> 1), 2048 - (AMG.ScreenHeight >> 1));
	sceGuViewport(2048, 2048, AMG.ScreenWidth, AMG.ScreenHeight);
	oslEndDrawing();
	oslStartDrawing();
}

// Cambia el pixel de una textura
void AMG_ChangeTexturePixel(AMG_Texture *tex, u32 x, u32 y, u32 color){
	if(tex == NULL) return;
	if(tex->Swizzle) return;
	if((x >= tex->Width) || (y >= tex->Height)) return;
	u32 offset = (x + (y * tex->Width));
	if(tex->TexFormat == GU_PSM_8888) tex->Data[offset] = color;
	else ((u16*)tex->Data)[offset] = (color &0xFFFF);
}

// Obtén un pixel de una textura
u32 AMG_GetTexturePixel(AMG_Texture *tex, u32 x, u32 y){
	if(tex == NULL) return 0;
	if((tex->Swizzle) || (x >= tex->Width) || (y >= tex->Height)) return 0;
	u32 offset = (x + (y * tex->Width));
	if(tex->TexFormat == GU_PSM_8888) return tex->Data[offset];
	return ((((u16*)tex->Data)[offset]) &0xFFFF);
}
#ifndef _AMG_MULTIMEDIA_H_
#define _AMG_MULTIMEDIA_H_

#ifdef __cplusplus
	extern "C" {
#endif

// Includes
#include <psptypes.h>
#include "AMG_Config.h"

#ifndef AMG_COMPILE_ONELUA

// Includes AUDIO
#include <pspaudio.h>
#include <pspaudiolib.h>
#include <mad.h>

#ifdef AMG_DOC_ENGLISH
/**
 * @file AMG_Multimedia.h
 * @brief Functions related to the multimedia engine (user mode)
 * @author Andr�s Mart�nez (Andresmargar)
 */
#else
/**
 * @file AMG_Multimedia.h
 * @brief Funciones encargadas del motor multimedia (modo usuario)
 * @author Andr�s Mart�nez (Andresmargar)
 */
#endif
 
#ifdef AMG_DOC_ENGLISH
/**
 * @struct
 * @brief Struct that holds a sound file
 */
#else
/**
 * @struct
 * @brief Estructura de un archivo de sonido
 */
#endif
typedef struct{
	u8 *Data;
	u32 DataSize;
	u8 Play, Pause, Stop;
	int Loop;
	u8 Type;
	// AT3
	int AtracID;
	u32 NSamples;
	u8 S, E;
	// MP3
	struct mad_stream Stream;
	struct mad_frame Frame;
	struct mad_synth Synth;
	mad_timer_t Timer;
	int OutputSamples;
	u16 *OutputBuffer;
}AMG_SOUND;

// Tipos de archivos
#define AMG_SOUND_MP3	0
#define AMG_SOUND_AT3	1
#define AMG_SOUNDLOOP_INFINITY -1

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Inits the multimedia engine
 * @return It returns nothing
 */
#else
/**
 * @brief Inicializa el motor multimedia
 * @return No devuelve nada
 */
#endif
void AMG_InitMultimedia(void);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Finishes the multimedia engine
 * @return It returns nothing
 */
#else
/**
 * @brief Acaba con el motor multimedia
 * @return No devuelve nada
 */
#endif
void AMG_FinishMultimedia(void);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Inits audio system
 * @return It returns nothing
 */
#else
/**
 * @brief Inicializa el motor de audio
 * @return No devuelve nada
 */
#endif
void AMG_InitAudio(void);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Finishes the audio system
 * @return It returns nothing
 */
#else
/**
 * @brief Finaliza el motor de audio
 * @return No devuelve nada
 */
#endif
void AMG_FinishAudio(void);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Loads a MP3 file
 * @param path The MP3 file path
 * @return A pointer to the MP3 file
 */
#else
/**
 * @brief Carga un archivo MP3
 * @param path La ruta del archivo MP3
 * @return El puntero al archivo MP3
 */
#endif
AMG_SOUND *AMG_LoadSoundMP3(const char *path);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Loads an AT3 file
 * @param path The AT3 file path
 * @return A pointer to the AT3 file
 */
#else
/**
 * @brief Carga un archivo AT3
 * @param path La ruta del archivo AT3
 * @return El puntero al archivo AT3
 */
#endif
AMG_SOUND *AMG_LoadSoundAT3(const char *path);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Links a sound file with a channel
 * @param snd Sound pointer
 * @param channel Audio channel
 * @return It returns nothing
 */
#else
/**
 * @brief Enlaza un sonido con un canal de audio
 * @param snd Puntero al sonido
 * @param channel El canal de audio
 * @return No devuelve nada
 */
#endif
void AMG_SetChannelSound(AMG_SOUND *snd, u8 channel);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Frees an audio channel
 * @param channel Audio channel
 * @return It returns nothing
 */
#else
/**
 * @brief Libera un canal de audio
 * @param channel El canal de audio
 * @return No devuelve nada
 */
#endif
void AMG_FreeChannelSound(u8 channel);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Deletes a sound
 * @param mp3 The sound to delete
 * @return It returns nothing
 */
#else
/**
 * @brief Elimina un sonido
 * @param mp3 El sonido a eliminar
 * @return No devuelve nada
 */
#endif
void AMG_UnloadSound(AMG_SOUND *snd);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Plays a sound file
 * @param mp3 Sound to play
 * @return It returns nothing
 */
#else
/**
 * @brief Reproduce un sonido
 * @param mp3 El sonido a reproducir
 * @return No devuelve nada
 */
#endif
static inline void AMG_PlaySound(AMG_SOUND *snd){
	snd->Play = 1;
}

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Pauses a sound file
 * @param mp3 Sound to pause
 * @return It returns nothing
 */
#else
/**
 * @brief Pausa un sonido
 * @param mp3 El sonido a pausar
 * @return No devuelve nada
 */
#endif
static inline void AMG_PauseSound(AMG_SOUND *snd){
	snd->Play = 0;
}

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Stops a sound file
 * @param mp3 The sound to stop
 * @return It returns nothing
 */
#else
/**
 * @brief Detiene un sonido
 * @param mp3 El sonido a detener
 * @return No devuelve nada
 */
#endif
void AMG_StopSound(AMG_SOUND *snd);

#ifdef AMG_DOC_ENGLISH
/**
 * @brief Set the loop for a sound file
 * @param mp3 Sound file
 * @param loop Loop value (true or false)
 * @return It returns nothing
 */
#else
/**
 * @brief Establece el loop de un sonido
 * @param mp3 El sonido
 * @param loop El valor del loop (true o false)
 * @return No devuelve nada
 */
#endif
void AMG_SetSoundLoop(AMG_SOUND *snd, u8 loop);

#endif

#ifdef __cplusplus
	}
#endif

#endif

#ifndef _AMG_CONFIG_H_
#define _AMG_CONFIG_H_

// Opciones de compilación, cámbialas a tu gusto
#define AMG_ADDON_BULLET
#define AMG_COMPAT_OSLIB
#define AMG_COMPILE_ONELUA

// Opciones de documentación
//#define AMG_DOC_ENGLISH

#endif

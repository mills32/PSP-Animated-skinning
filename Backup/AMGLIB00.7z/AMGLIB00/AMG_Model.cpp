// Includes
#include "AMG_Model.h"
#include "AMG_User.h"
#include "AMG_3D.h"
#include <pspgu.h>
#include <pspgum.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <math.h>
#include <pspmath.h>
int skip;

void AMG_UpdateBody(AMG_Object *model);
void AMG_UpdateActorBody(AMG_Actor *actor);
void AMG_UpdateVehicleBody(AMG_Model *model);
void AMG_UpdateVehicleWheel(AMG_Model *model, int i);

////MD2 NORMALS array///////////////////////////////
const float Q2_VERTEX_NORMAL_TABLE[162][3] = {
	{-0.525731f, 0.000000f, 0.850651f},
	{-0.442863f, 0.238856f, 0.864188f},
	{-0.295242f, 0.000000f, 0.955423f},
	{-0.309017f, 0.500000f, 0.809017f},
	{-0.162460f, 0.262866f, 0.951056f},
	{0.000000f, 0.000000f, 1.000000f},
	{0.000000f, 0.850651f, 0.525731f},
	{-0.147621f, 0.716567f, 0.681718f},
	{0.147621f, 0.716567f, 0.681718f},
	{0.000000f, 0.525731f, 0.850651f},
	{0.309017f, 0.500000f, 0.809017f},
	{0.525731f, 0.000000f, 0.850651f},
	{0.295242f, 0.000000f, 0.955423f},
	{0.442863f, 0.238856f, 0.864188f},
	{0.162460f, 0.262866f, 0.951056f},
	{-0.681718f, 0.147621f, 0.716567f},
	{-0.809017f, 0.309017f, 0.500000f},
	{-0.587785f, 0.425325f, 0.688191f},
	{-0.850651f, 0.525731f, 0.000000f},
	{-0.864188f, 0.442863f, 0.238856f},
	{-0.716567f, 0.681718f, 0.147621f},
	{-0.688191f, 0.587785f, 0.425325f},
	{-0.500000f, 0.809017f, 0.309017f},
	{-0.238856f, 0.864188f, 0.442863f},
	{-0.425325f, 0.688191f, 0.587785f},
	{-0.716567f, 0.681718f, -0.147621f},
	{-0.500000f, 0.809017f, -0.309017f},
	{-0.525731f, 0.850651f, 0.000000f},
	{0.000000f, 0.850651f, -0.525731f},
	{-0.238856f, 0.864188f, -0.442863f},
	{0.000000f, 0.955423f, -0.295242f},
	{-0.262866f, 0.951056f, -0.162460f},
	{0.000000f, 1.000000f, 0.000000f},
	{0.000000f, 0.955423f, 0.295242f},
	{-0.262866f, 0.951056f, 0.162460f},
	{0.238856f, 0.864188f, 0.442863f},
	{0.262866f, 0.951056f, 0.162460f},
	{0.500000f, 0.809017f, 0.309017f},
	{0.238856f, 0.864188f, -0.442863f},
	{0.262866f, 0.951056f, -0.162460f},
	{0.500000f, 0.809017f, -0.309017f},
	{0.850651f, 0.525731f, 0.000000f},
	{0.716567f, 0.681718f, 0.147621f},
	{0.716567f, 0.681718f, -0.147621f},
	{0.525731f, 0.850651f, 0.000000f},
	{0.425325f, 0.688191f, 0.587785f},
	{0.864188f, 0.442863f, 0.238856f},
	{0.688191f, 0.587785f, 0.425325f},
	{0.809017f, 0.309017f, 0.500000f},
	{0.681718f, 0.147621f, 0.716567f},
	{0.587785f, 0.425325f, 0.688191f},
	{0.955423f, 0.295242f, 0.000000f},
	{1.000000f, 0.000000f, 0.000000f},
	{0.951056f, 0.162460f, 0.262866f},
	{0.850651f, -0.525731f, 0.000000f},
	{0.955423f, -0.295242f, 0.000000f},
	{0.864188f, -0.442863f, 0.238856f},
	{0.951056f, -0.162460f, 0.262866f},
	{0.809017f, -0.309017f, 0.500000f},
	{0.681718f, -0.147621f, 0.716567f},
	{0.850651f, 0.000000f, 0.525731f},
	{0.864188f, 0.442863f, -0.238856f},
	{0.809017f, 0.309017f, -0.500000f},
	{0.951056f, 0.162460f, -0.262866f},
	{0.525731f, 0.000000f, -0.850651f},
	{0.681718f, 0.147621f, -0.716567f},
	{0.681718f, -0.147621f, -0.716567f},
	{0.850651f, 0.000000f, -0.525731f},
	{0.809017f, -0.309017f, -0.500000f},
	{0.864188f, -0.442863f, -0.238856f},
	{0.951056f, -0.162460f, -0.262866f},
	{0.147621f, 0.716567f, -0.681718f},
	{0.309017f, 0.500000f, -0.809017f},
	{0.425325f, 0.688191f, -0.587785f},
	{0.442863f, 0.238856f, -0.864188f},
	{0.587785f, 0.425325f, -0.688191f},
	{0.688191f, 0.587785f, -0.425325f},
	{-0.147621f, 0.716567f, -0.681718f},
	{-0.309017f, 0.500000f, -0.809017f},
	{0.000000f, 0.525731f, -0.850651f},
	{-0.525731f, 0.000000f, -0.850651f},
	{-0.442863f, 0.238856f, -0.864188f},
	{-0.295242f, 0.000000f, -0.955423f},
	{-0.162460f, 0.262866f, -0.951056f},
	{0.000000f, 0.000000f, -1.000000f},
	{0.295242f, 0.000000f, -0.955423f},
	{0.162460f, 0.262866f, -0.951056f},
	{-0.442863f, -0.238856f, -0.864188f},
	{-0.309017f, -0.500000f, -0.809017f},
	{-0.162460f, -0.262866f, -0.951056f},
	{0.000000f, -0.850651f, -0.525731f},
	{-0.147621f, -0.716567f, -0.681718f},
	{0.147621f, -0.716567f, -0.681718f},
	{0.000000f, -0.525731f, -0.850651f},
	{0.309017f, -0.500000f, -0.809017f},
	{0.442863f, -0.238856f, -0.864188f},
	{0.162460f, -0.262866f, -0.951056f},
	{0.238856f, -0.864188f, -0.442863f},
	{0.500000f, -0.809017f, -0.309017f},
	{0.425325f, -0.688191f, -0.587785f},
	{0.716567f, -0.681718f, -0.147621f},
	{0.688191f, -0.587785f, -0.425325f},
	{0.587785f, -0.425325f, -0.688191f},
	{0.000000f, -0.955423f, -0.295242f},
	{0.000000f, -1.000000f, 0.000000f},
	{0.262866f, -0.951056f, -0.162460f},
	{0.000000f, -0.850651f, 0.525731f},
	{0.000000f, -0.955423f, 0.295242f},
	{0.238856f, -0.864188f, 0.442863f},
	{0.262866f, -0.951056f, 0.162460f},
	{0.500000f, -0.809017f, 0.309017f},
	{0.716567f, -0.681718f, 0.147621f},
	{0.525731f, -0.850651f, 0.000000f},
	{-0.238856f, -0.864188f, -0.442863f},
	{-0.500000f, -0.809017f, -0.309017f},
	{-0.262866f, -0.951056f, -0.162460f},
	{-0.850651f, -0.525731f, 0.000000f},
	{-0.716567f, -0.681718f, -0.147621f},
	{-0.716567f, -0.681718f, 0.147621f},
	{-0.525731f, -0.850651f, 0.000000f},
	{-0.500000f, -0.809017f, 0.309017f},
	{-0.238856f, -0.864188f, 0.442863f},
	{-0.262866f, -0.951056f, 0.162460f},
	{-0.864188f, -0.442863f, 0.238856f},
	{-0.809017f, -0.309017f, 0.500000f},
	{-0.688191f, -0.587785f, 0.425325f},
	{-0.681718f, -0.147621f, 0.716567f},
	{-0.442863f, -0.238856f, 0.864188f},
	{-0.587785f, -0.425325f, 0.688191f},
	{-0.309017f, -0.500000f, 0.809017f},
	{-0.147621f, -0.716567f, 0.681718f},
	{-0.425325f, -0.688191f, 0.587785f},
	{-0.162460f, -0.262866f, 0.951056f},
	{0.442863f, -0.238856f, 0.864188f},
	{0.162460f, -0.262866f, 0.951056f},
	{0.309017f, -0.500000f, 0.809017f},
	{0.147621f, -0.716567f, 0.681718f},
	{0.000000f, -0.525731f, 0.850651f},
	{0.425325f, -0.688191f, 0.587785f},
	{0.587785f, -0.425325f, 0.688191f},
	{0.688191f, -0.587785f, 0.425325f},
	{-0.955423f, 0.295242f, 0.000000f},
	{-0.951056f, 0.162460f, 0.262866f},
	{-1.000000f, 0.000000f, 0.000000f},
	{-0.850651f, 0.000000f, 0.525731f},
	{-0.955423f, -0.295242f, 0.000000f},
	{-0.951056f, -0.162460f, 0.262866f},
	{-0.864188f, 0.442863f, -0.238856f},
	{-0.951056f, 0.162460f, -0.262866f},
	{-0.809017f, 0.309017f, -0.500000f},
	{-0.864188f, -0.442863f, -0.238856f},
	{-0.951056f, -0.162460f, -0.262866f},
	{-0.809017f, -0.309017f, -0.500000f},
	{-0.681718f, 0.147621f, -0.716567f},
	{-0.681718f, -0.147621f, -0.716567f},
	{-0.850651f, 0.000000f, -0.525731f},
	{-0.688191f, 0.587785f, -0.425325f},
	{-0.587785f, 0.425325f, -0.688191f},
	{-0.425325f, 0.688191f, -0.587785f},
	{-0.425325f, -0.688191f, -0.587785f},
	{-0.587785f, -0.425325f, -0.688191f},
	{-0.688191f, -0.587785f, -0.425325f},
};

u32 l = 0;

ScePspFVector3 s;		// Lo siento, no me gustan las variables locales :P
AMG_Object *amg_curfloor;	// El suelo actual (para reflejos y sombras)

//////////////////////

u8 Render_Style = GU_TRIANGLES;//Mills 04/08/15

// Cambia el modo de renderizado 3d //Mills 04/08/15
void AMG_RenderStyle(u8 Render_M){
	Render_Style = Render_M;
}

// Obten el directorio de un archivo
char *getdir(const char *path){
	char *dir = strdup(path);
	char *s = strrchr(dir, '/');
	if(s) s[1]   = '\0';
	else dir[0] = '\0';
	return dir;
}

// Carga un modelo en formato PLY
AMG_Model *AMG_LoadModelPLY(char *path, float css, u32 psm){
	
	if (psm == 0) psm = GU_PSM_8888;
	
	AMG_Vertex_TCNV *ttcnv = NULL;
	AMG_Vertex_TCNV *ftcnv = NULL;
	AMG_Vertex_V *outl = NULL;
	
	// Crea el modelo 3D
	AMG_Model *model = NULL;
	model = (AMG_Model*) calloc (1, sizeof(AMG_Model));
	FILE *f = fopen(path, "rb");
	
	if(f == NULL){ AMG_Error(AMG_OPEN_FILE, 0, path); goto error;}
{
	model->CelShading = 0;
	
	u32 *vindex; 
	u32 vtx = 0;
	u32 nvindex = 0;
	u32 nvtx = 0;
	u32 nobj = 0;

	u32 i = 0;

	char *line = (char*) calloc (128, sizeof(char));

	int colorR,colorG,colorB = 0;
	
	//CUENTA OBJETOS 
	nobj = 1;
	
	//PREPARA MEMORIA
	model->NObjects = nobj;
	model->Object = (AMG_Object*) calloc (model->NObjects, sizeof(AMG_Object));
	
	
	//model->Object[i].NFaces = 0;
	model->Object[0].Group = NULL;
	model->Object[0].Data = NULL;
	model->Object[0].Triangles = NULL;
	model->Object[0].Flags = (GU_VERTEX_32BITF | GU_TRANSFORM_3D);	// Flags por defecto
	model->Object[0].BBox = NULL;
	model->Object[0].BBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
	model->Object[0].tBBox = NULL;
	model->Object[0].tBBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
	model->Object[0].CelShadingScale = 1.025f;
	model->Object[0].OutLine = NULL;
	model->Object[0].OutlineColor = GU_RGBA(0, 0, 0, 0xFF);
	model->Object[0].Lighting = 1;
	model->Object[0].Pos.x = 0.0f; model->Object[i].Pos.y = 0.0f; model->Object[i].Pos.z = 0.0f;
	model->Object[0].Origin.x = 0.0f; model->Object[i].Origin.y = 0.0f; model->Object[i].Origin.z = 0.0f;
	model->Object[0].Rot.x = 0.0f; model->Object[i].Rot.y = 0.0f; model->Object[i].Rot.z = 0.0f;
	model->Object[0].Scale.x = 1.0f; model->Object[i].Scale.y = 1.0f; model->Object[i].Scale.z = 1.0f;
	model->Object[0].Physics = 0;
	if (css)
		model->Object[0].CelShadingScale = css;
	else
		model->Object[0].CelShadingScale = 0.2f; ///cambio tamaño del borde por
	// BULLET
	model->Object[0].Mass = 0.0f;
	model->Object[0].isGround = 0;
	model->Object[0].ShapeType = 0;
	model->Object[0].Collision = 0;
	model->Object[0].CollideWith = 0xFFFF;

	nvtx = 0; nobj = 0; 
	//CUENTA MATERIALES DE CADA OBJETO

	vtx = 0;
	// Crea los grupos de materiales
	model->Object[0].NGroups = 1;
	model->Object[0].Group = (AMG_ObjectGroup*) calloc (model->Object[0].NGroups, sizeof(AMG_ObjectGroup));

	model->Object[0].Group[0].Ambient = GU_RGBA(0x00, 0x00, 0x00, 0xFF);
	model->Object[0].Group[0].Emmision = GU_RGBA(0, 0, 0, 0xFF);
	model->Object[0].Group[0].Diffuse = GU_RGBA(0xFF, 0xFF, 0xFF, 0xFF);
	model->Object[0].Group[0].Specular = GU_RGBA(0xFF, 0xFF, 0xFF, 0xFF);
	model->Object[0].Group[0].Texture = NULL;
	model->Object[0].Group[0].MultiTexture = NULL;
	model->Object[0].Group[0].Start = 0;
	
	model->Object[0].Group[0].mtlname = (char*) calloc (64, sizeof(char));

	//model->Object[i].NFaces = model->Object[i].Group[model->Object[i].NGroups-1].End;
	model->Object[0].Triangles = memalign (16, model->Object[0].NFaces*3*sizeof(AMG_Vertex_V));	// Sombra para Cel-Shading
	// vertices, texcoords y normales
	model->Object[0].Flags |= (GU_NORMAL_32BITF|GU_TEXTURE_32BITF|GU_COLOR_8888);
	model->Object[0].Data = NULL;
	model->Object[0].TriangleSize = sizeof(AMG_Vertex_TCNV)*3;
	
	// Crea el buffer temporal de caras
	model->Object[0].face = NULL;
	model->Object[0].face = (AMG_FaceOBJ*) calloc (model->Object[0].NFaces, sizeof(AMG_FaceOBJ));

	nobj = 0;
	nvtx = 0;
	nvindex = 0;
	//CUENTA VERTICES Y CARAS
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		if (line[0] == 'e'){
			if(line[8] == 'v'){			
				sscanf(line, "element vertex %d",&nvtx);
			}
			if(line[8] == 'f'){			
				sscanf(line, "element face %d",&model->Object[0].NFaces);
				model->Object[0].Group[0].End = model->Object[0].NFaces;
			}			
		}
	}
	
	model->Object[0].Data = (AMG_Vertex_TCNV *) malloc (model->Object[0].NFaces*3*sizeof(AMG_Vertex_TCNV));
	ttcnv = (AMG_Vertex_TCNV *) malloc (nvtx*3*sizeof(AMG_Vertex_TCNV));
	//LEE VERTICES
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		if ((line[0] < 58)&&(line[1] != ' ')){//ascii, not a letter, and not a space in 1.
			if (sscanf(line, 
				"%f %f %f %f %f %f %f %f %d %d %d",
			    &ttcnv[vtx].x, &ttcnv[vtx].y,&ttcnv[vtx].z,
                &ttcnv[vtx].nx, &ttcnv[vtx].ny, &ttcnv[vtx].nz,	
				&ttcnv[vtx].u, &ttcnv[vtx].v,
                &colorR, &colorG, &colorB
			) < 11) {
				ttcnv[vtx].u = ttcnv[vtx].v = 0;
				colorR = colorG = colorB = 255;
			}
			ttcnv[vtx].v = -1*ttcnv[vtx].v;
			ttcnv[vtx].color = GU_RGBA(colorR,colorG,colorB,255);
			vtx++;
		}
	}
	vtx = 0;
	rewind(f);

	//INDICES
	vindex = (u32 *) malloc (model->Object[0].NFaces*3*sizeof(u32));
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		if ((line[0] == '3')&&(line[1] == ' ')){//ascii, equal 3 (avoid 3.00...)
			sscanf(line,"3 %d %d %d",&vindex[nvindex],&vindex[nvindex+1],&vindex[nvindex+2]);
			nvindex+=3;
			vtx++;
		}
	}
	fclose(f);
	
	model->Object[0].Mass = vtx;
	//ARRANGE VERTICES
	model->Object[0].Triangles = (AMG_Vertex_V *) malloc (model->Object[0].NFaces*3*sizeof(AMG_Vertex_V));
	AMG_Vertex_V *s = (AMG_Vertex_V*) model->Object[0].Triangles;
	ftcnv =(AMG_Vertex_TCNV *) malloc (model->Object[0].NFaces*3*sizeof(AMG_Vertex_TCNV));

	for (i = 0; i < model->Object[0].NFaces*3;i++){
		u32 index = vindex[i];
		ftcnv[i] = ttcnv[index];
		
		s[i].x = ftcnv[i].x; 
		s[i].y = ftcnv[i].y;
		s[i].z = ftcnv[i].z;
	}
	
	//COPY TO DATA
	memcpy(model->Object[0].Data,ftcnv,model->Object[0].NFaces*3*sizeof(AMG_Vertex_TCNV));

	if((model->Object[0].Data == NULL) || (model->Object[0].Triangles == NULL) || (model->Object[0].face == NULL)){
		AMG_Error(AMG_OUT_OF_RAM, -1, "AMG_LoadModel"); goto error;
	}
	
	//outline
	if (css && css>0){
		model->Object[0].OutLine = (AMG_Vertex_V*) malloc (model->Object[0].NFaces*3*sizeof(AMG_Vertex_V));
		
		for (i = 0; i < model->Object[0].NFaces*3;i++){
			model->Object[0].OutLine[i].x = s[i].x + ftcnv[i].nx * model->Object[0].CelShadingScale;
			model->Object[0].OutLine[i].y = s[i].y + ftcnv[i].ny * model->Object[0].CelShadingScale;
			model->Object[0].OutLine[i].z = s[i].z + ftcnv[i].nz * model->Object[0].CelShadingScale;
		}	
	}
	
	//get texture with the same name as the file
	char *texturename = (char*) calloc (strlen(path), sizeof(char));
	strncpy(texturename,path,strlen(path)-3);
	strcat(texturename,"png");
	int result = access(texturename, F_OK);
	if (result == 0) {
		AMG_Texture *texture = AMG_LoadTexture(texturename,AMG_TEX_RAM,psm);
		model->Object[0].Group[0].Texture = texture;
	} else model->Object[0].Group[0].Texture = NULL;
	nvtx = 0;

	//SIZE
	model->Object[0].BBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
	// Calcula la bounding box
	for(i=0;i<model->Object[0].NFaces*3;i++) {
		if (model->Object[0].BBox[0].x >= ftcnv[i].x) model->Object[0].BBox[0].x = ftcnv[i].x; //MIN X
		if (model->Object[0].BBox[0].y >= ftcnv[i].y) model->Object[0].BBox[0].y = ftcnv[i].y; //MIN Y
		if (model->Object[0].BBox[0].z >= ftcnv[i].z) model->Object[0].BBox[0].z = ftcnv[i].z; //MIN Z
		if (model->Object[0].BBox[1].x <= ftcnv[i].x) model->Object[0].BBox[1].x = ftcnv[i].x; //MAX X
		if (model->Object[0].BBox[1].y <= ftcnv[i].y) model->Object[0].BBox[1].y = ftcnv[i].y; //MAX Y
		if (model->Object[0].BBox[1].z <= ftcnv[i].z) model->Object[0].BBox[1].z = ftcnv[i].z; //MAX Z
	}

	if(line) free(line); line = NULL;
	if(ttcnv) free(ttcnv); ttcnv = NULL;
	if(ftcnv) free(ftcnv); ftcnv = NULL;
	if (outl) free(outl); outl = NULL;
	i = 0;
	
	return model;
}
error:
	return NULL;
}

// Carga un modelo en formato OBJ y MTL
AMG_Model *AMG_LoadModel(const char *path, float css, u32 psm){ ///cambio  Añadidos parámetros
	if (psm == 0) psm = GU_PSM_8888;
	// Define variables
	u32 j=0;
	AMG_Vertex_TV *tcv = NULL; AMG_Vertex_TNV *tcnv = NULL; AMG_Vertex_NV *cnv = NULL; AMG_Vertex_V *cv = NULL; AMG_Vertex_V *outl = NULL;
	u32 face_idx = 0;
	u8 ng = 0;
	int i = 0, faceformat = 0;
	float *vtx = NULL, *nrm = NULL, *txc = NULL;
	u8 noObjects = 0;
	u32 nobj = 0, nvtx = 0, nnrm = 0, ntxc = 0;
	char *line = (char*) calloc (128, sizeof(char));
	char *mtlpath = (char*) calloc (128, sizeof(char));
	char *straux = (char*) calloc (64, sizeof(char));
	
	// Crea el modelo 3D
	AMG_Model *model = NULL;
	model = (AMG_Model*) calloc (1, sizeof(AMG_Model));
	// Abre el archivo OBJ
	FILE *f = fopen(path, "rb");
	if(f == NULL){ AMG_Error(AMG_OPEN_FILE, 0, path); goto error;}
	model->CelShading = 0;
	
	// Primera lectura
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		switch(line[0]){
			case '#': break;
			case 'm': // mtllib
				sscanf(line, "mtllib %s", straux);
				sprintf(mtlpath, "%s%s", getdir(path), straux);
				break;
			case 'o': nobj ++; break;
			case 'v':
				switch(line[1]){
					case ' ': nvtx ++; break;
					case 'n': nnrm ++; break;
					case 't': ntxc ++; break;
					default: break;
				} break;
			default: break;
		}
	}
	
	// Si no hay objetos, pon uno al menos (para los modelos exportados con Sketchup)
	if(nobj == 0){
		nobj = 1;
		noObjects = 1;
	}
	
	// Prepara buffers
	vtx = (float*) calloc (nvtx*3, sizeof(float));
	if(ntxc) txc = (float*) calloc (ntxc<<1, sizeof(float));
	if(nnrm) nrm = (float*) calloc (nnrm*3, sizeof(float));
	model->NObjects = nobj;
	model->Object = (AMG_Object*) calloc (model->NObjects, sizeof(AMG_Object));
	nobj = nvtx = nnrm = ntxc = 0;
	for(i=0;i<model->NObjects;i++){
		model->Object[i].NGroups = 0;
		model->Object[i].Group = NULL;
		model->Object[i].Data = NULL;
		model->Object[i].Triangles = NULL;
		model->Object[i].TexFur = NULL;
		model->Object[i].FurLayers = 0;
		model->Object[i].Fur = NULL;
		model->Object[i].FurFilter = GU_NEAREST;
		model->Object[i].Flags = (GU_VERTEX_32BITF | GU_TRANSFORM_3D);	// Flags por defecto
		model->Object[i].BBox = NULL;
		model->Object[i].BBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
		model->Object[i].tBBox = NULL;
		model->Object[i].tBBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
		model->Object[i].Physics = 0;
		if (css)
			model->Object[i].CelShadingScale = css;
		else
			model->Object[i].CelShadingScale = 0.2f; ///cambio tamaño del borde por defecto
//##### añade la siguiente
        model->Object[i].OutLine = NULL;
		model->Object[i].OutlineColor = GU_RGBA(0, 0, 0, 0xFF);
		model->Object[i].Lighting = true;
		model->Object[i].Pos.x = 0.0f; model->Object[i].Pos.y = 0.0f; model->Object[i].Pos.z = 0.0f;
		model->Object[i].Origin.x = 0.0f; model->Object[i].Origin.y = 0.0f; model->Object[i].Origin.z = 0.0f;
		model->Object[i].Rot.x = 0.0f; model->Object[i].Rot.y = 0.0f; model->Object[i].Rot.z = 0.0f;
		model->Object[i].Scale.x = 1.0f; model->Object[i].Scale.y = 1.0f; model->Object[i].Scale.z = 1.0f;
		// BULLET
		model->Object[i].Mass = 0.0f;
		model->Object[i].isGround = 0;
		model->Object[i].ShapeType = 0;
		model->Object[i].Collision = 0;
		model->Object[i].CollideWith = 0xFFFF;
	}
	
	// Variables temporales de lectura de caras
	int tmp_v0, tmp_v1, tmp_v2, tmp_n0, tmp_n1, tmp_n2, tmp_t0, tmp_t1, tmp_t2;
	nobj = noObjects;
	
	// Segunda lectura
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		switch(line[0]){
			case '#': break;
			case 'g':	// Grupos de materiales (ahora soportados :D )
				break;
			case 'o': nobj ++; break;
			case 'u':	// usemtl
				model->Object[nobj-1].NGroups ++;
				break;
			case 'v':
				switch(line[1]){
					case ' ': sscanf(line, "v %f %f %f", &vtx[nvtx*3], &vtx[(nvtx*3)+1], &vtx[(nvtx*3)+2]); nvtx ++; break;
					case 'n': sscanf(line, "vn %f %f %f", &nrm[nnrm*3], &nrm[(nnrm*3)+1], &nrm[(nnrm*3)+2]); nnrm ++; break;
					case 't': 
						sscanf(line, "vt %f %f", &txc[ntxc<<1], &txc[(ntxc<<1)+1]); 
						txc[(ntxc<<1)+1] = -txc[(ntxc<<1)+1];		// Invierte la V
						ntxc ++; break;
					default: break;
				} break;
			default: break;
		}
	}
	
	// Crea los grupos de materiales
	for(i=0;i<model->NObjects;i++){
		model->Object[i].Group = (AMG_ObjectGroup*) calloc (model->Object[i].NGroups, sizeof(AMG_ObjectGroup));
		for(u8 k=0;k<model->Object[i].NGroups;k++){
			model->Object[i].Group[k].Ambient = GU_RGBA(0x7F, 0x7F, 0x7F, 0xFF);
			model->Object[i].Group[k].Emmision = GU_RGBA(0, 0, 0, 0xFF);
			model->Object[i].Group[k].Diffuse = GU_RGBA(0xFF, 0xFF, 0xFF, 0xFF);
			model->Object[i].Group[k].Specular = GU_RGBA(0xFF, 0xFF, 0xFF, 0xFF);
			model->Object[i].Group[k].Texture = NULL;
			model->Object[i].Group[k].MultiTexture = NULL;
			model->Object[i].Group[k].Start = 0;
			model->Object[i].Group[k].End = 0;
			model->Object[i].Group[k].mtlname = (char*) calloc (64, sizeof(char));
		}
	}
	
	// Lee el archivo y obtén el número de caras
	nobj = noObjects;
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		switch(line[0]){
			case '#': break;
			case 'g':		// Grupos de materiales (ahora soportados :D )
				break;
			case 'o':
				nobj ++; ng = 0; break;
			case 'u':	// usemtl (guardamos el nombre del material)
				ng ++;
				sscanf(line, "usemtl %s", model->Object[nobj-1].Group[ng-1].mtlname);
				if(ng > 1){
					model->Object[nobj-1].Group[ng-1].Start = (model->Object[nobj-1].Group[ng-2].End);
					model->Object[nobj-1].Group[ng-1].End = (model->Object[nobj-1].Group[ng-2].End);
				} break;
			case 'f': 	// Averigua el formato de caras
				if(strstr(line, "//")){		// v//n o v//
					if(sscanf(line, "f %d//%d %d//%d %d//%d", &tmp_v0, &tmp_n0, &tmp_v1, &tmp_n1, &tmp_v2, &tmp_n2) == 6){
						faceformat = 0;
					}else{
						faceformat = 1;
					}
				}else if(sscanf(line, "f %d/%d/%d %d/%d/%d %d/%d/%d", &tmp_v0, &tmp_t0, &tmp_n0, &tmp_v1, &tmp_t1, &tmp_n1, &tmp_v2, &tmp_t2, &tmp_n2) == 9){
					faceformat = 2;
				}else if(sscanf(line, "f %d/%d/ %d/%d/ %d/%d/", &tmp_v0, &tmp_t0, &tmp_v1, &tmp_t1, &tmp_v2, &tmp_t2) == 6) faceformat = 3;
				else if(sscanf(line, "f %d/%d %d/%d %d/%d", &tmp_v0, &tmp_t0, &tmp_v1, &tmp_t1, &tmp_v2, &tmp_t2) == 6) faceformat = 4;
				else if(sscanf(line, "f %d %d %d", &tmp_v0, &tmp_v1, &tmp_v2) == 3) faceformat = 5;
				else{ AMG_Error(AMG_CUSTOM_ERROR, 0, "Model \"%s\": Wrong face format", path); goto error;}
				model->Object[nobj-1].Group[ng-1].End ++;
				break;
			default: break;
		}
	}
	
	// Crea buffers de vertices finales
	for(i=0;i<model->NObjects;i++){
		model->Object[i].NFaces = model->Object[i].Group[model->Object[i].NGroups-1].End;
		model->Object[i].Triangles = memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_V));	// Sombra para Cel-Shading

		switch(faceformat){
			case 0:			// vertices y normales
				model->Object[i].Flags |= GU_NORMAL_32BITF;
				model->Object[i].Data = (AMG_Vertex_NV*) memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_NV));
				model->Object[i].TriangleSize = sizeof(AMG_Vertex_NV)*3;
				break;
			case 1: case 5: // vertices
				model->Object[i].Data = (AMG_Vertex_V*) memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_V));
				model->Object[i].TriangleSize = sizeof(AMG_Vertex_V)*3;
				break;
			case 2: // vertices, texcoords y normales
				model->Object[i].Flags |= (GU_TEXTURE_32BITF | GU_NORMAL_32BITF);
				model->Object[i].Data = (AMG_Vertex_TNV*) memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_TNV));
				model->Object[i].TriangleSize = sizeof(AMG_Vertex_TNV)*3;
				break;
			case 3: case 4:	// vertices y texcoords
				model->Object[i].Flags |= GU_TEXTURE_32BITF;
				model->Object[i].Data = (AMG_Vertex_TV*) memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_TV));
				model->Object[i].TriangleSize = sizeof(AMG_Vertex_TV)*3;
				break;
			default: break;
		}
		if (css && css>0)
			model->Object[i].OutLine = (AMG_Vertex_V*) memalign (16, model->Object[i].NFaces*3*sizeof(AMG_Vertex_V));
		
		
		// Crea el buffer temporal de caras
		model->Object[i].face = NULL;
		model->Object[i].face = (AMG_FaceOBJ*) calloc (model->Object[i].NFaces, sizeof(AMG_FaceOBJ));
		if((model->Object[i].Data == NULL) || (model->Object[i].Triangles == NULL) || (model->Object[i].face == NULL)){
			AMG_Error(AMG_OUT_OF_RAM, -1, "AMG_LoadModel"); goto error;
		}
	}
	
	// Tercera lectura, leer las caras
	nobj = noObjects;
	fseek(f, 0, SEEK_SET);
	while(!feof(f)){
		memset(line, 0, 128);
		fgets(line, 128, f);
		if(line[0] == 'o'){
			nobj ++; face_idx = 0;
		}else if(line[0] == 'f' && line[1] == ' '){
			// Segun el formato de caras...
			switch(faceformat){
				case 0: sscanf(line, "f %d//%d %d//%d %d//%d", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].n[0], 
															   &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].n[1], 
															   &model->Object[nobj-1].face[face_idx].v[2], &model->Object[nobj-1].face[face_idx].n[2]); break;
				case 1: sscanf(line, "f %d// %d// %d//", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].v[2]); break;
				case 2: sscanf(line, "f %d/%d/%d %d/%d/%d %d/%d/%d", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].t[0], &model->Object[nobj-1].face[face_idx].n[0],
																	 &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].t[1], &model->Object[nobj-1].face[face_idx].n[1],
																	 &model->Object[nobj-1].face[face_idx].v[2], &model->Object[nobj-1].face[face_idx].t[2], &model->Object[nobj-1].face[face_idx].n[2]);
																	 break;
				case 3: sscanf(line, "f %d/%d/ %d/%d/ %d/%d/", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].t[0], 
															   &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].t[1], 
															   &model->Object[nobj-1].face[face_idx].v[2], &model->Object[nobj-1].face[face_idx].t[2]); break;
				case 4: sscanf(line, "f %d/%d %d/%d %d/%d", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].t[0], 
															   &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].t[1], 
															   &model->Object[nobj-1].face[face_idx].v[2], &model->Object[nobj-1].face[face_idx].t[2]); break;
				case 5: sscanf(line, "f %d %d %d", &model->Object[nobj-1].face[face_idx].v[0], &model->Object[nobj-1].face[face_idx].v[1], &model->Object[nobj-1].face[face_idx].v[2]);
															   break;
				default: break;
			}
			// Resta 1 a cada indice de la cara
			for(i=0;i<3;i++){
				model->Object[nobj-1].face[face_idx].v[i] --;
				model->Object[nobj-1].face[face_idx].t[i] --;
				model->Object[nobj-1].face[face_idx].n[i] --;
			}
			// Suma el indice de caras para este objeto
			face_idx ++;
		}
	}

	// Compila el modelo para AMGLib
	for(i=0;i<model->NObjects;i++){
		for(face_idx=0;face_idx<model->Object[i].NFaces;face_idx++){
			AMG_Vertex_V *s = (AMG_Vertex_V*) model->Object[i].Triangles;

			switch(faceformat){
				case 0:					// vertices y normales
					cnv = (AMG_Vertex_NV*) model->Object[i].Data;
					for(j=0;j<3;j++){
						s[(face_idx*3)+j].x = cnv[(face_idx*3)+j].x = vtx[model->Object[i].face[face_idx].v[j] * 3];
						s[(face_idx*3)+j].y = cnv[(face_idx*3)+j].y = vtx[(model->Object[i].face[face_idx].v[j] * 3)+1];
						s[(face_idx*3)+j].z = cnv[(face_idx*3)+j].z = vtx[(model->Object[i].face[face_idx].v[j] * 3)+2];
						cnv[(face_idx*3)+j].nx = nrm[model->Object[i].face[face_idx].n[j] * 3];
						cnv[(face_idx*3)+j].ny = nrm[(model->Object[i].face[face_idx].n[j] * 3)+1];
						cnv[(face_idx*3)+j].nz = nrm[(model->Object[i].face[face_idx].n[j] * 3)+2];
					} break;
				case 1: case 5:			// vertices
					cv = (AMG_Vertex_V*) model->Object[i].Data;
					for(j=0;j<3;j++){
						cv[(face_idx*3)+j].x = vtx[model->Object[i].face[face_idx].v[j] * 3];
						cv[(face_idx*3)+j].y = vtx[(model->Object[i].face[face_idx].v[j] * 3)+1];
						cv[(face_idx*3)+j].z = vtx[(model->Object[i].face[face_idx].v[j] * 3)+2];
					}
					memcpy(s, cv, model->Object[i].NFaces*3*sizeof(AMG_Vertex_V));				
					break;
				case 2:					// todo
					tcnv = (AMG_Vertex_TNV*) model->Object[i].Data;
					for(j=0;j<3;j++){
						s[(face_idx*3)+j].x = tcnv[(face_idx*3)+j].x = vtx[model->Object[i].face[face_idx].v[j] * 3];
						s[(face_idx*3)+j].y = tcnv[(face_idx*3)+j].y = vtx[(model->Object[i].face[face_idx].v[j] * 3)+1];
						s[(face_idx*3)+j].z = tcnv[(face_idx*3)+j].z = vtx[(model->Object[i].face[face_idx].v[j] * 3)+2];
						tcnv[(face_idx*3)+j].nx = nrm[model->Object[i].face[face_idx].n[j] * 3];
						tcnv[(face_idx*3)+j].ny = nrm[(model->Object[i].face[face_idx].n[j] * 3)+1];
						tcnv[(face_idx*3)+j].nz = nrm[(model->Object[i].face[face_idx].n[j] * 3)+2];
						tcnv[(face_idx*3)+j].u = txc[(model->Object[i].face[face_idx].t[j] << 1)];
						tcnv[(face_idx*3)+j].v = txc[(model->Object[i].face[face_idx].t[j] << 1)+1];
						if (css && css>0){ ///cambio toma vertices y escala usando normales
							model->Object[i].OutLine[(face_idx*3)+j].x = s[(face_idx*3)+j].x + tcnv[(face_idx*3)+j].nx * model->Object[i].CelShadingScale;
							model->Object[i].OutLine[(face_idx*3)+j].y = s[(face_idx*3)+j].y + tcnv[(face_idx*3)+j].ny * model->Object[i].CelShadingScale;
							model->Object[i].OutLine[(face_idx*3)+j].z = s[(face_idx*3)+j].z + tcnv[(face_idx*3)+j].nz * model->Object[i].CelShadingScale;
						}
					} break;
				case 3: case 4:			// vertices y texcoords
					tcv = (AMG_Vertex_TV*) model->Object[i].Data;
					for(j=0;j<3;j++){
						s[(face_idx*3)+j].x = tcv[(face_idx*3)+j].x = vtx[model->Object[i].face[face_idx].v[j] * 3];
						s[(face_idx*3)+j].y = tcv[(face_idx*3)+j].y = vtx[(model->Object[i].face[face_idx].v[j] * 3)+1];
						s[(face_idx*3)+j].z = tcv[(face_idx*3)+j].z = vtx[(model->Object[i].face[face_idx].v[j] * 3)+2];
						tcv[(face_idx*3)+j].u = txc[(model->Object[i].face[face_idx].t[j] << 1)];
						tcv[(face_idx*3)+j].v = txc[(model->Object[i].face[face_idx].t[j] << 1)+1];					
					}
					break;
				default: break;
			}
		}
	}
	
	// Abre el archivo MTL
	fclose(f); f = NULL;
	f = fopen(mtlpath, "rb");
	if(f == NULL){ AMG_Error(AMG_OPEN_FILE, 0, mtlpath); goto error;}
	
	// Leelo linea a linea
	float clr[3];
	u8 first;
	while(!feof(f)){
		fgets(line, 128, f);
		switch(line[0]){
			case '#': break;
			case 'n':	// newmtl
				sscanf(line, "newmtl %s", straux);
				for(i=0;i<model->NObjects;i++) for(u8 k=0;k<model->Object[i].NGroups;k++) model->Object[i].Group[k].sel = 0;
				// Busca los grupos que tengan ese material...
				for(i=0;i<model->NObjects;i++){
					for(u8 k=0;k<model->Object[i].NGroups;k++){
						if(strcmp(straux, model->Object[i].Group[k].mtlname) == 0){
							model->Object[i].Group[k].sel = 1;
						}
					}
				} break;
			case 'm':	// map_Kd
				sscanf(line, "map_Kd %s", straux);
				first = 1;
				for(i=0;i<model->NObjects;i++){
					for(u8 k=0;k<model->Object[i].NGroups;k++){
						if(model->Object[i].Group[k].sel){
							if(first){
								sprintf(model->Object[i].Group[k].mtlname, "%s%s", getdir(path), straux);
								//model->Object[i].Group[k].Texture = AMG_LoadTexture(model->Object[i].Group[k].mtlname, AMG.TextureDest);
								model->Object[i].Group[k].Texture = AMG_LoadTexture(model->Object[i].Group[k].mtlname, AMG_TEX_RAM,psm);
								first = 0;
							}else{
								// Busca la primera textura
								for(u8 i0=0;i0<model->NObjects;i0++){
									for(u8 i1=0;i1<model->Object[i0].NGroups;i1++){
										if(model->Object[i0].Group[i1].sel){
											model->Object[i].Group[k].Texture = model->Object[i0].Group[i1].Texture;
											i1 = model->Object[i0].NGroups; i0 = model->NObjects;	// Para salir del bucle doble...
										}
									}
								}
							}
						}
					}
				} break;
			case 'K':
				switch(line[1]){
					case 'd':		// Kd
						sscanf(line, "Kd %f %f %f", &clr[0], &clr[1], &clr[2]);
						for(i=0;i<model->NObjects;i++){
							for(u8 k=0;k<model->Object[i].NGroups;k++){
								if(model->Object[i].Group[k].sel) model->Object[i].Group[k].Diffuse = GU_COLOR(clr[0], clr[1], clr[2], 1.0f);
							}
						} break;
					case 'a':		// Ka
						sscanf(line, "Ka %f %f %f", &clr[0], &clr[1], &clr[2]);
						for(i=0;i<model->NObjects;i++){
							for(u8 k=0;k<model->Object[i].NGroups;k++){
								if(model->Object[i].Group[k].sel) model->Object[i].Group[k].Ambient = GU_COLOR(clr[0], clr[1], clr[2], 1.0f);
							}
						} break;
					case 's':		// Ks
						sscanf(line, "Ks %f %f %f", &clr[0], &clr[1], &clr[2]);
						for(i=0;i<model->NObjects;i++){
							for(u8 k=0;k<model->Object[i].NGroups;k++){
								if(model->Object[i].Group[k].sel) model->Object[i].Group[k].Specular = GU_COLOR(clr[0], clr[1], clr[2], 1.0f);
							}
						} break;
					default: break;
				} break;
			case 'd':
				sscanf(line, "d %f", &clr[0]);
				for(i=0;i<model->NObjects;i++){
					for(u8 k=0;k<model->Object[i].NGroups;k++){
						if(model->Object[i].Group[k].sel){
							model->Object[i].Group[k].Diffuse &= 0x00FFFFFF;
							model->Object[i].Group[k].Diffuse |= ((u8)(clr[0] * 255.0f) << 24);
						}
					}
				} break;
			default: break;
		}
	}
	
	// Cierra el archivo MTL
	fclose(f); f = NULL;
	model->FaceFormat = faceformat;
	
	// Calcula las bounding boxes
	u8 k;
	for(i=0;i<model->NObjects;i++){
		// Calcula la bounding box
		model->Object[i].BBox[0].x = vtx[(model->Object[i].face[0].v[0]*3)];
		model->Object[i].BBox[0].y = vtx[(model->Object[i].face[0].v[0]*3)+1];
		model->Object[i].BBox[0].z = vtx[(model->Object[i].face[0].v[0]*3)+2];
		model->Object[i].BBox[1].x = model->Object[i].BBox[0].x;
		model->Object[i].BBox[1].y = model->Object[i].BBox[0].y;
		model->Object[i].BBox[1].z = model->Object[i].BBox[0].z;
		for(j=1;j<model->Object[i].NFaces;j++){
			for(k=0;k<3;k++){
//##### esto lo podemos usar para calcular el tamaño del borde por defecto (parece que calcula el tamaño del objeto)
				if(model->Object[i].BBox[0].x >= vtx[(model->Object[i].face[j].v[k]*3)]) model->Object[i].BBox[0].x = vtx[(model->Object[i].face[j].v[k]*3)];	// XMIN
				if(model->Object[i].BBox[0].y >= vtx[(model->Object[i].face[j].v[k]*3)+1]) model->Object[i].BBox[0].y = vtx[(model->Object[i].face[j].v[k]*3)+1];	// YMIN
				if(model->Object[i].BBox[0].z >= vtx[(model->Object[i].face[j].v[k]*3)+2]) model->Object[i].BBox[0].z = vtx[(model->Object[i].face[j].v[k]*3)+2];	// ZMIN
				if(model->Object[i].BBox[1].x <= vtx[(model->Object[i].face[j].v[k]*3)]) model->Object[i].BBox[1].x = vtx[(model->Object[i].face[j].v[k]*3)];	// XMAX
				if(model->Object[i].BBox[1].y <= vtx[(model->Object[i].face[j].v[k]*3)+1]) model->Object[i].BBox[1].y = vtx[(model->Object[i].face[j].v[k]*3)+1];	// YMAX
				if(model->Object[i].BBox[1].z <= vtx[(model->Object[i].face[j].v[k]*3)+2]) model->Object[i].BBox[1].z = vtx[(model->Object[i].face[j].v[k]*3)+2];	// ZMAX
			}
		}
	}
	
	//AMG_MessageBox(AMG_MESSAGE_STRING, 0, 0, "Gotcha!");
	/*f = fopen("log.txt", "wb");
	fprintf(f, "FaceFormat: %d\n", (int)model->FaceFormat);
	fprintf(f, "NObjects: %d noObjects: %d\n", (int)model->NObjects, (int)noObjects);
	fprintf(f, "NV: %d, NT: %d, NN: %d\n", (int)nvtx, (int)ntxc, (int)nnrm);
	for(u16 i=0;i<model->NObjects;i++){
		fprintf(f, "\nObject[%d]\n\n", (int)i);
		fprintf(f, "NFaces: %d\nNGroups: %d\nTriangleSize: %d bytes\n", (int)model->Object[i].NFaces, (int)model->Object[i].NGroups, (int)model->Object[i].TriangleSize);
		fprintf(f, "Data: %p\n", model->Object[i].Data);
		for(u8 k=0;k<model->Object[i].NGroups;k++){
			fprintf(f, "\n\tGroup[%d]\n\n\t", (int)k);
			fprintf(f, "%d to %d\n", (int)model->Object[i].Group[k].Start, (int)model->Object[i].Group[k].End); 
		}
	}
	fclose(f); f = NULL;*/
	
	// Libera TODOS los datos temporales usados
//##### añade outl
	tcnv = NULL; tcv = NULL; cv = NULL; cnv =  NULL; outl = NULL;
	free(line); line = NULL; free(mtlpath); mtlpath = NULL; free(straux); straux = NULL;
	free(vtx); vtx = NULL;
	if(ntxc) free(txc); txc = NULL;
	if(nnrm) free(nrm); nrm = NULL;
	for(i=0;i<model->NObjects;i++){
		free(model->Object[i].face); model->Object[i].face = NULL;
		for(u8 k=0;k<model->Object[i].NGroups;k++){
			free(model->Object[i].Group[k].mtlname); model->Object[i].Group[k].mtlname = NULL;
		}
	}
	
	// Devuelve el modelo creado
	return model;
error:
	// Libera datos del modelo
	if(f) fclose(f);
	if(model){
		if(model->Object){
			for(i=0;i<model->NObjects;i++){
				if(model->Object[i].face) free(model->Object[i].face);
				if(model->Object[i].Data) free(model->Object[i].Data);
				if(model->Object[i].Triangles) free(model->Object[i].Triangles);
//##### borra tambien el outline si hay error (tambien habra que meter esto en la funcion de borrar objeto)
				if(model->Object[i].OutLine) free(model->Object[i].OutLine);
				if(model->Object[i].BBox) free(model->Object[i].BBox);
				if(model->Object[i].tBBox) free(model->Object[i].tBBox);
				for(u8 k=0;k<model->Object[i].NGroups;k++){
					if(model->Object[i].Group[k].Texture){
						AMG_UnloadTexture(model->Object[i].Group[k].Texture);
						free(model->Object[i].Group[k].Texture);
					}
					if(model->Object[i].Group[k].mtlname) free(model->Object[i].Group[k].mtlname);
				}
			}
			free(model->Object);
		}
		free(model);
	}
	// Libera buffers temporales
	if(vtx) free(vtx);
	if(txc) free(txc);
	if(nrm) free(nrm);
	if(straux) free(straux);
	if(line) free(line);
	if(mtlpath) free(mtlpath);
	// Devuelve NULL
	return NULL;
}

void AMG_RenderModel(AMG_Model *model, int transparente){
	if(model == NULL) return;
	if (transparente <0 && transparente >2) transparente=0;
	for(u8 i=0;i<model->NObjects;i++){
		AMG_RenderObject(&model->Object[i], model->CelShading, transparente);
	}
}

// Renderiza un objeto 3D
void AMG_RenderObject(AMG_Object *model, u8 cs, int transparente){
	if (transparente <0 && transparente >3) transparente=0;
	// Comprueba si es NULL
	if(model == NULL) return;
	// Control de la iluminación
	u8 l2 = 0;

	if(!model->Lighting){
		l2 = sceGuGetStatus(GU_LIGHTING);
		sceGuDisable(GU_LIGHTING);
	}
	// Aplica las transformaciones necesarias	
	AMG_PushMatrix(GU_MODEL);
	AMG_LoadIdentity(GU_MODEL);
	
	//If no bullet, just apply position and rotation defined by user
	if (model->Physics == 0){
		AMG_Translate(GU_MODEL, &model->Pos);
		//AMG_Translate(GU_MODEL, &model->Origin);
		AMG_Rotate(GU_MODEL, &model->Rot);
	}
	//If has bullet physics, apply position and rotation from bullet physics
	else AMG_UpdateBody(model);
	
	AMG_Scale(GU_MODEL, &model->Scale);
	/*model->Origin.x = -model->Origin.x; model->Origin.y = -model->Origin.y; model->Origin.z = -model->Origin.z;
	AMG_Translate(GU_MODEL, &model->Origin);
	model->Origin.x = -model->Origin.x; model->Origin.y = -model->Origin.y; model->Origin.z = -model->Origin.z;
	*/
	AMG_UpdateMatrices();											// Actualiza las matrices
	sceGuColorMaterial(GU_DIFFUSE | GU_SPECULAR | GU_AMBIENT);		// Define los componentes materiales a usar
	sceGuSpecular(AMG.WorldSpecular);								// Define el valor especular del mundo 3D

  if (!skip){
	// Dibuja cada grupo de este objeto
	for(u8 i=0;i<model->NGroups;i++){
		// Define los materiales
		sceGuMaterial(GU_DIFFUSE, model->Group[i].Diffuse); 
		sceGuMaterial(GU_SPECULAR, model->Group[i].Specular); 
		sceGuMaterial(GU_AMBIENT, model->Group[i].Ambient);
		sceGuColor(model->Group[i].Diffuse); sceGuAmbient(model->Group[i].Ambient);
		if(model->Group[i].Texture != NULL){
			AMG_EnableTexture(model->Group[i].Texture);	// Activa la textura
		}else{
			sceGuDisable(GU_TEXTURE_2D);
		}
		u16 nfaces = (model->Group[i].End - model->Group[i].Start);

		//////////////////////////////////////////////////////////////////////////////////////
		//begin object will only draw the object if it is inside viewport, 
		//Do not use for big models
		//sceGuBeginObject(GU_VERTEX_32BITF,nfaces*3,0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize])); 
		switch(transparente){
			case 0:
				//dibuja las caras que miran a la camara
				sceGuEnable(GU_CULL_FACE);
					sceGuFrontFace(GU_CCW);
					sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));
			break;
			case 1:
				sceGuEnable(GU_CULL_FACE);
					sceGuFrontFace(GU_CW);
					sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));
				//dibuja encima las demás caras
					sceGuFrontFace(GU_CCW);
					sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));
			break;
			case 2:
				sceGuDisable(GU_CULL_FACE);
					sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));
			break;
			case 3: //solo para renderizar objectos reflejados
				sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0,(void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));	
			break;
			case 4: //solo para renderizar el objeto que hace de espejo
				sceGuDepthMask(GU_TRUE);
					sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGBA);
					sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0,(void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));					
				sceGuDepthMask(GU_FALSE);
			break;
		}
		// Dibuja la parte MultiTextura
		if((model->Group[i].MultiTexture != NULL) && (model->Group[i].Texture != NULL)){
			AMG_EnableTexture(model->Group[i].MultiTexture);
			// Dibuja solo las que miran hacia la cámara
			sceGuEnable(GU_CULL_FACE);
			//sceGuFrontFace(GU_CW);
			sceGuFrontFace(GU_CCW);
			sceGuDrawArray(Render_Style, model->Flags, nfaces*3, 0, (void*)&(((u8*)model->Data)[model->Group[i].Start*model->TriangleSize]));
			AMG.DrawnVertices += (nfaces*3);
		}
		
		//sceGuEndObject();
		
		//sceGuBeginObject(GU_VERTEX_32BITF,nfaces*3,0,model->OutLine); 
		// Dibuja la parte Cel-Shading (el outline)
		if(cs==1 && model->OutLine){
			AMG_Light[2].Pos.x = AMG_Light[3].Pos.y = 1.0f;		// Configura la matriz del envmap
			sceGuDisable(GU_TEXTURE_2D);
			l = sceGuGetStatus(GU_LIGHTING);
			sceGuDisable(GU_LIGHTING);
			sceGuEnable(GU_CULL_FACE);
	        sceGuFrontFace(GU_CW);
			sceGuColor(model->OutlineColor);
			AMG_UpdateMatrices();
				sceGuDrawArray(GU_TRIANGLES, (GU_VERTEX_32BITF | GU_TRANSFORM_3D), nfaces*3, 0, model->OutLine);
			sceGuDisable(GU_CULL_FACE);
			if(l == GU_TRUE) sceGuEnable(GU_LIGHTING);
			AMG.DrawnVertices += (nfaces*3);
			sceGuColor(GU_RGBA(255, 255, 255, 0xFF));
		}
		//sceGuEndObject();
	}
	
	//Draw Fur/grass if any
	if(model->Fur){
		int size = model->Group[model->FurGroup].Texture->Width;
		int i;
		int FurGroup = model->FurGroup;
		u32 dataoffset = 0;
		u32 nfaces = (model->Group[FurGroup].End - model->Group[FurGroup].Start);
		u32 offset = nfaces*3;
		u8 layers = model->FurLayers;
		
		//sceGuBeginObject(GU_VERTEX_32BITF,nfaces*3,0, (void*)&(((u8*)model->Data)[model->Group[FurGroup].Start*model->TriangleSize])); 
		
		sceGuColorMaterial(GU_DIFFUSE | GU_SPECULAR | GU_AMBIENT);		// Define los componentes materiales a usar
		sceGuSpecular(AMG.WorldSpecular);	
		sceGuMaterial(GU_DIFFUSE, model->Group[FurGroup].Diffuse); 
		sceGuMaterial(GU_SPECULAR, model->Group[FurGroup].Specular); 
		sceGuMaterial(GU_AMBIENT, model->Group[FurGroup].Ambient);
		sceGuColor(model->Group[FurGroup].Diffuse); sceGuAmbient(model->Group[FurGroup].Ambient);
		
		// setup texture 
		sceGuTexFilter(model->FurFilter,model->FurFilter);
		sceGuEnable(GU_TEXTURE_2D);
		sceGuTexMode(GU_PSM_4444,0,0,0);
		
		sceGuEnable(GU_CULL_FACE);
		sceGuFrontFace(GU_CCW);
		AMG_UpdateMatrices();
		
		for (i= 0; i != layers; i++){
			sceGuTexImage(0,size,size,size,model->TexFur[i].Data);
			sceGuDrawArray(GU_TRIANGLES, model->Flags, nfaces*3, 0, model->Fur+dataoffset);
			dataoffset += offset;
		}
		sceGuDisable(GU_CULL_FACE);
		//sceGuEndObject();
	}
  }
	// Actualiza el número de vértices dibujados
	AMG.DrawnVertices += (model->NFaces*3);
	/** Actualiza la Bounding Box **/
	model->tBBox[0].x = model->BBox[0].x + model->Pos.x;
	model->tBBox[0].y = model->BBox[0].y + model->Pos.y;
	model->tBBox[0].z = model->BBox[0].z + model->Pos.z;
	model->tBBox[1].x = model->BBox[1].x + model->Pos.x;
	model->tBBox[1].y = model->BBox[1].y + model->Pos.y;
	model->tBBox[1].z = model->BBox[1].z + model->Pos.z;
	model->Centre.x = (model->BBox[0].x + model->BBox[1].x)/2.0f;
	model->Centre.y = (model->BBox[0].y + model->BBox[1].y)/2.0f;
	model->Centre.z = (model->BBox[0].z + model->BBox[1].z)/2.0f;
	model->tCentre.x = model->Centre.x + model->Pos.x;
	model->tCentre.y = model->Centre.y + model->Pos.y;
	model->tCentre.z = model->Centre.z + model->Pos.z;
	/*******************************/
	sceGuDisable(GU_CULL_FACE);
    AMG_PopMatrix(GU_MODEL);
	// Control de la iluminación
	if((!model->Lighting) && (l2)) sceGuEnable(GU_LIGHTING);
}

// Elimina un objeto 3D
void AMG_UnloadObject(AMG_Object *model){
	// Libera el objeto
	if(model == NULL) return;
	if(model->Data != NULL) free(model->Data); model->Data = NULL;
	if(model->BBox != NULL) free(model->BBox); model->BBox = NULL;
	if(model->tBBox != NULL) free(model->tBBox); model->tBBox = NULL;
	if(model->Triangles) free(model->Triangles); model->Triangles = NULL;
	if(model->OutLine) free(model->OutLine); model->OutLine = NULL;
	// Libera los grupos de materiales
	for(u8 i=0;i<model->NGroups;i++){
		if(model->Group[i].Texture != NULL){
			AMG_UnloadTexture(model->Group[i].Texture);
			free(model->Group[i].Texture); model->Group[i].Texture = NULL;
		}
	}
	free(model->Group); model->Group = NULL;
}

// Elimina un modelo 3D
void AMG_UnloadModel(AMG_Model *model){
	if(model == NULL) return;
	u16 i;
	for(i=0;i<model->NObjects;i++){
		AMG_UnloadObject(&model->Object[i]);
	}
	model->FaceFormat = 0; model->NObjects = 0; model->CelShading = 0;
	free(model->Object); model->Object = NULL;
} 

void AMG_RenderVehicle(AMG_Model *model,AMG_Model *wheel){
	int i;
	
	//draw chasis
	AMG_PushMatrix(GU_MODEL);
	AMG_LoadIdentity(GU_MODEL);

	AMG_UpdateVehicleBody(model);
	AMG_UpdateMatrices();
	sceGuColorMaterial(GU_DIFFUSE | GU_SPECULAR | GU_AMBIENT);		// Define los componentes materiales a usar
	sceGuSpecular(AMG.WorldSpecular);
	sceGuMaterial(GU_DIFFUSE, model->Object[0].Group[0].Diffuse); 
	sceGuMaterial(GU_SPECULAR, model->Object[0].Group[0].Specular); 
	sceGuMaterial(GU_AMBIENT, model->Object[0].Group[0].Ambient);
	sceGuColor(model->Object[0].Group[0].Diffuse); sceGuAmbient(model->Object[0].Group[0].Ambient);
	if(model->Object[0].Group[0].Texture != NULL){
		AMG_EnableTexture(model->Object[0].Group[0].Texture);	// Activa la textura
	}else{
		sceGuDisable(GU_TEXTURE_2D);
	}
	u16 nface = (model->Object[0].Group[0].End - model->Object[0].Group[0].Start);
	sceGuDrawArray(GU_TRIANGLES, model->Object[0].Flags, nface*3, 0, (void*)&(((u8*)model->Object[0].Data)[model->Object[0].Group[0].Start*model->Object[0].TriangleSize]));
	
	AMG_PopMatrix(GU_MODEL);
	
	//set up wheels material
	sceGuColorMaterial(GU_DIFFUSE | GU_SPECULAR | GU_AMBIENT);		// Define los componentes materiales a usar
	sceGuSpecular(AMG.WorldSpecular);
	sceGuMaterial(GU_DIFFUSE, wheel->Object[0].Group[0].Diffuse); 
	sceGuMaterial(GU_SPECULAR, wheel->Object[0].Group[0].Specular); 
	sceGuMaterial(GU_AMBIENT, wheel->Object[0].Group[0].Ambient);
	sceGuColor(wheel->Object[0].Group[0].Diffuse); sceGuAmbient(wheel->Object[0].Group[0].Ambient);
	if(wheel->Object[0].Group[0].Texture != NULL){
		AMG_EnableTexture(wheel->Object[0].Group[0].Texture);	// Activa la textura
	}else{
		sceGuDisable(GU_TEXTURE_2D);
	}
	//Draw wheels
	for (i=0;i!=4;i++){
		AMG_PushMatrix(GU_MODEL);
		AMG_LoadIdentity(GU_MODEL);
		AMG_UpdateVehicleWheel(model,i);
		AMG_UpdateMatrices();
		u16 nface = (wheel->Object[0].Group[0].End - wheel->Object[0].Group[0].Start);
		sceGuDrawArray(GU_TRIANGLES, wheel->Object[0].Flags, nface*3, 0, (void*)&(((u8*)wheel->Object[0].Data)[wheel->Object[0].Group[0].Start*wheel->Object[0].TriangleSize]));
		AMG_PopMatrix(GU_MODEL);
	}
}


// Carga un modelo MD2
AMG_Actor *AMG_LoadActor(const char *md2fname, int a, u32 psm){	
	int i;
	int j;
	int k;
	if (psm == 0) psm = GU_PSM_8888;
	AMG_Actor *actor = NULL;
	actor = (AMG_Actor*) calloc (1, sizeof(AMG_Actor));
	actor->Object = (AnimModel*) calloc (1, sizeof(AnimModel));
	//////////////////////////////////
	actor->Optimized = a;
	actor->clone = 0;
	MD2Model m;
	memset(&m,0,sizeof(MD2Model));
	FILE *file=fopen(md2fname,"rb");
	
	if(!file){ AMG_Error(AMG_OPEN_FILE, 0, md2fname); goto error;}
{
	MD2Header header;
	fread(&header,sizeof(header),1,file);
	
	// Copy the header attributes.
	m.frameCount=header.numFrames;
	m.glcmdCount=header.numGlcmds;
	m.vertexCount=header.numVertices;
	m.skinCount=header.numSkins;
	m.texCoordCount=header.numSt;
	m.triangleCount=header.numTris;
	m.skinWidth=header.skinwidth;
	m.skinHeight=header.skinheight;
	
	fseek(file,header.offsetSkins,SEEK_SET);
	m.skins=(MD2Skin *)malloc(sizeof(MD2Skin)*header.numSkins);
	fread(m.skins,sizeof(MD2Skin),header.numSkins,file);
	
	fseek(file,header.offsetSt,SEEK_SET);
	m.texCoords=(MD2TexCoord *)malloc(sizeof(MD2TexCoord)*header.numSt);
	fread(m.texCoords,sizeof(MD2TexCoord),header.numSt,file);
	
	fseek(file,header.offsetTris,SEEK_SET);
	m.triangles=(MD2Triangle *)malloc(sizeof(MD2Triangle)*header.numTris);
	fread(m.triangles,sizeof(MD2Triangle),header.numTris,file);
	
	fseek(file,header.offsetFrames,SEEK_SET);
	m.frames=(MD2Frame *)malloc(sizeof(MD2Frame)*header.numFrames);
	//Read Frames
	for(i=0;i<m.frameCount;i++) {
		fread(m.frames+i,sizeof(MD2Frame)-4,1,file);
		m.frames[i].verts=(MD2Vertex *)malloc(sizeof(MD2Vertex)*m.vertexCount);
		fread(m.frames[i].verts,sizeof(MD2Vertex),m.vertexCount,file);	
	}
	
	fseek(file,header.offsetGlcmds,SEEK_SET);
	m.glcmds=(int *)malloc(sizeof(int)*header.numGlcmds);
	fread(m.glcmds,sizeof(int),header.numGlcmds,file);
	fclose(file);
	
	// Convert to AnimMesh format
	actor->Object[0].texture=0;
	actor->Object[0].MultiTexture = 0;
	actor->Object[0].frameCount=m.frameCount;
	actor->Object[0].polyCount=m.triangleCount;
	actor->Object[0].skinWidth=m.skinWidth;
	actor->Object[0].skinHeight=m.skinHeight;
	actor->Object[0].index=(int*) malloc(sizeof(int*)*m.glcmdCount);
	//vertex index
	for(i=0;i<m.glcmdCount;i++)actor->Object[0].index[i] = m.glcmds[i];

	//GUARDA LOS VERTICES DE TODOS LOS FRAMES
	if (actor->Optimized == 0){
		actor->Object[0].Data = (AMG_Vertex_TNV*) malloc( sizeof(AMG_Vertex_TNV)*actor->Object->frameCount*actor->Object->polyCount*3);
	}
	if (actor->Optimized == 1){
		actor->Object[0].Data_OP = (AMG_Vertex_V*) malloc( sizeof(AMG_Vertex_V)*actor->Object->frameCount*actor->Object->polyCount*3);
	}
	float invSkinWidth=1.0f/actor->Object[0].skinWidth,invSkinHeight=1.0f/actor->Object[0].skinHeight;
	int frame = 0;

	for(i=0;i<actor->Object[0].frameCount;i++) {
		//ALTERNATE FRAMES FOR MORPHOWEIGHT
	    MD2Frame *f=m.frames+i;
		ScePspFVector3 s1,t1;
		s1=f->scale;
		t1=f->translate;
		
    	for(j=0;j<actor->Object[0].polyCount;j++) {
    		// Decompress a triangle from the frame.
    		for(k=0;k<3;k++) {
    			int v0=m.triangles[j].vertex[k];
				
				if (actor->Optimized == 0){
				actor->Object[0].Data[frame+(j*3+k)].z=f->verts[v0].v[0]*s1.x+t1.x;
				actor->Object[0].Data[frame+(j*3+k)].y=f->verts[v0].v[2]*s1.z+t1.z;
				actor->Object[0].Data[frame+(j*3+k)].x=f->verts[v0].v[1]*s1.y+t1.y;
				
				actor->Object[0].Data[frame+(j*3+k)].u=m.texCoords[m.triangles[j].st[k]].s*invSkinWidth;
				actor->Object[0].Data[frame+(j*3+k)].v=m.texCoords[m.triangles[j].st[k]].t*invSkinHeight;
				//vertex normal
				actor->Object[0].Data[frame+(j*3+k)].nz = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][0];
				actor->Object[0].Data[frame+(j*3+k)].nx = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][1];
				actor->Object[0].Data[frame+(j*3+k)].ny = Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][2];
				}
				if (actor->Optimized == 1){
				actor->Object[0].Data_OP[frame+(j*3+k)].z=f->verts[v0].v[0]*s1.x+t1.x;
				actor->Object[0].Data_OP[frame+(j*3+k)].y=f->verts[v0].v[2]*s1.z+t1.z;
				actor->Object[0].Data_OP[frame+(j*3+k)].x=f->verts[v0].v[1]*s1.y+t1.y;
				}
			}
    	}
		frame+=actor->Object[0].polyCount*3;
	}

	actor->Origin.x = 0.0f; 
	actor->Origin.y = 0.0f; 
	actor->Origin.z = 0.0f;
	
	//RESERVA ESPACIO EN RAM PARA DOS FRAMES
	if (actor->Optimized == 0){	
		actor->Object[0].vertices = (MorphVertex *) malloc (sizeof(MorphVertex)*actor->Object[0].polyCount*3);
	}
	//SI EL OBJETO SE CARGA OPTIMIZADO, AÑADE LAS NORMALES Y COORDENADAS DE TEXTURA FIJAS A ESOS DOS FRAMES
	if (actor->Optimized == 1){
		actor->Object[0].vertices_OP = (MorphVertex_OP *) malloc (sizeof(MorphVertex_OP)*actor->Object[0].polyCount*3);
		MD2Frame *f=m.frames;
		for(j=0;j<actor->Object[0].polyCount;j++) {
    		// Decompress a triangle from the frame.
    		for(k=0;k<3;k++) {
    			int v0=m.triangles[j].vertex[k];
				
				actor->Object[0].vertices_OP[j*3+k].u=m.texCoords[m.triangles[j].st[k]].s*invSkinWidth;
				actor->Object[0].vertices_OP[j*3+k].v=m.texCoords[m.triangles[j].st[k]].t*invSkinHeight;
				actor->Object[0].vertices_OP[j*3+k].nz = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][0];
				actor->Object[0].vertices_OP[j*3+k].nx = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][1];
				actor->Object[0].vertices_OP[j*3+k].ny = Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][2];
				
				actor->Object[0].vertices_OP[j*3+k].u1=m.texCoords[m.triangles[j].st[k]].s*invSkinWidth;
				actor->Object[0].vertices_OP[j*3+k].v1=m.texCoords[m.triangles[j].st[k]].t*invSkinHeight;
				actor->Object[0].vertices_OP[j*3+k].nz1 = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][0];
				actor->Object[0].vertices_OP[j*3+k].nx1 = -Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][1];
				actor->Object[0].vertices_OP[j*3+k].ny1 = Q2_VERTEX_NORMAL_TABLE[f->verts[v0].normalindex][2];
			}
		}
	}
	//////////////////////////////////////////////////////
	// Clean up
	if(m.skins) free(m.skins); m.skins=0;
	if(m.texCoords) free(m.texCoords); m.texCoords=0;
	if(m.triangles) free(m.triangles); m.triangles=0;
	for(i=0;i<m.frameCount;i++) {
		if(m.frames[i].verts) free(m.frames[i].verts);
	}
	if(m.frames) free(m.triangles); m.triangles=0;
	if(m.glcmds) free(m.glcmds); m.glcmds=0;

	/////////////////////////////////
	
	if(!actor->Object) goto error;
	
	//get texture with the same name as the file
	char *texturename = (char*) calloc (strlen(md2fname), sizeof(char));
	strncpy(texturename,md2fname,strlen(md2fname)-3);
	strcat(texturename,"png");
	AMG_Texture *texture = AMG_LoadTexture(texturename,AMG_TEX_VRAM,psm);
	actor->Object[0].texture=texture;
	AMG_SwizzleTexture(actor->Object[0].texture);

	actor->Scale.x = 1; actor->Scale.y = 1; actor->Scale.z = 1;
	actor->Object[0].morphoweight = 0;
	actor->Object[0].frame = 0;
	
	//SIZE
	actor->Object[0].BBox = (ScePspFVector3*) calloc (2, sizeof(ScePspFVector3));
	if (actor->Optimized == 0){
	// Calcula la bounding box
	for(i=0;i<actor->Object->polyCount*3;i++) {
		if (actor->Object[0].BBox[0].x >= actor->Object[0].Data[i].x) actor->Object[0].BBox[0].x = actor->Object[0].Data[i].x; //MIN X
		if (actor->Object[0].BBox[0].y >= actor->Object[0].Data[i].y) actor->Object[0].BBox[0].y = actor->Object[0].Data[i].y; //MIN Y
		if (actor->Object[0].BBox[0].z >= actor->Object[0].Data[i].z) actor->Object[0].BBox[0].z = actor->Object[0].Data[i].z; //MIN Z
		if (actor->Object[0].BBox[1].x <= actor->Object[0].Data[i].x) actor->Object[0].BBox[1].x = actor->Object[0].Data[i].x; //MAX X
	    if (actor->Object[0].BBox[1].y <= actor->Object[0].Data[i].y) actor->Object[0].BBox[1].y = actor->Object[0].Data[i].y; //MAX Y
		if (actor->Object[0].BBox[1].z <= actor->Object[0].Data[i].z) actor->Object[0].BBox[1].z = actor->Object[0].Data[i].z; //MAX Z
	}
	}
	if (actor->Optimized == 1){
	// Calcula la bounding box
	for(i=0;i<actor->Object->polyCount*3;i++) {
		if (actor->Object[0].BBox[0].x >= actor->Object[0].Data_OP[i].x) actor->Object[0].BBox[0].x = actor->Object[0].Data_OP[i].x; //MIN X
		if (actor->Object[0].BBox[0].y >= actor->Object[0].Data_OP[i].y) actor->Object[0].BBox[0].y = actor->Object[0].Data_OP[i].y; //MIN Y
		if (actor->Object[0].BBox[0].z >= actor->Object[0].Data_OP[i].z) actor->Object[0].BBox[0].z = actor->Object[0].Data_OP[i].z; //MIN Z
		if (actor->Object[0].BBox[1].x <= actor->Object[0].Data_OP[i].x) actor->Object[0].BBox[1].x = actor->Object[0].Data_OP[i].x; //MAX X
	    if (actor->Object[0].BBox[1].y <= actor->Object[0].Data_OP[i].y) actor->Object[0].BBox[1].y = actor->Object[0].Data_OP[i].y; //MAX Y
		if (actor->Object[0].BBox[1].z <= actor->Object[0].Data_OP[i].z) actor->Object[0].BBox[1].z = actor->Object[0].Data_OP[i].z; //MAX Z
	}
	}
	actor->Object[0].Lighting = 1;
	actor->Mirror = 0;
	actor->Object[0].frame = 0;
	actor->Object[0].endFrame = 1;
	actor->clone = 0;
	return actor;
}
error:	
	// Libera el objeto
	
	if(actor->Object[0].Data != NULL) free(actor->Object[0].Data); actor->Object[0].Data = NULL;
	if(actor->Object[0].Data_OP != NULL) free(actor->Object[0].Data_OP); actor->Object[0].Data_OP = NULL;
	if(actor->Object[0].vertices != NULL) free (actor->Object[0].vertices); actor->Object[0].vertices = NULL;
	if(actor->Object[0].vertices_OP != NULL) free (actor->Object[0].vertices_OP); actor->Object[0].vertices_OP = NULL;
	if(actor->Object[0].BBox != NULL) free(actor->Object[0].BBox); actor->Object[0].BBox = NULL;
	//if(actor->Object[0].OutLine) free(actor->Object[0].OutLine); actor->Object[0].OutLine = NULL;
	// Libera los grupos de materiales
	if(actor->Object[0].texture != NULL){
			AMG_UnloadTexture(actor->Object[0].texture);
			free(actor->Object[0].texture); actor->Object[0].texture = NULL;
	}
	if(actor->Object[0].MultiTexture != NULL){
			AMG_UnloadTexture(actor->Object[0].MultiTexture);
			free(actor->Object[0].MultiTexture); actor->Object[0].MultiTexture = NULL;
	}
	return NULL;
}

// Clona un actor
AMG_Actor *AMG_CloneActor(AMG_Actor *actor){

	AMG_Actor *actorc = NULL;
	actorc = (AMG_Actor*) calloc (1, sizeof(AMG_Actor));
	actorc->Object = (AnimModel*) calloc (1, sizeof(AnimModel));
	//////////////////////////////////
	actorc->Object[0].texture = actor->Object[0].texture;
	actorc->Object[0].MultiTexture = actor->Object[0].MultiTexture;
	actorc->Object[0].Data = (AMG_Vertex_TNV*) actor->Object[0].Data;
	actorc->Object[0].Data_OP = (AMG_Vertex_V*) actor->Object[0].Data_OP;
	
	actorc->Optimized = actor->Optimized;
	//RESERVA ESPACIO EN RAM PARA DOS FRAMES
	if (actorc->Optimized == 0){	
		actorc->Object[0].vertices = (MorphVertex *) malloc (sizeof(MorphVertex)*actor->Object[0].polyCount*3);
	}
	//SI EL OBJETO ORIGINAL SE CARGO OPTIMIZADO, AÑADE LAS NORMALES Y COORDENADAS DE TEXTURA FIJAS A ESOS DOS FRAMES
	if (actorc->Optimized == 1){
		actorc->Object[0].vertices_OP = (MorphVertex_OP *) malloc (sizeof(MorphVertex_OP)*actor->Object[0].polyCount*3);
		actorc->Object[0].vertices_OP = actor->Object[0].vertices_OP;
	}
	
	actorc->Object[0].Lighting = 1;
	actorc->Mirror = 0;
	actorc->Object[0].frame = 0;
	actorc->Object[0].endFrame = 1;
	actorc->Scale.x = 1; actor->Scale.y = 1; actor->Scale.z = 1;
	actorc->Object[0].morphoweight = 0;
	actorc->Object[0].frame = 0;
	
	actorc->Object[0].BBox = actor->Object[0].BBox;
	
	actorc->clone = 1;	
	return actorc;
}	

// Configura un actor MD2
void AMG_ConfigActor(AMG_Actor *actor,int begin,int end, int speed){
	actor->Object[0].loop = 1;
	actor->Object[0].speed = speed;	
	actor->Object[0].startFrame = begin;
	actor->Object[0].endFrame = end;
}

// Dibuja un actor MD2
void AMG_RenderActor(AMG_Actor *actor, int transparent){
	sceGuSpecular(0xffffffff);		// Actualiza las matrices
	sceGuColor(0xffffffff); sceGuAmbient(0xff111111);	
	// Save the context, do the transform, draw the meshes restore the context	
	AnimModel *model=actor->Object;
	if(!model) return;
	
	AMG_Texture* tex=actor->Object->texture;
	if (!skip) {if(tex !=NULL) AMG_EnableTexture(tex);}
	// Control de la iluminación
	u8 l2 = 0;
	if ((!actor->Object->Lighting) || (actor->Optimized == 1)) {
		l2 = sceGuGetStatus(GU_LIGHTING);
		sceGuDisable(GU_LIGHTING);
	}
	
	u32 v = 0;
	//GET PHYSICS ID
	if(actor->Object[0].phys == 1) v = actor->Object[0].bullet_id;

	AMG_PushMatrix(GU_MODEL);
	if (actor->Object[0].phys == 0) AMG_Translate(GU_MODEL, &actor->Pos);
	else AMG_UpdateActorBody(actor);
	
	AMG_Rotate(GU_MODEL, &actor->Rot);
	AMG_Scale(GU_MODEL, &actor->Scale);
	AMG_UpdateMatrices();	
	
	//Be sure the model frame is inside the animation
	if (actor->Object[0].frame < actor->Object[0].startFrame) actor->Object[0].frame = actor->Object[0].startFrame;
	if (actor->Object[0].frame > actor->Object[0].endFrame) actor->Object[0].frame = actor->Object[0].startFrame;
	
	//UPDATE FRAME
	int frame,nextframe,start,end;
	float sp;
	start = actor->Object[0].startFrame;
	end = actor->Object[0].endFrame;
	sp= actor->Object[0].speed / 100;
	sceKernelDcacheWritebackInvalidateAll();	
	

	if (actor->Mirror == 0){
		if (actor->Object[0].morphoweight > 1) {
			actor->Object[0].morphoweight = 0;
			actor->Object[0].frame++;
		}
		if (actor->Object[0].frame == end) 
			actor->Object[0].frame = start;
		
		frame=actor->Object[0].frame;
		nextframe=actor->Object[0].frame+1;
		if (actor->Object[0].frame == end-1) nextframe=start;
	
		if (actor->Object[0].morphoweight == 0){
			if (actor->Optimized == 0){
				//FILL MORPHO VERTEX STRUCT WITH TWO FRAMES (BY micronn)
				AMG_Vertex_TNV *pc, *pl;
				char *pm;
				for (pm = (char*)&actor->Object[0].vertices[0].v0, pc = actor->Object[0].Data + (frame*actor->Object[0].polyCount*3), pl = &actor->Object[0].Data[actor->Object[0].polyCount*3] + (frame*actor->Object[0].polyCount*3); pc < pl; pc++) {
					*((AMG_Vertex_TNV*)pm) = *pc;
					pm += sizeof(MorphVertex);
				}
				for (pm = (char*)&actor->Object[0].vertices[0].v1, pc = actor->Object[0].Data + (nextframe*actor->Object[0].polyCount*3), pl = &actor->Object[0].Data[actor->Object[0].polyCount*3]+(nextframe*actor->Object[0].polyCount*3); pc < pl; pc++) {
					*((AMG_Vertex_TNV*)pm) = *pc;
					pm += sizeof(MorphVertex);
				}
			}
			if (actor->Optimized == 1){
				//FILL MORPHO VERTEX OPTIMIZED
				AMG_Vertex_V *pc, *pl;
				char *pm;
				for (pm = (char*)&actor->Object[0].vertices_OP[0].v2, pc = actor->Object[0].Data_OP + (frame*actor->Object[0].polyCount*3), pl = &actor->Object[0].Data_OP[actor->Object[0].polyCount*3] + (frame*actor->Object[0].polyCount*3); pc < pl; pc++) {
					*((AMG_Vertex_V*)pm) = *pc;
					pm += sizeof(MorphVertex_OP);
				}
				for (pm = (char*)&actor->Object[0].vertices_OP[0].v3, pc = actor->Object[0].Data_OP + (nextframe*actor->Object[0].polyCount*3), pl = &actor->Object[0].Data_OP[actor->Object[0].polyCount*3]+(nextframe*actor->Object[0].polyCount*3); pc < pl; pc++) {
					*((AMG_Vertex_V*)pm) = *pc;
					pm += sizeof(MorphVertex_OP);
				}
			}
		}
	}

	sceGuMorphWeight(0,1-actor->Object[0].morphoweight);
	sceGuMorphWeight(1,actor->Object[0].morphoweight);
	
	//sceGuDisable(GU_CULL_FACE);
	if (!skip){
		if (actor->Optimized == 0)sceGuBeginObject(GU_VERTEX_32BITF,actor->Object[0].polyCount*3,0,actor->Object[0].vertices); 
		if (actor->Optimized == 1)sceGuBeginObject(GU_VERTEX_32BITF,actor->Object[0].polyCount*3,0,actor->Object[0].vertices_OP); 
		if (transparent == 1){
			sceGuEnable(GU_CULL_FACE);
			sceGuFrontFace(GU_CCW);
			if (actor->Optimized == 0)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices);
			if (actor->Optimized == 1)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices_OP);
		}
		sceGuFrontFace(GU_CW);
		
		if (actor->Mirror == 0){
			if (actor->Optimized == 0)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices);
			if (actor->Optimized == 1)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices_OP);
			// Dibuja la parte MultiTextura
			if((actor->Object[0].MultiTexture != NULL) && (actor->Object[0].texture != NULL)){
				AMG_EnableTexture(actor->Object[0].MultiTexture);
				// Dibuja solo las que miran hacia la cámara
				sceGuEnable(GU_CULL_FACE);
				sceGuFrontFace(GU_CW);
				if (actor->Optimized == 0)
					sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices);
				if (actor->Optimized == 1)
					sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices_OP);
			}
			sceGuDisable(GU_CULL_FACE);
		}
		if (actor->Mirror == 1){
			if (actor->Optimized == 0)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices);
			if (actor->Optimized == 1)
				sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_VERTICES(2)|GU_TRANSFORM_3D,actor->Object[0].polyCount*3,0,actor->Object[0].vertices_OP);
		}
		sceGuEndObject();
	}	

	AMG_PopMatrix(GU_MODEL);
	if((!actor->Object->Lighting) && (l2))sceGuEnable(GU_LIGHTING);
	if((actor->Optimized == 1) && (l2))sceGuEnable(GU_LIGHTING);
	
	/*if(actor->Object[0].phys == 1) {
		actor->Pos.y = actor->Pos.y-(((actor->Object[0].BBox[1].x - actor->Object[0].BBox[0].x)/2)*actor->Scale.x);
	}*/
	if (actor->Mirror == 0) actor->Object[0].morphoweight+=sp;
}

// Elimina un actor 3D
void AMG_UnloadActor(AMG_Actor *actor){
	// Libera el objeto
	if(actor == NULL) return;
	if(actor->Object[0].Data != NULL) free(actor->Object[0].Data); actor->Object[0].Data = NULL;
	if(actor->Object[0].Data_OP != NULL) free(actor->Object[0].Data_OP); actor->Object[0].Data_OP = NULL;
	if(actor->Object[0].vertices != NULL) free (actor->Object[0].vertices); actor->Object[0].vertices = NULL;
	if(actor->Object[0].vertices_OP != NULL) free (actor->Object[0].vertices_OP); actor->Object[0].vertices_OP = NULL;
	if(actor->Object[0].BBox != NULL) free(actor->Object[0].BBox); actor->Object[0].BBox = NULL;
	//if(actor->Object[0].OutLine) free(actor->Object[0].OutLine); actor->Object[0].OutLine = NULL;
	// Libera los grupos de materiales
	if(actor->Object[0].texture != NULL){
			AMG_UnloadTexture(actor->Object[0].texture);
			free(actor->Object[0].texture); actor->Object[0].texture = NULL;
	}
	if(actor->Object[0].MultiTexture != NULL){
			AMG_UnloadTexture(actor->Object[0].MultiTexture);
			free(actor->Object[0].MultiTexture); actor->Object[0].MultiTexture = NULL;
	}
}


/*
// Tracking Modelo-Modelo
void Track3DObj(AMG_Model *model, AMG_Model *model1, int track,int x, int y, int z){
	if (model->Object[0].bullet_id != NULL);
	ScePspFVector3 Pos;
	ScePspFVector3 Rot;
}
// Tracking Modelo-Actor
void Track3DObj(AMG_Model *model, AMG_Actor *actor, int track,int x, int y, int z){
	bullet_id
	phys
	ScePspFVector3 Pos;
	ScePspFVector3 Rot;
}
*/
// Tracking Actor-Actor
/*
void Track3DObj(AMG_Actor *actor, AMG_Actor *actor1, float speed, ScePspFVector3 ax){
	{}
	if (actor->Object[0].phys == 0){
		float x =(actor->Pos.x-actor1->Pos.x);
		float y =(actor->Pos.y-Purpl1->Pos.y);
		float z =(actor->Pos.z-Purple->Pos.z);
		actor->Rot.y = vfpu_atan2f(x,z);
		actor->Rot.z = vfpu_atan2f(x,z);
		actor->Pos.x += x/10 *speed;
		actor->Pos.z += z/10 *speed;
	}
	if (actor->Object[0].phys == 1){
		float x =(actor->Pos.x-actor->Pos.x);
		float z =(actor->Pos.z-Purple->Pos.z);
		actor->Rot.y = vfpu_atan2f(x,z);
		AMG_SetActorLinearVelocity(actor, (x/10) *speed, 0,(z/10)*speed);			
	}
}*/

// Comprueba la colision entre 2 objetos con Bounding Box
u8 AMG_CheckBBoxCollision(const AMG_Object *obj1, const AMG_Object *obj2){
	if((obj1 == NULL) || (obj2 == NULL)) return 0;
	if(((obj1->tBBox[0].x) <= (obj2->tBBox[1].x))  // Borde derecho obj1 > Borde izquierdo obj2
	 && ((obj1->tBBox[1].x) >= (obj2->tBBox[0].x))  // Borde izquierdo obj1 < Borde derecho obj2
	 && ((obj1->tBBox[0].y) <= (obj2->tBBox[1].y))  // Borde inferior obj1 < Borde superior obj2
	 && ((obj1->tBBox[1].y) >= (obj2->tBBox[0].y))  // Borde superior obj1 > Borde inferior obj2
	 && ((obj1->tBBox[0].z) <= (obj2->tBBox[1].z))  
	 && ((obj1->tBBox[1].z) >= (obj2->tBBox[0].z))) return 1;
	return 0;
}

// Normaliza un modelo 3D
void AMG_NormalizeModel(AMG_Model *model){
	if(model == NULL) return;
	u8 i; u32 j;
	ScePspFVector3 vec;
	AMG_Vertex_TNV *tcnv; AMG_Vertex_NV *cnv; AMG_Vertex_V *cv; AMG_Vertex_TV *tcv;
	// Procesa cada vertice
	for(i=0;i<model->NObjects;i++){
		// Normaliza las caras
		switch(model->FaceFormat){
			case 0:				// v+n
				cnv = (AMG_Vertex_NV*) model->Object[i].Data;
				for(j=0;j<(model->Object[i].NFaces*3);j++){
					vec.x = cnv[j].x; vec.y = cnv[j].y; vec.z = cnv[j].z;
					AMG_Normalize(&vec);
					cnv[j].nx = vec.x; cnv[j].ny = vec.y; cnv[j].nz = vec.z;
				}
				break;
			case 2:				// v+n+t
				tcnv = (AMG_Vertex_TNV*) model->Object[i].Data;
				for(j=0;j<(model->Object[i].NFaces*3);j++){
					vec.x = tcnv[j].x; vec.y = tcnv[j].y; vec.z = tcnv[j].z;
					AMG_Normalize(&vec);
					tcnv[j].nx = vec.x; tcnv[j].ny = vec.y; tcnv[j].nz = vec.z;
				}
				break;
			case 1: case 5:		// v
				// Transforma a CNV
				cnv = (AMG_Vertex_NV*) calloc (model->Object[i].NFaces*3, sizeof(AMG_Vertex_NV));
				cv = (AMG_Vertex_V*) model->Object[i].Data;
				model->FaceFormat = 1;
				for(j=0;j<(model->Object[i].NFaces*3);j++){
					vec.x = cv[j].x; vec.y = cv[j].y; vec.z = cv[j].z;
					AMG_Normalize(&vec);
					cnv[j].nx = vec.x; cnv[j].ny = vec.y; cnv[j].nz = vec.z;
					cnv[j].x = cv[j].x; cnv[j].y = cv[j].y; cnv[j].z = cv[j].z;
				}
				model->Object[i].Flags = (GU_NORMAL_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D);
				free(model->Object[i].Data); model->Object[i].Data = (void*) cnv;
				break;
			case 3: case 4:		// v+t
				// Transforma a TCNV
				tcnv = (AMG_Vertex_TNV*) calloc (model->Object[i].NFaces*3, sizeof(AMG_Vertex_TNV));
				tcv = (AMG_Vertex_TV*) model->Object[i].Data;
				model->FaceFormat = 3;
				for(j=0;j<(model->Object[i].NFaces*3);j++){
					vec.x = tcv[j].x; vec.y = tcv[j].y; vec.z = tcv[j].z;
					AMG_Normalize(&vec);
					tcnv[j].nx = vec.x; tcnv[j].ny = vec.y; tcnv[j].nz = vec.z;
					tcnv[j].x = tcv[j].x; tcnv[j].y = tcv[j].y; tcnv[j].z = tcv[j].z;
				}
				model->Object[i].Flags = (GU_TEXTURE_32BITF | GU_NORMAL_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D);
				free(model->Object[i].Data); model->Object[i].Data = (void*) tcnv;
				break;
			default: AMG_Error(AMG_CUSTOM_ERROR, 0, "AMG_NormalizeModel: Couldn't normalize model"); return;
		}
	}
}

// Renderiza un objeto (mirror)
void AMG_RenderMirrorObject(AMG_Object *obj, u8 axis){
    // Cuidado con la iluminacion
	if(obj == NULL) return;
	u8 l = sceGuGetStatus(GU_LIGHTING);
	sceGuDisable(GU_LIGHTING);
	sceGuStencilFunc(GU_EQUAL, 1, 1);
	sceGuStencilOp(GU_KEEP, GU_KEEP, GU_KEEP);
	// Guarda valores temporales
	ScePspFVector3 tmp_pos, tmp_scl, tmp_rot;
	tmp_pos.x = obj->Pos.x; tmp_pos.y = obj->Pos.y; tmp_pos.z= obj->Pos.z;
	tmp_scl.x = obj->Scale.x; tmp_scl.y = obj->Scale.y; tmp_scl.z= obj->Scale.z;
	tmp_rot.x = obj->Rot.x; tmp_rot.y = obj->Rot.y; tmp_rot.z= obj->Rot.z;
	// Cambia la posición
	float d = 0.0f;		// Distancia del objeto al suelo
	switch(axis){
		case 0:			// Eje X
			d = ((obj->Origin.x + obj->Pos.x) - (amg_curfloor->Origin.x + amg_curfloor->Pos.x));
			obj->Pos.x -= (d * 2.0f);
			obj->Scale.x = -obj->Scale.x;
			obj->Rot.y = -obj->Rot.z;
			obj->Rot.z = -obj->Rot.z;
			break;
		case 1:			// Eje Y
			d = ((obj->Origin.y + obj->Pos.y) - (amg_curfloor->Origin.y + amg_curfloor->Pos.y));
			obj->Pos.y -= (d * 2.0f);
			obj->Scale.y = -obj->Scale.y;
			obj->Rot.x = -obj->Rot.x;
			obj->Rot.z = -obj->Rot.z;
			break;
		case 2:			// Eje Z
			d = ((obj->Origin.z + obj->Pos.z) - (amg_curfloor->Origin.z + amg_curfloor->Pos.z));
			obj->Pos.z -= (d * 2.0f);
			obj->Scale.z = -obj->Scale.z;
			obj->Rot.x = -obj->Rot.x;
			obj->Rot.y = -obj->Rot.y;
			break;
		default: return;
	}
	// Renderiza el objeto
	AMG_RenderObject(obj, 0, 3);
	obj->Pos = tmp_pos;
	obj->Scale = tmp_scl; 
	obj->Rot = tmp_rot; 
	if(l) sceGuEnable(GU_LIGHTING);
}

// Renderiza un actor (mirror)
void AMG_RenderMirrorActor(AMG_Actor *obj, u8 axis){
    // Cuidado con la iluminacion
	if(obj == NULL) return;
	u8 l = sceGuGetStatus(GU_LIGHTING);
	sceGuDisable(GU_LIGHTING);
	sceGuStencilFunc(GU_EQUAL, 1, 1);
	sceGuStencilOp(GU_KEEP, GU_KEEP, GU_KEEP);
	// Guarda valores temporales
	ScePspFVector3 tmp_pos, tmp_scl;
	tmp_pos.x = obj->Pos.x; tmp_pos.y = obj->Pos.y; tmp_pos.z= obj->Pos.z;
	tmp_scl.x = obj->Scale.x; tmp_scl.y = obj->Scale.y; tmp_scl.z= obj->Scale.z;

	// Cambia la posición
	float d = 0.0f;		// Distancia del objeto al suelo
	switch(axis){
		case 0:			// Eje X
			d = ((obj->Origin.x + obj->Pos.x) - (amg_curfloor->Origin.x + amg_curfloor->Pos.x));
			obj->Pos.x -= (d * 2.0f);
			obj->Scale.x = -obj->Scale.x;
			break;
		case 1:			// Eje Y
			d = ((obj->Origin.y + obj->Pos.y) - (amg_curfloor->Origin.y + amg_curfloor->Pos.y));
			obj->Pos.y -= (d * 2.0f);
			obj->Scale.y = -obj->Scale.y;
			break;
		case 2:			// Eje Z
			d = ((obj->Origin.z + obj->Pos.z) - (amg_curfloor->Origin.z + amg_curfloor->Pos.z));
			obj->Pos.z -= (d * 2.0f);
			obj->Scale.z = -obj->Scale.z;
			break;
		default: return;
	}
	// Renderiza el objeto
	obj->Mirror = 1;
	AMG_RenderActor(obj, 0);
	obj->Mirror = 0;
	obj->Pos.x = tmp_pos.x; obj->Pos.y = tmp_pos.y; obj->Pos.z = tmp_pos.z;
	obj->Scale.x = tmp_scl.x; obj->Scale.y = tmp_scl.y; obj->Scale.z = tmp_scl.z;
	if(l) sceGuEnable(GU_LIGHTING);
}


// Comienza el motor de reflejos
void AMG_StartReflection(AMG_Object *obj){
	sceGuEnable(GU_STENCIL_TEST);
	sceGuStencilFunc(GU_ALWAYS, 1, 1);
	sceGuStencilOp(GU_KEEP, GU_KEEP, GU_REPLACE);
	
	AMG_RenderObject(obj, 0, 4);

	amg_curfloor = obj;
}

// Termina el motor de reflejos
void AMG_FinishReflection(){
	sceGuDisable(GU_STENCIL_TEST);
	sceGuClear(GU_STENCIL_BUFFER_BIT);
	//sceGuEnable(GU_BLEND);
	sceGuBlendFunc(GU_ADD ,GU_SRC_COLOR, GU_FIX, 0, 0x77444444);
	AMG_RenderObject(amg_curfloor, 0, 0);
	sceGuBlendFunc(GU_ADD , GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
	//sceGuDisable(GU_BLEND);
}

//***************
//3D object (cylinder) for STENCIL Shadow
AMG_Vertex_NV Volumetric_Shadow[240] =
{    
    {0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{-0.485700, 0.237800, -0.841200, -0.237500, -0.036935, -0.411362},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.498200, -0.085300, -0.862900, 0.196391, -7.154250, -0.340160},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.841200, 0.237800, -0.485700, 0.411362, -0.036935, -0.237500},
	{0.862900, -0.085300, -0.498200, 0.340160, -7.154251, -0.196392},
	{0.841200, 0.237800, -0.485700, 0.411362, -0.036935, -0.237500},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.485700, 0.237800, 0.841200, 0.237500, -0.036935, 0.411362},
	{0.498200, -0.085300, 0.862900, 0.196391, -7.154250, 0.340159},
	{0.485700, 0.237800, 0.841200, 0.237500, -0.036935, 0.411362},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{0.000000, -0.085300, 0.996400, 0.000000, -7.154250, 0.392781},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{-0.498200, -0.085300, 0.862900, -0.196391, -7.154250, 0.340159},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{-0.841200, 0.237800, 0.485700, -0.411362, -0.036935, 0.237500},
	{-0.862900, -0.085300, 0.498200, -0.340160, -7.154250, 0.196390},
	{-0.841200, 0.237800, 0.485700, -0.411362, -0.036935, 0.237500},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{-0.485700, 0.237800, -0.841200, -0.237500, -0.036935, -0.411362},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.485700, 0.237800, -0.841200, -0.237500, -0.036935, -0.411362},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.841200, 0.237800, -0.485700, 0.411362, -0.036935, -0.237500},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{0.485700, 0.237800, 0.841200, 0.237500, -0.036935, 0.411362},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.749100, 0.662500, 0.000000, -0.300844, 0.273167, 0.000000},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.841200, 0.237800, 0.485700, -0.411362, -0.036935, 0.237500},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.639200, 0.671200, 0.375500, 0.260539, 0.273167, 0.150422},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{0.000000, 0.662500, -0.749100, 0.000000, 0.273167, -0.300844},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{0.000000, 0.662500, 0.749100, 0.000000, 0.273167, 0.300844},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.000000, 0.662500, -0.749100, 0.000000, 0.273167, -0.300844},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{0.000000, 0.662500, -0.749100, 0.000000, 0.273167, -0.300844},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.000000, 0.662500, 0.749100, 0.000000, 0.273167, 0.300844},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{0.000000, 0.662500, 0.749100, 0.000000, 0.273167, 0.300844},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{0.639200, 0.671200, 0.375500, 0.260539, 0.273167, 0.150422},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.749100, 0.662500, 0.000000, 0.300844, 0.273167, 0.000000},
	{0.639200, 0.671200, 0.375500, 0.260539, 0.273167, 0.150422},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{0.639200, 0.671200, 0.375500, 0.260539, 0.273167, 0.150422},
	{0.749100, 0.662500, 0.000000, 0.300844, 0.273167, 0.000000},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{-0.749100, 0.662500, 0.000000, -0.300844, 0.273167, 0.000000},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{0.749100, 0.662500, 0.000000, 0.300844, 0.273167, 0.000000},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{-0.749100, 0.662500, 0.000000, -0.300844, 0.273167, 0.000000},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.000000, 1.000000, 0.000000, 0.000000, 0.433135, 0.000000},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{0.000000, 1.000000, 0.000000, 0.000000, 0.433135, 0.000000},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{0.000000, 1.000000, 0.000000, 0.000000, 0.433135, 0.000000},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.000000, 1.000000, 0.000000, 0.000000, 0.433135, 0.000000},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{-0.862900, -0.085300, -0.498200, -0.340160, -7.154251, -0.196392},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{0.000000, -0.085300, -0.996400, 0.000000, -7.154250, -0.392783},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{-0.862900, -0.085300, -0.498200, -0.340160, -7.154251, -0.196392},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{-0.862900, -0.085300, 0.498200, -0.340160, -7.154250, 0.196390},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{-0.498200, -0.085300, 0.862900, -0.196391, -7.154250, 0.340159},
	{-0.862900, -0.085300, 0.498200, -0.340160, -7.154250, 0.196390},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.000000, -0.085300, 0.996400, 0.000000, -7.154250, 0.392781},
	{-0.498200, -0.085300, 0.862900, -0.196391, -7.154250, 0.340159},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.498200, -0.085300, 0.862900, 0.196391, -7.154250, 0.340159},
	{0.000000, -0.085300, 0.996400, 0.000000, -7.154250, 0.392781},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.862900, -0.085300, 0.498200, 0.340160, -7.154251, 0.196390},
	{0.498200, -0.085300, 0.862900, 0.196391, -7.154250, 0.340159},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.862900, -0.085300, 0.498200, 0.340160, -7.154251, 0.196390},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.862900, -0.085300, -0.498200, 0.340160, -7.154251, -0.196392},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.498200, -0.085300, -0.862900, 0.196391, -7.154250, -0.340160},
	{0.862900, -0.085300, -0.498200, 0.340160, -7.154251, -0.196392},
	{0.000000, -1.000000, 0.000000, 0.000000, -9.566864, -0.000002},
	{0.000000, -0.085300, -0.996400, 0.000000, -7.154250, -0.392783},
	{0.498200, -0.085300, -0.862900, 0.196391, -7.154250, -0.340160},
	{0.000000, 0.662500, -0.749100, 0.000000, 0.273167, -0.300844},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{0.000000, -0.085300, -0.996400, 0.000000, -7.154250, -0.392783},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{0.498200, -0.085300, -0.862900, 0.196391, -7.154250, -0.340160},
	{0.498200, -0.085300, -0.862900, 0.196391, -7.154250, -0.340160},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.862900, -0.085300, -0.498200, 0.340160, -7.154251, -0.196392},
	{0.862900, -0.085300, -0.498200, 0.340160, -7.154251, -0.196392},
	{0.841200, 0.237800, -0.485700, 0.411362, -0.036935, -0.237500},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.862900, -0.085300, 0.498200, 0.340160, -7.154251, 0.196390},
	{0.996400, -0.085300, 0.000000, 0.392782, -7.154250, -0.000001},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.862900, -0.085300, 0.498200, 0.340160, -7.154251, 0.196390},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.498200, -0.085300, 0.862900, 0.196391, -7.154250, 0.340159},
	{0.498200, -0.085300, 0.862900, 0.196391, -7.154250, 0.340159},
	{0.485700, 0.237800, 0.841200, 0.237500, -0.036935, 0.411362},
	{0.000000, -0.085300, 0.996400, 0.000000, -7.154250, 0.392781},
	{0.000000, -0.085300, 0.996400, 0.000000, -7.154250, 0.392781},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{-0.498200, -0.085300, 0.862900, -0.196391, -7.154250, 0.340159},
	{-0.498200, -0.085300, 0.862900, -0.196391, -7.154250, 0.340159},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{-0.862900, -0.085300, 0.498200, -0.340160, -7.154250, 0.196390},
	{-0.862900, -0.085300, 0.498200, -0.340160, -7.154250, 0.196390},
	{-0.841200, 0.237800, 0.485700, -0.411362, -0.036935, 0.237500},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{-0.862900, -0.085300, -0.498200, -0.340160, -7.154251, -0.196392},
	{-0.996400, -0.085300, 0.000000, -0.392782, -7.154250, -0.000001},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{0.000000, -0.085300, -0.996400, 0.000000, -7.154250, -0.392783},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{-0.862900, -0.085300, -0.498200, -0.340160, -7.154251, -0.196392},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.498200, -0.085300, -0.862900, -0.196391, -7.154250, -0.340160},
	{0.841200, 0.237800, -0.485700, 0.411362, -0.036935, -0.237500},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.749100, 0.662500, 0.000000, 0.300844, 0.273167, 0.000000},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.000000, 0.662500, 0.749100, 0.000000, 0.273167, 0.300844},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{-0.749100, 0.662500, 0.000000, -0.300844, 0.273167, 0.000000},
	{-0.971300, 0.237800, 0.000000, -0.475000, -0.036935, 0.000000},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{-0.841200, 0.237800, 0.485700, -0.411362, -0.036935, 0.237500},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{0.485700, 0.237800, 0.841200, 0.237500, -0.036935, 0.411362},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{0.485700, 0.237800, -0.841200, 0.237500, -0.036935, -0.411362},
	{0.000000, 0.237800, -0.971300, 0.000000, -0.036935, -0.475000},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{-0.485700, 0.237800, 0.841200, -0.237500, -0.036935, 0.411362},
	{0.000000, 0.237800, 0.971300, 0.000000, -0.036935, 0.475000},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{-0.639200, 0.671200, -0.375500, -0.260539, 0.273167, -0.150422},
	{0.000000, 0.923200, -0.384400, 0.000000, 0.412927, -0.089048},
	{0.639200, 0.671200, -0.375500, 0.260539, 0.273167, -0.150422},
	{0.375500, 0.671200, -0.639200, 0.150422, 0.273167, -0.260539},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.000000, 0.923200, 0.384400, 0.000000, 0.412927, 0.089048},
	{0.375500, 0.671200, 0.639200, 0.150422, 0.273167, 0.260539},
	{0.384400, 0.923200, 0.000000, 0.089048, 0.412927, 0.000000},
	{0.841200, 0.237800, 0.485700, 0.411362, -0.036935, 0.237500},
	{0.971300, 0.237800, 0.000000, 0.475000, -0.036935, 0.000000},
	{0.639200, 0.671200, 0.375500, 0.260539, 0.273167, 0.150422},
	{-0.485700, 0.237800, -0.841200, -0.237500, -0.036935, -0.411362},
	{-0.841200, 0.237800, -0.485700, -0.411362, -0.036935, -0.237500},
	{-0.375500, 0.671200, -0.639200, -0.150422, 0.273167, -0.260539},
	{-0.639200, 0.671200, 0.375500, -0.260539, 0.273167, 0.150422},
	{-0.375500, 0.671200, 0.639200, -0.150422, 0.273167, 0.260539},
	{-0.384400, 0.923200, 0.000000, -0.089048, 0.412927, 0.000000}
};

void AMG_CastModelShadow(AMG_Model *c, int obj = 0, int alpha = 100, int type = 1, int light = 0)
{    
	//Prepare to Draw Shadows  
	sceGuEnable(GU_CULL_FACE);
    sceGuDisable(GU_TEXTURE_2D);
	sceGuDepthMask(GU_TRUE);
	float shadow_size = 0;
	float CX = 0;
	float CZ = 0;
	
	shadow_size = (1.2*c->Object[obj].Scale.x * fabs((c->Object[obj].BBox[0].x - c->Object[obj].BBox[1].x)));
	CX = c->Object[obj].Pos.x;
    CZ = c->Object[obj].Pos.z;

    float LX = AMG_Light[light].Pos.x;  
    float LY = AMG_Light[light].Pos.y;
    float LZ = AMG_Light[light].Pos.z;

	ScePspFVector3 size;	
	size.x = size.y = size.z = shadow_size;
	ScePspFVector3 rot;
	rot.x = 0; 
    float Dist = 0; 	
	if (AMG_Light[light].Type == GU_DIRECTIONAL){
		rot.y = -vfpu_atan2f(LZ,LX); rot.z = -vfpu_atan2f(LX,LY);
		if ((LX == 0) && (LZ == 0)) {rot.y = 0; rot.z = 0;}
	}
	if ((AMG_Light[light].Type == GU_POINTLIGHT) || (AMG_Light[light].Type == GU_SPOTLIGHT)){
		Dist = 6*AMG_SquareRoot(vfpu_powf((LX-CX),2) + vfpu_powf((LZ-CZ),2));
		rot.y = -(GU_PI/180.0f)*180.0f-vfpu_atan2f(CZ-LZ,CX-LX); rot.z = -vfpu_atan2f(Dist,LY);
	}
	AMG_PushMatrix(GU_MODEL);
	
	AMG_Translate(GU_MODEL, &c->Object[obj].Pos);
	AMG_Translate(GU_MODEL, &c->Object[obj].Origin);
	if (type == 1) AMG_Rotate(GU_MODEL, &rot);
	AMG_Scale(GU_MODEL, &size);
	c->Object[0].Origin.x = -c->Object[0].Origin.x; c->Object[0].Origin.y = -c->Object[0].Origin.y; c->Object[0].Origin.z = -c->Object[0].Origin.z;
	AMG_Translate(GU_MODEL, &c->Object[0].Origin);
	c->Object[0].Origin.x = -c->Object[0].Origin.x; c->Object[0].Origin.y = -c->Object[0].Origin.y; c->Object[0].Origin.z = -c->Object[0].Origin.z;
	AMG_UpdateMatrices();

  if (!skip){
	//Draw shadow 1 pass
	sceGuDisable(GU_LIGHTING);			  
	sceGuFrontFace(GU_CW);
	sceGuEnable(GU_STENCIL_TEST); // Stencil test
    sceGuStencilFunc(GU_ALWAYS, 1, 1); // always set 1 bit in 1 bit mask
    sceGuStencilOp(GU_KEEP, GU_KEEP, GU_REPLACE); // keep value on failed test (fail and zfail) and replace on pass
	
	sceGuColor(0x01000000); 
	sceGuDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_3D,240, 0, Volumetric_Shadow);
	
	//Draw shadow 2 pass GU_NORMAL_32BITF
	sceGuFrontFace(GU_CCW);
	sceGuStencilFunc(GU_EQUAL, 0, 1); // allow drawing where stencil is 1
	sceGuStencilOp(GU_KEEP, GU_KEEP, GU_KEEP); // keep the stencil buffer unchanged
	
	sceGuColor(GU_RGBA(0,0,0,alpha));
	sceGuDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_3D, 240, 0, Volumetric_Shadow);
  }
	AMG_PopMatrix(GU_MODEL);

	sceGuClear(GU_STENCIL_BUFFER_BIT);//GU_DEPTH_BUFFER_BIT

	//Restore drawing to normal
	sceGuDisable(GU_STENCIL_TEST);
	sceGuDepthMask(GU_FALSE);
	sceGuDisable(GU_CULL_FACE);
	sceGuEnable(GU_TEXTURE_2D);
	sceGuEnable(GU_LIGHTING);
}


void AMG_CastActorShadow(AMG_Actor *a, int alpha = 100, int type = 1, int light = 0)
{    
	//Prepare to Draw Shadows  
	sceGuEnable(GU_CULL_FACE);
    sceGuDisable(GU_TEXTURE_2D);
	sceGuDepthMask(GU_TRUE);
	float shadow_size = 0;
	float CX = 0;
	float CZ = 0;
	
	shadow_size = 1*(a->Scale.x * fabs(a->Object->BBox[0].x - a->Object->BBox[1].x));
	CX = a->Pos.x;
    CZ = a->Pos.z;

    float LX = AMG_Light[light].Pos.x;  
    float LY = AMG_Light[light].Pos.y;
    float LZ = AMG_Light[light].Pos.z;
	float CCX = CX+LX; float CCZ = CZ+LZ;
	ScePspFVector3 size;	
	size.x = size.y = size.z = shadow_size;
	ScePspFVector3 rot;
	rot.x = 0; 
    float Dist = 0; 	
	if (AMG_Light[light].Type == GU_DIRECTIONAL){
		Dist = AMG_SquareRoot(vfpu_powf((CCX-CX),2) + vfpu_powf((CCZ-CZ),2));
		rot.y = -vfpu_atan2f(LZ,LX); rot.z = -vfpu_atan2f(Dist,LY);	
	}
	if ((AMG_Light[light].Type == GU_POINTLIGHT) || (AMG_Light[light].Type == GU_SPOTLIGHT)){
		Dist = 6*AMG_SquareRoot(vfpu_powf((LX-CX),2) + vfpu_powf((LZ-CZ),2));
		rot.y = -(GU_PI/180.0f)*180.0f-vfpu_atan2f(CZ-LZ,CX-LX); rot.z = -vfpu_atan2f(Dist,LY);
	}
	AMG_PushMatrix(GU_MODEL);
	
	AMG_Translate(GU_MODEL, &a->Pos);
	AMG_Translate(GU_MODEL, &a->Origin);
	if (type == 1) AMG_Rotate(GU_MODEL, &rot);
	AMG_Scale(GU_MODEL, &size);
	a->Origin.x = -a->Origin.x; a->Origin.y = -a->Origin.y; a->Origin.z = -a->Origin.z;
	AMG_Translate(GU_MODEL, &a->Origin);
	a->Origin.x = -a->Origin.x; a->Origin.y = -a->Origin.y; a->Origin.z = -a->Origin.z;
	AMG_UpdateMatrices();
  if (!skip){
	//Draw shadow 1 pass
	sceGuDisable(GU_LIGHTING);			  
	sceGuFrontFace(GU_CW);
	sceGuEnable(GU_STENCIL_TEST); // Stencil test
    sceGuStencilFunc(GU_ALWAYS, 1, 1); // always set 1 bit in 1 bit mask
    sceGuStencilOp(GU_KEEP, GU_KEEP, GU_REPLACE); // keep value on failed test (fail and zfail) and replace on pass
	sceGuColor(0x01000000); 
	sceGuDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_3D,240, 0, Volumetric_Shadow);

	//Draw shadow 2 pass GU_NORMAL_32BITF
	sceGuFrontFace(GU_CCW);
	sceGuStencilFunc(GU_EQUAL, 0, 1); // allow drawing where stencil is 1
	sceGuStencilOp(GU_KEEP, GU_KEEP, GU_KEEP); // keep the stencil buffer unchanged
	sceGuColor(GU_RGBA(0,0,0,alpha));
	sceGuDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_3D, 240, 0, Volumetric_Shadow);
  }
	AMG_PopMatrix(GU_MODEL);

	sceGuClear(GU_STENCIL_BUFFER_BIT);//GU_DEPTH_BUFFER_BIT

	//Restore drawing to normal
	sceGuDisable(GU_STENCIL_TEST);
	sceGuDepthMask(GU_FALSE);
	sceGuDisable(GU_CULL_FACE);
	sceGuEnable(GU_TEXTURE_2D);
	sceGuEnable(GU_LIGHTING);	
}

void AMG_Set_Fur(AMG_Object *object, int group, float Scale, u8 nlayers, int idensity, u8 fluffyness, float translucency, u32 filter){
	if (object->Group[group].Texture->TexFormat != GU_PSM_8888) return;
	AMG_Vertex_TNV *vertex = (AMG_Vertex_TNV*)&(((u8*)object->Data)[object->Group[group].Start*object->TriangleSize]);
	u16 nfaces = (object->Group[group].End - object->Group[group].Start);
	object->Fur = (AMG_Vertex_TNV*) malloc(sizeof(AMG_Vertex_TNV)*nfaces*3*nlayers);
	object->FurGroup = group;
	object->TexFur = (AMG_Texture*) malloc(sizeof(AMG_Texture)*nlayers);
	object->FurLayers = nlayers;
	object->FurFilter = filter;
	int size = object->Group[group].Texture->Width;
	int i,layer;
	float length = 0;
	for (layer = 0; layer < nlayers;layer++){
		length += Scale/nlayers;
		float displacement_x = 0;//0.0009*layer;
		float displacement_y = 0;//.001*layer;
		u32 dataoffset = nfaces*3*layer;
		for (i = 0; i < nfaces*3;i++){
			object->Fur[i+dataoffset].u = vertex[i].u+displacement_x;
			object->Fur[i+dataoffset].v = vertex[i].v+displacement_y;
			object->Fur[i+dataoffset].nx = vertex[i].nx;
			object->Fur[i+dataoffset].ny = vertex[i].ny;
			object->Fur[i+dataoffset].nz = vertex[i].nz;
			object->Fur[i+dataoffset].x = vertex[i].x + vertex[i].nx * length;
			object->Fur[i+dataoffset].y = vertex[i].y + vertex[i].ny * length;
			object->Fur[i+dataoffset].z = vertex[i].z + vertex[i].nz * length;
		}
	}
	AMG_UnswizzleTexture(object->Group[group].Texture);
	srand(0);
	float hlight = 1-translucency;
	for (layer = 0; layer < nlayers;layer++){
		object->TexFur[layer].Data = (u32*) AMG_VramAlloc(size, size, GU_PSM_4444);
		//Set all pixels to 0
		for(i=0; i<size*size; i++) object->TexFur[layer].Data[i] = 0x00000000;
		
		//Change density
		float hlength = (float)layer/(float)nlayers;
		hlength = 1 - hlength;
		int density = idensity * hlength* 2;
		//int density = idensity * sin(length*(GU_PI/2));
		
		//Change alpha according to fluffyness
		float halpha = ((fluffyness/(float)nlayers)*layer)-(255-fluffyness);
		
		//Change darkness according to translucency
		hlight += translucency/(float)nlayers;
		if (layer == 0){
			for(i=0; i<size*size; i++){
				u32 color = object->Group[group].Texture->Data[i];
				float r = ((color      ) & 0xff);
				float g = ((color >>  8) & 0xff);
				float b = ((color >> 16) & 0xff);
				float a = ((color >> 24) & 0xff);
				//Make base texture darker
				r *= hlight; g *= hlight; b *= hlight;
				((u16*)object->TexFur[0].Data)[i] = (AMG_RGBA4444((u8)r>>4,(u8)g>>4,(u8)b>>4,(u8)a>>4));
			}
		}
		else{ //Layer 1 and so... make the fur texture
			//seed random number generator
			srand(28382);
			for(i=0; i<density; i++){
				int xrand = rand() % (size - 0);
				int yrand = rand() % (size - 0);
				u32 offset = (xrand + (yrand * size));
				u32 color = AMG_GetTexturePixel(object->Group[group].Texture,xrand,yrand);
				float r = ((color      ) & 0xff);
				float g = ((color >>  8) & 0xff);
				float b = ((color >> 16) & 0xff);
				float a = ((color >> 24) & 0xff);
				
				//Now modify non transparent pixels (hairs or grass...)
				if (a>0){
					//The bottom parts are darker
					r *= hlight; g *= hlight; b *= hlight;
					//Now, make more transparent the top parts of the hair/grass
					a = 255-halpha;
				}
				//Store values in 16 bit colour to speed up rendering
				((u16*)object->TexFur[layer].Data)[offset] = (AMG_RGBA4444((u8)r>>4,(u8)g>>4,(u8)b>>4,(u8)a>>4));
			}
		}
	}
	AMG_ConvertTexture(object->Group[group].Texture, GU_PSM_4444);
	AMG_SwizzleTexture(object->Group[group].Texture);
	//object->TexFur[0].Data = object->Group[0].Texture->Data;
	//memcpy(&object->TexFur[0].data,object->Group[0].Texture->Data,sizeof(u16)*size*size);
}